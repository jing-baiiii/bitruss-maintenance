# Bitruss Maintenance

This directory contains reproducible implementations of dynamic bipartite bitruss maintenance algorithms, organized as a CMake project. It includes four algorithms, BM, SA, SAP, and SAP+, with support for edge insertion, edge deletion, continuous updates, memory measurement, and correctness verification.

## Directory Layout

```text
.
├── CMakeLists.txt
├── include/
│   ├── bm_sa/          # Shared headers for BM and SA
│   └── sap_sap_plus/   # SAP, SAP+, and Bai baseline dependencies
├── src/
│   ├── bm_sa/          # Canonical BM and SA entry points and implementations
│   └── sap_sap_plus/   # Canonical SAP and SAP+ entry points and Bai sources
├── scripts/            # Build and verification scripts
├── data/
│   ├── datasets/       # Small DS and GH graph inputs
│   ├── samples/        # Frozen update sequences
│   └── results/        # Experiment summaries and event measurements
└── docs/               # Algorithm and reproduction notes
```

## Build

A C++17 compiler and CMake 3.16 or newer are required. OpenMP is enabled automatically when available.

```bash
cmake -S . -B build -DCMAKE_BUILD_TYPE=Release
cmake --build build -j
```

To build only the correctness verification programs:

```bash
cmake -S . -B build -DBITRUSS_BUILD_EXPERIMENTS=OFF
cmake --build build -j
```

## Entry Points

See `docs/Algorithm and Reproduction Notes.md` for BM/SA arguments and data formats. Common targets are:

```text
build/bm_sa_verify_insert
build/bm_sa_verify_delete
build/bm_sa_bench
build/bm_sa_continuous
build/bm_sa_memory
build/sap_sap_plus_runner
```

Programs require a graph file and a sample-edge file as input. DS and GH graph inputs and the frozen experiment sequences are included under `data/`; see `data/README.md` for formats, label conventions, and result tables.

## Source Scope

This directory contains the canonical algorithm sources, their required dependencies, build files, reproducibility entry points, frozen update samples, and experiment result tables. Full run logs, manuscripts, and historical source snapshots are outside the release directory.

## License and Citation

Add the project license, author information, and paper citation before publishing. This directory does not make license claims for third-party dependencies.
