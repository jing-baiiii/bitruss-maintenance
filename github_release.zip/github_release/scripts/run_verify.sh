#!/usr/bin/env bash
set -euo pipefail

root=$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)
build_dir="${root}/build"
if [[ ! -x "${build_dir}/bm_sa_verify_insert" ]]; then
  "${root}/scripts/build.sh" -DBITRUSS_BUILD_EXPERIMENTS=OFF
fi

if [[ $# -lt 3 ]]; then
  printf 'Usage: %s <insert|delete> <graph-file> <sample-file> [sample-count]\n' "$0" >&2
  exit 2
fi
direction=$1
graph=$2
sample=$3
count=${4:-100}
case "${direction}" in
  insert) exec "${build_dir}/bm_sa_verify_insert" "${graph}" "${sample}" "${count}" ;;
  delete) exec "${build_dir}/bm_sa_verify_delete" "${graph}" "${sample}" "${count}" ;;
  *) printf 'Direction must be insert or delete\n' >&2; exit 2 ;;
esac
