#!/usr/bin/env bash
set -euo pipefail

root=$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)
build_dir="${root}/build"
cmake -S "${root}" -B "${build_dir}" -DCMAKE_BUILD_TYPE=Release "$@"
cmake --build "${build_dir}" -j
