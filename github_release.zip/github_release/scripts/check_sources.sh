#!/usr/bin/env bash
set -euo pipefail

root=$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)
status=0
if rg -n '/media/|/home/|[A-Za-z]:\\\\' "${root}" \
    --glob '!**/build/**' --glob '!**/scripts/**' --glob '!*.md' --glob '!*.pdf'; then
  printf 'Machine-specific absolute paths were found; use relative paths or command-line arguments.\n' >&2
  status=1
fi
while IFS= read -r artifact; do
  printf 'Build or experiment artifact should not be committed: %s\n' "${artifact#"${root}/"}" >&2
  status=1
done < <(find "${root}" -type f \( -name '*.o' -o -name '*.out' -o -name '*.tsv' -o -name '*.log' \) \
  ! -path "${root}/data/results/*" -print)
exit "${status}"
