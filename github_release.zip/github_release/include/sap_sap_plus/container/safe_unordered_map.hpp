






#pragma once
#include "container/container_utility.h"

namespace scnu
{
    




    template <typename key_type, typename value_type>
    class safe_unordered_map
    {
    public:
        





        value_type& at(key_type key)
        {
            return data_map.at(key);
        }

        



        auto begin()
        {
            return data_map.begin();
        }

        


        void clear()
        {
            lock_guard<mutex> lg(map_mutex);
            data_map.clear();
        }

        




        bool count(key_type key)
        {
            lock_guard<mutex> lg(map_mutex);
            return data_map.count(key);
        }

        



        bool empty()
        {
            lock_guard<mutex> lg(map_mutex);
            return data_map.empty();
        }

        



        auto end()
        {
            return data_map.end();
        }

        



        void erase(key_type key)
        {
            lock_guard<mutex> lg(map_mutex);
            data_map.erase(key);
        }


        



        void insert(pair<key_type,value_type> p)
        {
            lock_guard<mutex> lg(map_mutex);
            if(!data_map.count(p.first))
            {
                data_map.insert(std::move(p));
            }
        }

        void lock()
        {
            map_mutex.lock();
        }


        





        void set_value(key_type key, value_type value)
        {
            lock_guard<mutex> lg(map_mutex);
            data_map.at(key) = value;
        }

        



        uint32_t size()
        {
            lock_guard<mutex> lg(map_mutex);
            return data_map.size();
        }

        void unlock()
        {
            map_mutex.unlock();
        }

    private:
        mutable mutex map_mutex;
        unordered_map<key_type,value_type> data_map;
    };
}
