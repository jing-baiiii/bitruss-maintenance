







#pragma once
#include "container/extend_node.hpp"

namespace scnu
{


    






    template <typename key_type, typename value_type>
    class extend_list {
        


        using iterator = list_iterator<shared_ptr<extend_node<key_type,value_type>>>;
        using forward_iterator = list_forward_iterator<shared_ptr<extend_node<key_type,value_type>>>;
        using backward_iterator = list_backward_iterator<shared_ptr<extend_node<key_type,value_type>>>;
    public:
        



        extend_list():node_map(make_shared<unordered_map<value_type, shared_ptr<extend_node<key_type, value_type>>>>()) {

        }

        



        explicit extend_list(const shared_ptr<extend_list<key_type,value_type>>& other_list):extend_list(){
            auto p = other_list->get_head();
            while (p) {
                auto node = make_shared<extend_node<key_type, value_type>>(0, p->get_value());
                right_insert(node);

                p = p->get_next();
            }
        }

        



        iterator begin()
        {
            return forward_iterator(head);
        }


        


        void clear() {
            head->reset();
            rear->reset();
            node_map->clear();
        }

        




        bool count_value(const value_type &value) {
            return node_map->count(value);
        }

        



        bool empty()
        {
            return node_map->empty();
        }

        



        iterator end()
        {
            return forward_iterator(shared_ptr<extend_node<key_type, value_type>>());
        }

        



        shared_ptr<extend_node<key_type,value_type>> get_head() {
            return head;
        }

        





        shared_ptr<extend_node<key_type,value_type>> find(const value_type& value)
        {
            return node_map->count(value) ? node_map->at(value):shared_ptr<extend_node<key_type, value_type>>();
        }

        




        std::optional<key_type> find_key(const value_type& value)
        {
            if(node_map->count(value))
            {
                return node_map->at(value)->get_key();
            }
            return std::nullopt;
        }

        



        shared_ptr<extend_node<key_type,value_type>> get_rear() {
            return rear;
        }

        



        uint32_t size()
        {
            return node_map->size();
        }

        




        void insert_after(const shared_ptr<extend_node<key_type,value_type>>& node,
                          const shared_ptr<extend_node<key_type,value_type>>& pivot_node)
        {
            if(!pivot_node)
            {
                


                head = node;
                rear = node;
                node->set_key(0);
            }else
            {
                if(pivot_node==rear)
                {
                    



                    auto key = pivot_node->get_key() + 1;
                    node->set_key(key);

                    pivot_node->set_next(node);
                    node->set_prior(pivot_node);
                    node->set_next(nullptr);
                    rear = node;
                } else
                {
                    


                    auto next_node = pivot_node->get_next();

                    pivot_node->set_next(node);
                    node->set_prior(pivot_node);
                    node->set_next(next_node);
                    next_node->set_prior(node);
                }
            }
            node_map->insert({node->get_value(), node});
        }

        




        void insert_before(const shared_ptr<extend_node<key_type,value_type>>& node,
                           const shared_ptr<extend_node<key_type,value_type>>& pivot_node)
        {
            if(!pivot_node)
            {
                


                head = node;
                rear = node;
                node->set_key(0);
            } else
            {

                


                if(pivot_node == head)
                {
                    double key = pivot_node->get_key() - 1;
                    node->set_key(key);

                    node->set_prior(nullptr);
                    node->set_next(pivot_node);

                    pivot_node->set_prior(node);
                    head = node;
                } else
                {
                    


                    auto prior_node = pivot_node->get_prior();

                    node->set_next(pivot_node);
                    node->set_prior(prior_node);
                    prior_node->set_next(node);
                    pivot_node->set_prior(node);
                }
            }
            node_map->insert({node->get_value(), node});
        }

        




        shared_ptr<extend_node<key_type,value_type>> left_insert(const value_type& value) {
            



            auto node = make_shared<extend_node<key_type,value_type>>(0, value);
            if (!head) {
                rear = node;
            } else {
                


                node->set_key(head->get_key() - 1);

                node->set_next(head);
                head->set_prior(node);
            }
            head = node;
            node_map->insert({value, node});

            return node;
        }

        




        void left_insert(const shared_ptr<extend_node<key_type,value_type>>& node) {
            



            if (!head) {
                node->set_key(0);
                rear = node;
            } else {
                node->set_key(head->get_key() - 1);

                node->set_next(head);
                head->set_prior(node);
            }
            head = node;
            node_map->insert({node->get_value(), node});
        }

        iterator rbegin()
        {
            return backward_iterator(rear);
        }

        iterator rend()
        {
            return backward_iterator(nullptr);
        }

        




        void right_insert(const shared_ptr<extend_node<key_type,value_type>>& node) {
            



            if (!rear) {
                node->set_key(0);
                head = node;
            } else {
                node->set_key(rear->get_key() + 1);
                rear->set_next(node);
                node->set_prior(rear);
            }
            rear = node;
            node_map->insert({node->get_value(), node});
        }

        





        shared_ptr<extend_node<key_type,value_type>> push_back(const value_type& value) {
            



            auto node = make_shared<extend_node<key_type,value_type>>(0, value);
            if (!rear) {
                head = node;
            } else {
                node->set_key(rear->get_key() + 1);

                rear->set_next(node);
                node->set_prior(rear);
            }
            rear = node;
            node_map->insert({value, node});
            return node;
        }

        





        shared_ptr<extend_node<key_type,value_type>> remove(const value_type& value) {
            auto node = node_map->at(value);
            if (head == rear) {
                


                head.reset();
                rear.reset();
            } else {
                if (node == head) {
                    


                    head = head->get_next();
                    head->set_prior(nullptr);
                } else if (node == rear) {
                    


                    rear = rear->get_prior();
                    rear->set_next(nullptr);
                } else {
                    


                    auto next_node = node->get_next();
                    auto prior_node = node->get_prior();

                    prior_node->set_next(next_node);
                    next_node->set_prior(prior_node);
                }
            }
            node_map->erase(value);

            node->set_prior(nullptr);
            node->set_next(nullptr);
            return node;
        }

        



        void set_head(const shared_ptr<extend_node<key_type,value_type>>& node) {
            head = node;
        }

        



        void set_rear(const shared_ptr<extend_node<key_type,value_type>>& node) {
            rear = node;
        }

        void reset_left_order(const shared_ptr<extend_node<key_type,value_type>>& node){
            for(auto p = node; p ; p = p->get_prior()){
                p->set_key(p->get_next()->get_key() - 1);
            }
        }

        void reset_right_order(const shared_ptr<extend_node<key_type,value_type>>& node){
            for(auto p = node; p ; p = p->get_next()){
                p->set_key(p->get_prior()->get_key() + 1);
            }
        }

        void reset_order(){
            if(head){
                head->set_key(0);
                reset_right_order(head->get_next());
            }
        }

    private:
        shared_ptr<extend_node<key_type,value_type>> head;
        shared_ptr<extend_node<key_type,value_type>> rear;
        shared_ptr<unordered_map<value_type,shared_ptr<extend_node<key_type,value_type>>>> node_map;
    };
    
}





