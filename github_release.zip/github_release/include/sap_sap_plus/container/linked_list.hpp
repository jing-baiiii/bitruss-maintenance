







#pragma once
#include "container/linked_node.hpp"

namespace scnu
{
    



    template <typename value_type>
    class linked_list
    {
        using iterator = list_forward_iterator<shared_ptr<linked_node<value_type>>>;
    public:

        



        iterator begin()
        {
            return iterator(head);
        }

        void clear(){
            auto p = head;
            while (p){
                auto q = p->get_next();
                p->set_next(shared_ptr<linked_node<value_type>>());
                p = q;
            }
            head = move(shared_ptr<linked_node<value_type>>());
            rear = head;
        }

        



        iterator end()
        {
            return iterator(shared_ptr<linked_node<value_type>>());
        }

        bool empty(){
            return !head ? true:false;
        }

        shared_ptr<linked_node<value_type>> emplace_back(value_type value)
        {
            auto node = make_shared<linked_node<value_type>>(move(value));
            if(!rear)
            {
                head = node;
            } else
            {
                rear->set_next(node);
            }
            rear = node;
            return node;
        }
        



        shared_ptr<linked_node<value_type>> emplace_front(value_type value)
        {
            auto node = make_shared<linked_node<value_type>>(move(value));
            if(!head)
            {
                rear = node;
            }else
            {
                node->set_next(head);
            }
            head = node;
            return node;
        }

        shared_ptr<linked_node<value_type>> erase(iterator iter){
            auto node = *iter;
            erase(node);
            return node;
        }

        void erase(const shared_ptr<linked_node<value_type>>& node){
            if(node == head){
                if(head == rear){
                    head = shared_ptr<linked_node<value_type>>();
                    rear = shared_ptr<linked_node<value_type>>();
                    head == rear;
                }else
                {
                    head = head->get_next();
                }
            }else if(node == rear)
            {
                auto prior_node = find_prior_node(node);
                rear = prior_node;
                rear->set_next(shared_ptr<linked_node<value_type>>());
            }else
            {
                auto prior_node = find_prior_node(node);
                auto next_node = node->get_next();
                prior_node->set_next(next_node);
            }
            node->set_next(shared_ptr<linked_node<value_type>>());
        }

        





        shared_ptr<linked_node<value_type>> find(value_type value)
        {
            auto p = head;
            while(p && p->get_value() != value)
            {
                p = p->get_next();
            }
            return p;
        }

        shared_ptr<linked_node<value_type>> find_prior_node(const shared_ptr<linked_node<value_type>>& node){
            auto p = head;
            while(p && p->get_next()!=node)
            {
                p = p->get_next();
            }
            return p;
        }
        
        



        shared_ptr<linked_node<value_type>> get_head()
        {
            return head;
        }

        



        shared_ptr<linked_node<value_type>> get_rear()
        {
            return rear;
        }

        



        void connect(const shared_ptr<linked_list<value_type>>& other_list)
        {
            if(other_list->head){
                if(!rear)
                {
                    head = move(other_list->head);
                    rear = move(other_list->rear);
                } else
                {
                    auto node = move(other_list->head);
                    rear->set_next(node);
                    rear = move(other_list->rear);
                }
                other_list->head = shared_ptr<linked_node<value_type>>();
                other_list->rear = shared_ptr<linked_node<value_type>>();
            }
        }

        shared_ptr<linked_node<value_type>> insert_after(const shared_ptr<linked_node<value_type>>& pivot_node,
                                                            value_type value)
        {
            



            if(!pivot_node||!pivot_node->get_next())
            {
                return push_back(value);
            }

            auto node = make_shared<linked_node<value_type>>(value);
            auto next_node = pivot_node->get_next();
            node->set_next(next_node);
            pivot_node->set_next(node);
            return node;
        }

        



        shared_ptr<linked_node<value_type>> push_front(value_type value)
        {
            auto node = make_shared<linked_node<value_type>>(value);
            if(!head)
            {
                rear = node;
            }else
            {
                node->set_next(head);
            }
            head = node;
            return node;
        }

        shared_ptr<linked_node<value_type>> push_front(const shared_ptr<linked_node<value_type>> node)
        {
            if(!head)
            {
                rear = node;
            }else
            {
                node->set_next(head);
            }
            head = node;
            return node;
        }

        



        shared_ptr<linked_node<value_type>> push_back(value_type value)
        {
            auto node = make_shared<linked_node<value_type>>(value);
            if(!rear)
            {
                head = node;
            } else
            {
                rear->set_next(node);
            }
            rear = node;
            return node;
        }

        shared_ptr<linked_node<value_type>> push_back(const shared_ptr<linked_node<value_type>>& node)
        {
            if(!rear)
            {
                head = node;
            } else
            {
                rear->set_next(node);
            }
            rear = node;
            return node;
        }


        void remove(value_type value){
            auto node = find(value);
            while(node){
                erase(node);
                node = find(value);
            }
        }

    private:
        shared_ptr<linked_node<value_type>> head;
        shared_ptr<linked_node<value_type>> rear;
    };
}
