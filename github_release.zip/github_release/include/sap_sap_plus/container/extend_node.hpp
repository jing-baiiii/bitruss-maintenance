







#pragma once

#include "container/container_utility.h"
#include "graph/abstract_edge.h"

namespace scnu
{
    




    template <typename key_type, typename value_type>
    class extend_node{
    public:
        




        extend_node(key_type other_key, value_type other_value):
                extend_node(other_key,other_value, nullptr, nullptr){

        }

        




        extend_node(key_type other_key, value_type other_value,
                    const shared_ptr<extend_node<key_type,value_type>> &other_prior,
                    const shared_ptr<extend_node<key_type,value_type>> &other_next):
                    key(other_key),value(other_value),prior(other_prior),next(other_next){

        }

        



        explicit extend_node(const shared_ptr<extend_node<key_type,value_type>> &other_node)
        : extend_node(other_node->get_key(),other_node->get_value(), other_node->get_prior(),
                      other_node->get_next()){

        }

        



        [[nodiscard]] key_type get_key() const {
            return key;
        }


        



        shared_ptr<extend_node<key_type,value_type>> get_next() {
            return next;
        }

        



        shared_ptr<extend_node<key_type,value_type>> get_prior() {
            return prior;
        }

        



        [[nodiscard]] value_type get_value() const {
            return value;
        }

        



        void set_key(key_type other_key) {
            key = other_key;
        }

        




        void set_next(const shared_ptr<extend_node<key_type,value_type>>& other_node) {
            if(other_node)
            {
                next = other_node;
            }
            else
            {
                next.reset();
            }
        }

        




        void set_prior(const shared_ptr<extend_node<key_type,value_type>>& other_node) {
            if(other_node)
            {
                prior = other_node;
            }else
            {
                prior.reset();
            }
        }

    private:
        key_type key;
        value_type value;
        shared_ptr<extend_node<key_type,value_type>> prior;
        shared_ptr<extend_node<key_type,value_type>> next;
    };

    template <typename key_type, typename value_type>
    struct extend_node_compare
    {
        bool operator()(const shared_ptr<scnu::extend_node<key_type, value_type>>& node1,
                        const shared_ptr<scnu::extend_node<key_type, value_type>>& node2) const
        {
            return node1->get_key() < node2->get_key();
        }
    };
}


