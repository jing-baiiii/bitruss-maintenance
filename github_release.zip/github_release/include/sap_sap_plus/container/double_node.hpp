







#pragma once
#include "container/container_utility.h"

namespace scnu
{
    


    template <typename value_type>
    class double_node {
    public:
        




        explicit double_node(value_type other_value): value(other_value) {

        }

        




         explicit double_node(const shared_ptr<double_node>& node):
                value(node->get_value()), next(node->get_next()), prior(node->get_prior()){
        }

        




        value_type get_value() const{
            return value;
        }

        




        shared_ptr<double_node> get_next() const{
            return next;
        }

        




        shared_ptr<double_node> get_prior() const{
            return prior;
        }

        




        void set_next(const shared_ptr<double_node>& other_node) {
            if(other_node)
            {
                next = other_node;
            }else
            {
                next.reset();
            }
        }

        




        void set_prior(const shared_ptr<double_node>& other_node) {
            if(other_node)
            {
                prior = other_node;
            }else
            {
                prior.reset();
            }
        }



    private:
        value_type value;
        shared_ptr<double_node> next;
        shared_ptr<double_node> prior;
    };
}

