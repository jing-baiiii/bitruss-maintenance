






#pragma once
#include "container/list_iterator.hpp"

namespace scnu
{
    



    template <typename node_type>
    class list_backward_iterator: public  list_iterator<node_type>{
    public:
        



        explicit list_backward_iterator(const node_type& position):
                list_iterator<node_type>(position)
        {

        }

        



        list_iterator<node_type>& operator++()
        {
            list_iterator<node_type>::iter = list_iterator<node_type>::iter->get_prior();
            return *this;
        }
    };


    



    template<typename node_type>
    class list_backward_iterator_range
    {
    public:
        




        list_backward_iterator_range(const node_type& other_from,
                                    const node_type& other_to):
                from (other_from), to(other_to)
        {

        }

        



        list_backward_iterator<node_type> begin()
        {
            return from;
        }

        



        list_backward_iterator<node_type> end()
        {
            return to;
        }
    private:
        list_backward_iterator<node_type> from;
        list_backward_iterator<node_type> to;
    };
}


