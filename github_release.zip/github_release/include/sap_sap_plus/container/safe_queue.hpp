







#pragma once
#include "container/container_utility.h"

namespace scnu
{
    



    template<typename value_type>
    class safe_queue {
    public:
        


        safe_queue() = default;


        



        safe_queue(const safe_queue& other_safe_queue)
        {
            lock_guard<mutex> lg(queue_mutex);
            data_queue = other_safe_queue.data_queue;
        }
        
        safe_queue& operator=(const safe_queue&)= delete;

        



        bool empty() const
        {
            lock_guard<mutex> lg(queue_mutex);
            return data_queue.empty();
        }

        



        void push(value_type new_value)
        {
            lock_guard<mutex> lg(queue_mutex);
            data_queue.push(move(new_value));
            mDataCondition.notify_one();
        }

        




        bool try_pop(value_type& value)
        {
            lock_guard<mutex> lg(queue_mutex);
            if(data_queue.empty())
            {
                return false;
            }
            value = std::move(data_queue.front());
            data_queue.pop();
            return true;
        }

        



        shared_ptr<value_type> try_pop()
        {
            lock_guard<mutex> lg(queue_mutex);
            if(data_queue.empty())
            {
                return shared_ptr<value_type>();
            }
            auto result = make_shared<value_type>(data_queue.front());
            data_queue.pop();
            return result;
        }

        



        void wait_and_pop(value_type& value)
        {
            unique_lock<mutex> ul(queue_mutex);
            mDataCondition.wait(ul, [this]{ return !data_queue.empty();});
            value = data_queue.front();
            data_queue.pop();
            ul.unlock();
        }

        



        shared_ptr<value_type> wait_and_pop()
        {
            unique_lock<mutex> ul(queue_mutex);
            mDataCondition.wait(ul, [this]{ return !data_queue.empty();});
            auto result = make_shared<value_type>(data_queue.front());
            data_queue.pop();
            ul.unlock();
            return result;
        }

    private:
        mutable mutex queue_mutex;
        queue<value_type> data_queue;
        condition_variable mDataCondition;
    };
};



