






#pragma once
#include "container/container_utility.h"

namespace scnu
{
    



    template<typename value_type>
    class safe_unordered_set
    {
    public:
        



        auto begin()
        {
            return data_set.begin();
        }

        


        void clear()
        {
            lock_guard<mutex> lg(set_mutex);
            data_set.clear();
        }

        




        bool count(value_type value)
        {
            lock_guard<mutex> lg(set_mutex);
            return data_set.count(value);
        }

        



        bool empty()
        {
            lock_guard<mutex> lg(set_mutex);
            return data_set.empty();
        }

        



        auto end()
        {
            return data_set.end();
        }

        



        void erase(value_type value)
        {
            lock_guard<mutex> lg(set_mutex);
            data_set.erase(value);
        }

        



        void insert(value_type value)
        {
            lock_guard<mutex> lg(set_mutex);
            data_set.insert(value);
        }

        



        uint32_t size()
        {
            lock_guard<mutex> lg(set_mutex);
            return data_set.size();
        }

    private:
        mutable mutex set_mutex;
        unordered_set<value_type> data_set;
    };
}
