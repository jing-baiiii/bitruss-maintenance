






#pragma once
#include "container/container_utility.h"

namespace scnu
{
    




    template <typename key_type, typename value_type>
    class safe_map
    {
    public:
        





        value_type at(key_type key)
        {
            lock_guard<mutex> lg(map_mutex);
            return data_map.at(key);
        }

        



        auto begin()
        {
            lock_guard<mutex> lg(map_mutex);
            return data_map.begin();
        }

        


        void clear()
        {
            lock_guard<mutex> lg(map_mutex);
            return data_map.clear();
        }

        




        bool count(key_type key)
        {
            lock_guard<mutex> lg(map_mutex);
            return data_map.count(key);
        }

        


        void empty()
        {
            lock_guard<mutex> lg(map_mutex);
            return data_map.empty();
        }

        



        auto end()
        {
            lock_guard<mutex> lg(map_mutex);
            return data_map.end();
        }


        



        void erase(key_type key)
        {
            lock_guard<mutex> lg(map_mutex);
            data_map.erase(key);
        }


        



        void insert(const pair<key_type,value_type>& p)
        {
            lock_guard<mutex> lg(map_mutex);
            data_map.insert(p);
        }

        





        void set_value(key_type key, value_type value)
        {
            lock_guard<mutex> lg(map_mutex);
            data_map.at(key) = value;
        }

        



        uint32_t size()
        {
            lock_guard<mutex> lg(map_mutex);
            return data_map.size();
        }

    private:
        mutable mutex map_mutex;
        unordered_map<key_type,value_type> data_map;
    };
}


