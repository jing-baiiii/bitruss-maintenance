







#pragma once
#include "container/double_node.hpp"
#include "container/list_forward_iterator.hpp"
#include "container/list_backward_iterator.hpp"

namespace scnu
{
    



    template<typename value_type>
    class double_list {
        using backward_iterator = list_backward_iterator<shared_ptr<double_node<value_type>>>;
        using forward_iterator = list_forward_iterator<shared_ptr<double_node<value_type>>>;
        using iterator = list_iterator<shared_ptr<double_node<value_type>>>;
    public:
        double_list():head(shared_ptr<double_node<value_type>>()),rear(shared_ptr<double_node<value_type>>()){

        }

        forward_iterator begin()
        {
            return forward_iterator(head);
        }
        



        void clear() {
            head.reset();
            rear.reset();
        }

        



        bool empty() {
            if(head)
            {
                return false;
            }
            return true;
        }

        forward_iterator end()
        {
            return forward_iterator(shared_ptr<double_node<value_type>>());
        }

        




        shared_ptr<double_node<value_type>> find(value_type value)
        {
            auto node = head;
            while (node)
            {
                if(node->get_value() == value)
                {
                    break;
                }
                node = node->get_next();
            }
            return node;
        }

        



        shared_ptr<double_node<value_type>> get_head() {
            return head;
        }

        



        shared_ptr<double_node<value_type>> get_rear() {
            return rear;
        }

        




        shared_ptr<double_node<value_type>> left_insert(value_type value) {
            auto node = make_shared<double_node<value_type>>(value);
            if (!head) {
                rear = node;
            } else {
                node->set_next(head);
                head->set_prior(node);
            }
            head = node;
            return node;
        }

        



        void left_insert(const shared_ptr<double_node<value_type>>& node) {
            


            node->set_prior(nullptr);
            node->set_next(nullptr);

            if (!head) {
                rear = node;
            } else {
                node->set_next(head);
                head->set_prior(node);
            }
            head = node;
        }

        backward_iterator rbegin()
        {
            return backward_iterator(rear);
        }

        backward_iterator rend()
        {
            return backward_iterator(shared_ptr<double_node<value_type>>());
        }

        




        shared_ptr<double_node<value_type>> right_insert(uint32_t value) {
            auto node = make_shared<double_node<value_type>>(value);
            if (!rear) {
                head = node;
            } else {
                rear->set_next(node);
                node->set_prior(rear);
            }
            rear = node;
            return node;
        }

        



        void right_insert(const shared_ptr<double_node<value_type>>& node) {
            


            node->set_prior(nullptr);
            node->set_next(nullptr);

            if (!rear) {
                head = node;
            } else {
                rear->set_next(node);
                node->set_prior(rear);
            }
            rear = node;
        }

        





        void right_insert(const shared_ptr<double_node<value_type>>& start,
                          const shared_ptr<double_node<value_type>>& end) {
            


             start->set_prior(nullptr);
             end->set_next(nullptr);

            if (!rear) {
                head = start;
            } else {
                rear->set_next(start);
                start->set_prior(rear);
            }
            rear = end;
        }

        



        void set_rear(const shared_ptr<double_node<value_type>>& node) {
            rear = node;
        }

        



        void set_head(const shared_ptr<double_node<value_type>>& node) {
            head = node;
        }

        




        void remove(const shared_ptr<double_node<value_type>>& node) {
            if (head == rear) {
                


                this->head.reset();
                this->rear.reset();
            } else {
                if (node == head) {
                    


                    head = head->get_next();
                    head->set_prior(nullptr);
                } else if (node == rear) {
                    


                    rear = rear->get_prior();
                    rear->set_next(nullptr);
                } else {
                    


                    auto next_node = node->get_next();
                    auto prior_node = node->get_prior();
                    prior_node->set_next(next_node);
                    next_node->set_prior(prior_node);
                }
            }
        }

         





        bool remove(value_type value) {
            auto node = find(value);
            


            if(!node)
            {
                return false;
            }
            remove(node);
            return true;
        }

    private:
        shared_ptr<double_node<value_type>> head;
        shared_ptr<double_node<value_type>> rear;
    };
}


