







#pragma once
#include "container/container_utility.h"
namespace scnu {
    



    template<typename node_type>
    class list_iterator {
    public:
        



        explicit list_iterator(const node_type &position) :
                iter(position) {

        }

        


        virtual ~list_iterator() = default;

        



        auto operator*() {
            return iter;
        }

        



        virtual list_iterator& operator++() = 0;


        




        bool operator!=(const list_iterator &other) const {
            return iter != other.iter;
        }

        




        bool operator==(const list_iterator &other) const {
            return iter == other.iter;
        }

    protected:
        node_type iter;
    };

    template<typename node_type>
    class list_iterator_range
    {
    public:
        list_iterator_range(const node_type& other_from,
                                    const node_type& other_to):
                from (other_from), to(other_to)
        {

        }

        list_iterator<node_type> begin()
        {
            return from;
        }

        list_iterator<node_type> end()
        {
            return to;
        }
    private:
        list_iterator<node_type> from;
        list_iterator<node_type> to;
    };
}




namespace std {
    template <typename node_type>
    struct iterator_traits<scnu::list_iterator<node_type>> {
        using iterator_category = std::forward_iterator_tag;
        using value_type = node_type;
    };
}



