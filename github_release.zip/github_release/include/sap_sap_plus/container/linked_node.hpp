







#pragma once
#include "container/container_utility.h"

namespace scnu
{
    



    template<typename value_type>
    class linked_node
    {
    public:
        explicit linked_node(value_type other_value): value(other_value)
        {

        }

        explicit linked_node(const shared_ptr<linked_node<value_type>>& other_node):
        value(other_node->value),next(other_node->next)
        {

        }

        ~linked_node()
        {
            next = shared_ptr<linked_node<value_type>>();
        }

        shared_ptr<linked_node<value_type>> get_next()
        {
            return next;
        }

        value_type get_value()
        {
            return value;
        }

        void set_next(const shared_ptr<linked_node>& next_node)
        {
            next = next_node;
        }

    private:
        value_type value;
        shared_ptr<linked_node> next;
    };
}


