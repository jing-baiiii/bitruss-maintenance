






#pragma once

#include "wing_utility.h"
#include "BE_index.h"













#ifdef BAI_FAST_SINGLE
  #define BAI_LOCK(x)     ((void)0)
  #define BAI_UNLOCK(x)   ((void)0)
#else
  #define BAI_LOCK(x)     (x)->lock()
  #define BAI_UNLOCK(x)   (x)->unlock()
#endif

namespace scnu {
    
    
    
    inline long long g_bai_wedge_probes = 0;
    inline long long g_bai_site_probes[24] = {0};
    inline const char* g_bai_site_names[24] = {
        "candidate_graph_finding",
        "candidate_graph_finding2",
        "edge_support_computation_u32a",
        "edge_support_computation_u32b",
        "edge_support_computation_void1",
        "edge_support_computation_void2",
        "edge_support_computation_void3",
        "edge_support_computation_void4",
        "insert",
        "insert2",
        "insert4",
        "left_index_construction1",
        "left_index_construction2",
        "remove",
        "remove2_a",
        "remove2_b",
        "remove3",
        "remove_unsatisfied_edges_1",
        "remove_unsatisfied_edges_3",
        "right_index_construction1",
        "right_index_construction2",
        "update_edge_wing_support_1",
        "update_single_wing",
        "update_single_wing2"
    };
    


    inline void bai_reset_probes() {
        g_bai_wedge_probes = 0;
        for (int i = 0; i < 24; ++i) g_bai_site_probes[i] = 0;
        bai_reset_ops();
    }
    class quasi_wing_maintenance {
    public:

        static void previous_k_max(const shared_ptr<unordered_map<shared_ptr<abstract_bipartite_edge>, uint32_t>> &edge_wing_map,
                                   uint32_t &k_max,
                                   const shared_ptr<thread_pool>& pool);




        static void init(const shared_ptr<unordered_map<shared_ptr<abstract_bipartite_edge>, uint32_t>> &edge_wing_map,
                         const shared_ptr<unordered_map<shared_ptr<abstract_bipartite_edge>,shared_ptr<mutex>>>& edge_mutex_map,
                         const shared_ptr<unordered_map<shared_ptr<abstract_bipartite_edge>, uint32_t>>& edge_rank_map,
                         const shared_ptr<unordered_map<shared_ptr<abstract_bipartite_edge>, uint32_t>>& edge_support_map,
                         const shared_ptr<unordered_map<shared_ptr<abstract_bipartite_edge>, uint32_t>> &WS,
                         const shared_ptr<thread_pool>& pool);


        static void init(const shared_ptr<unordered_map<shared_ptr<abstract_bipartite_edge>, uint32_t>> &edge_wing_map,
                         const shared_ptr<unordered_map<shared_ptr<abstract_bipartite_edge>,shared_ptr<mutex>>>& edge_mutex_map,
                         const shared_ptr<unordered_map<shared_ptr<abstract_bipartite_edge>, uint32_t>>& edge_rank_map,
                         const shared_ptr<unordered_map<shared_ptr<abstract_bipartite_edge>, uint32_t>>& edge_support_map,
                         const shared_ptr<thread_pool>& pool);


        static void insert(const shared_ptr<abstract_bipartite_graph> &G,
                           const shared_ptr<unordered_map<shared_ptr<abstract_bipartite_edge>,shared_ptr<mutex>>>& edge_mutex_map,
                           const shared_ptr<unordered_set<shared_ptr<abstract_bipartite_edge>>> &edge_set,
                           const shared_ptr<unordered_map<shared_ptr<abstract_bipartite_edge>, uint32_t>>& edge_rank_map,
                           const shared_ptr<unordered_map<shared_ptr<abstract_bipartite_edge>, uint32_t>>& edge_support_map,
                           const shared_ptr<unordered_map<shared_ptr<abstract_bipartite_edge>, uint32_t>> &edge_wing_map,
                           const shared_ptr<unordered_map<shared_ptr<abstract_bipartite_edge>, uint32_t>>& WS,
                           const shared_ptr<uint32_t>& previous_k_max,
                           const shared_ptr<thread_pool>& pool);

        static void insert2(const shared_ptr<abstract_bipartite_graph> &G,
                            const shared_ptr<unordered_map<shared_ptr<abstract_bipartite_edge>,shared_ptr<mutex>>>& edge_mutex_map,
                            const shared_ptr<unordered_set<shared_ptr<abstract_bipartite_edge>>> &edge_set,
                            const shared_ptr<unordered_map<shared_ptr<abstract_bipartite_edge>, uint32_t>>& edge_rank_map,
                            const shared_ptr<unordered_map<shared_ptr<abstract_bipartite_edge>, uint32_t>>& edge_support_map,
                            const shared_ptr<unordered_map<shared_ptr<abstract_bipartite_edge>, uint32_t>> &edge_wing_map,
                            const shared_ptr<unordered_map<shared_ptr<abstract_bipartite_edge>, uint32_t>>& WS,
                            const shared_ptr<uint32_t>& previous_k_max,
                            const shared_ptr<thread_pool>& pool);

        static void insert3(const shared_ptr<abstract_bipartite_graph> &G,
                            const shared_ptr<unordered_map<shared_ptr<abstract_bipartite_edge>, shared_ptr<mutex>>> &edge_mutex_map,
                            const shared_ptr<unordered_set<shared_ptr<abstract_bipartite_edge>>> &edge_set,
                            const shared_ptr<unordered_map<shared_ptr<abstract_bipartite_edge>, uint32_t>> &edge_rank_map,
                            const shared_ptr<unordered_map<shared_ptr<abstract_bipartite_edge>, uint32_t>> &candidate_edge_support_map,
                            const shared_ptr<unordered_map<shared_ptr<abstract_bipartite_edge>, uint32_t>> &edge_wing_map,
                            const shared_ptr<unordered_map<shared_ptr<abstract_bipartite_edge>, uint32_t>> &WS,
                            const shared_ptr<uint32_t> &previous_k_max,
                            const shared_ptr<thread_pool> &pool);

        static void insert4(const shared_ptr<abstract_bipartite_graph> &G,
                            const shared_ptr<unordered_map<shared_ptr<abstract_bipartite_edge>,shared_ptr<mutex>>>& edge_mutex_map,
                            const shared_ptr<unordered_set<shared_ptr<abstract_bipartite_edge>>> &edge_set,
                            const shared_ptr<unordered_map<shared_ptr<abstract_bipartite_edge>, uint32_t>>& edge_rank_map,
                            const shared_ptr<unordered_map<shared_ptr<abstract_bipartite_edge>, uint32_t>>& edge_support_map,
                            const shared_ptr<unordered_map<shared_ptr<abstract_bipartite_edge>, uint32_t>> &edge_wing_map,
                            const shared_ptr<unordered_map<shared_ptr<abstract_bipartite_edge>, uint32_t>>& WS,
                            const shared_ptr<unordered_map<uint32_t,shared_ptr<map<uint32_t,shared_ptr<unordered_set<uint32_t>>>>>> &WL,
                            const shared_ptr<uint32_t>& previous_k_max,
                            const shared_ptr<thread_pool>& pool);


        static void remove(const shared_ptr<abstract_bipartite_graph> &G,
                           const shared_ptr<unordered_map<shared_ptr<abstract_bipartite_edge>,shared_ptr<mutex>>>& edge_mutex_map,
                           const shared_ptr<unordered_set<shared_ptr<abstract_bipartite_edge>>> &edge_set,
                           const shared_ptr<unordered_map<shared_ptr<abstract_bipartite_edge>, uint32_t>>& edge_rank_map,
                           const shared_ptr<unordered_map<shared_ptr<abstract_bipartite_edge>, uint32_t>> &edge_wing_map,
                           const shared_ptr<unordered_map<shared_ptr<abstract_bipartite_edge>, uint32_t>>& WS,
                           const shared_ptr<uint32_t>& previous_k_max,
                           const shared_ptr<thread_pool>& pool);

        static void remove2(const shared_ptr<abstract_bipartite_graph> &G,
                            const shared_ptr<unordered_map<shared_ptr<abstract_bipartite_edge>,shared_ptr<mutex>>>& edge_mutex_map,
                            const shared_ptr<unordered_set<shared_ptr<abstract_bipartite_edge>>> &edge_set,
                            const shared_ptr<unordered_map<shared_ptr<abstract_bipartite_edge>, uint32_t>>& edge_rank_map,
                            const shared_ptr<unordered_map<shared_ptr<abstract_bipartite_edge>, uint32_t>> &edge_wing_map,
                            const shared_ptr<unordered_map<shared_ptr<abstract_bipartite_edge>, uint32_t>>& WS,
                            const shared_ptr<uint32_t>& previous_k_max,
                            const shared_ptr<thread_pool>& pool);


        static void remove3(const shared_ptr<abstract_bipartite_graph> &G,
                            const shared_ptr<unordered_map<shared_ptr<abstract_bipartite_edge>,shared_ptr<mutex>>>& edge_mutex_map,
                            const shared_ptr<unordered_set<shared_ptr<abstract_bipartite_edge>>> &edge_set,
                            const shared_ptr<unordered_map<shared_ptr<abstract_bipartite_edge>, uint32_t>>& edge_rank_map,
                            const shared_ptr<unordered_map<shared_ptr<abstract_bipartite_edge>, uint32_t>> &edge_wing_map,
                            const shared_ptr<unordered_map<shared_ptr<abstract_bipartite_edge>, uint32_t>>& WS,
                            const shared_ptr<uint32_t>& previous_k_max,
                            const shared_ptr<thread_pool>& pool);

        static void remove4(const shared_ptr<abstract_bipartite_graph> &G,
                            const shared_ptr<unordered_map<shared_ptr<abstract_bipartite_edge>,shared_ptr<mutex>>>& edge_mutex_map,
                            const shared_ptr<unordered_set<shared_ptr<abstract_bipartite_edge>>> &edge_set,
                            const shared_ptr<unordered_map<shared_ptr<abstract_bipartite_edge>, uint32_t>>& edge_rank_map,
                            const shared_ptr<unordered_map<shared_ptr<abstract_bipartite_edge>, uint32_t>> &edge_wing_map,
                            const shared_ptr<unordered_map<shared_ptr<abstract_bipartite_edge>, uint32_t>>& WS,
                            const shared_ptr<unordered_map<uint32_t,shared_ptr<map<uint32_t,shared_ptr<unordered_set<uint32_t>>>>>> &WL,
                            const shared_ptr<uint32_t>& previous_k_max,
                            const shared_ptr<thread_pool>& pool);

    private:


        static void candidate_graph_finding(const shared_ptr<abstract_bipartite_graph> &G,
                                            const shared_ptr<unordered_map<shared_ptr<abstract_bipartite_edge>,shared_ptr<mutex>>> &edge_mutex_map,
                                            const shared_ptr<unordered_map<shared_ptr<abstract_bipartite_edge>,uint32_t>>& edge_rank_map,
                                            const shared_ptr<unordered_map<shared_ptr<abstract_bipartite_edge>, uint32_t>> &edge_wing_map,
                                            const shared_ptr<unordered_set<shared_ptr<abstract_bipartite_edge>>> &edge_set,
                                            const shared_ptr<unordered_set<shared_ptr<abstract_bipartite_edge>>> &candidate_edge_set,
                                            const shared_ptr<unordered_map<shared_ptr<abstract_bipartite_edge>, uint32_t>> &candidate_edge_support_map,
                                            const shared_ptr<unordered_map<shared_ptr<abstract_bipartite_edge>, uint32_t>> &WS,
                                            uint32_t k,
                                            const shared_ptr<thread_pool>& pool);

        static void candidate_graph_finding2(const shared_ptr<abstract_bipartite_graph> &G,
                                             const shared_ptr<unordered_map<shared_ptr<abstract_bipartite_edge>,shared_ptr<mutex>>> &edge_mutex_map,
                                             const shared_ptr<unordered_map<shared_ptr<abstract_bipartite_edge>,uint32_t>>& edge_rank_map,
                                             const shared_ptr<unordered_map<shared_ptr<abstract_bipartite_edge>, uint32_t>> &edge_wing_map,
                                             const shared_ptr<unordered_set<shared_ptr<abstract_bipartite_edge>>> &edge_set,
                                             const shared_ptr<unordered_set<shared_ptr<abstract_bipartite_edge>>> &candidate_edge_set,
                                             const shared_ptr<unordered_map<shared_ptr<abstract_bipartite_edge>, uint32_t>> &candidate_edge_support_map,
                                             const shared_ptr<unordered_map<shared_ptr<abstract_bipartite_edge>, uint32_t>> &WS,
                                             uint32_t k,
                                             const shared_ptr<thread_pool>& pool);

        static void candidate_graph_finding3(const shared_ptr<abstract_bipartite_graph> &G,
                                             const shared_ptr<BE_index>& bloom_index,
                                             const shared_ptr<unordered_map<shared_ptr<abstract_bipartite_edge>,shared_ptr<mutex>>> &edge_mutex_map,
                                             const shared_ptr<unordered_map<shared_ptr<abstract_bipartite_edge>,uint32_t>>& edge_rank_map,
                                             const shared_ptr<unordered_map<shared_ptr<abstract_bipartite_edge>, uint32_t>> &edge_wing_map,
                                             const shared_ptr<unordered_set<shared_ptr<abstract_bipartite_edge>>> &edge_set,
                                             const shared_ptr<unordered_set<shared_ptr<abstract_bipartite_edge>>> &candidate_edge_set,
                                             const shared_ptr<unordered_map<shared_ptr<abstract_bipartite_edge>, uint32_t>> &candidate_edge_support_map,
                                             const shared_ptr<unordered_map<shared_ptr<abstract_bipartite_edge>, uint32_t>> &WS,
                                             uint32_t k,
                                             const shared_ptr<thread_pool>& pool);

        static void candidate_graph_finding4(const shared_ptr<abstract_bipartite_graph> &G,
                                             const shared_ptr<unordered_map<shared_ptr<abstract_bipartite_edge>,shared_ptr<mutex>>> &edge_mutex_map,
                                             const shared_ptr<unordered_map<shared_ptr<abstract_bipartite_edge>,uint32_t>>& edge_rank_map,
                                             const shared_ptr<unordered_map<shared_ptr<abstract_bipartite_edge>, uint32_t>> &edge_wing_map,
                                             const shared_ptr<unordered_set<shared_ptr<abstract_bipartite_edge>>> &edge_set,
                                             const shared_ptr<unordered_set<shared_ptr<abstract_bipartite_edge>>> &candidate_edge_set,
                                             const shared_ptr<unordered_map<shared_ptr<abstract_bipartite_edge>, uint32_t>> &candidate_edge_support_map,
                                             const shared_ptr<unordered_map<shared_ptr<abstract_bipartite_edge>, uint32_t>> &WS,
                                             const shared_ptr<unordered_map<uint32_t,shared_ptr<map<uint32_t,shared_ptr<unordered_set<uint32_t>>>>>> &WL,
                                             uint32_t k,
                                             const shared_ptr<thread_pool>& pool);

        static uint32_t edge_support_computation(const shared_ptr<abstract_bipartite_graph> &G,
                                                 const shared_ptr<abstract_bipartite_edge> &e,
                                                 const shared_ptr<unordered_map<shared_ptr<abstract_bipartite_edge>, uint32_t>> &edge_wing_map,
                                                 uint32_t k);


        static uint32_t edge_support_computation(const shared_ptr<abstract_bipartite_graph> &G,
                                                 const shared_ptr<abstract_bipartite_edge> &e,
                                                 const shared_ptr<unordered_map<shared_ptr<abstract_bipartite_edge>, uint32_t>> &edge_wing_map,
                                                 const shared_ptr<unordered_map<shared_ptr<abstract_bipartite_edge>, uint32_t>> &WS,
                                                 uint32_t k);

        static void edge_support_computation(const shared_ptr<abstract_bipartite_graph> &G,
                                             const shared_ptr<unordered_set<shared_ptr<abstract_bipartite_edge>>> &edge_set,
                                             const shared_ptr<unordered_map<shared_ptr<abstract_bipartite_edge>, shared_ptr<mutex>>> &edge_mutex_map,
                                             const shared_ptr<unordered_map<shared_ptr<abstract_bipartite_edge>, uint32_t>> &edge_support_map,
                                             const shared_ptr<unordered_map<uint32_t, uint32_t>> &vertex_priority_map,
                                             const shared_ptr<thread_pool> &pool);

        static shared_ptr<BE_index> index_construction(const shared_ptr<abstract_bipartite_graph> &G,
                                                       const shared_ptr<unordered_map<shared_ptr<abstract_bipartite_edge>, shared_ptr<mutex>>> &edge_mutex_map,
                                                       const shared_ptr<thread_pool> &pool);

        static void left_index_construction(const shared_ptr<abstract_bipartite_graph> &G,
                                            const shared_ptr<unordered_map<uint32_t, uint32_t>> &vertex_priority,
                                            const shared_ptr<unordered_map<shared_ptr<abstract_bipartite_edge>, uint32_t>> &edge_support_map,
                                            const shared_ptr<unordered_map<shared_ptr<abstract_bipartite_edge>,shared_ptr<mutex>>>& edge_mutex_map,
                                            const shared_ptr<BE_index> &bloom_index,
                                            const shared_ptr<thread_pool>& pool);


        static uint32_t partial_wing_decomposition(const shared_ptr<abstract_bipartite_graph> &G,
                                                   const shared_ptr<unordered_map<shared_ptr<abstract_bipartite_edge>,shared_ptr<mutex>>>& edge_mutex_map,
                                                   const shared_ptr<unordered_map<shared_ptr<abstract_bipartite_edge>,uint32_t>>& edge_rank_map,
                                                   const shared_ptr<unordered_map<shared_ptr<abstract_bipartite_edge>, uint32_t>> &edge_wing_map,
                                                   const shared_ptr<unordered_set<shared_ptr<abstract_bipartite_edge>>> &candidate_edge_set,
                                                   const shared_ptr<unordered_map<shared_ptr<abstract_bipartite_edge>, uint32_t>> &candidate_edge_support_map,
                                                   uint32_t k,
                                                   const shared_ptr<thread_pool>& pool);

        static uint32_t partial_wing_decomposition2(const shared_ptr<abstract_bipartite_graph> &G,
                                                    const shared_ptr<unordered_map<shared_ptr<abstract_bipartite_edge>,shared_ptr<mutex>>>& edge_mutex_map,
                                                    const shared_ptr<unordered_map<shared_ptr<abstract_bipartite_edge>,uint32_t>>& edge_rank_map,
                                                    const shared_ptr<unordered_map<shared_ptr<abstract_bipartite_edge>, uint32_t>> &edge_wing_map,
                                                    const shared_ptr<unordered_set<shared_ptr<abstract_bipartite_edge>>> &candidate_edge_set,
                                                    const shared_ptr<unordered_map<shared_ptr<abstract_bipartite_edge>, uint32_t>> &candidate_edge_support_map,
                                                    const shared_ptr<unordered_map<shared_ptr<abstract_bipartite_edge>, uint32_t>> &WS,
                                                    uint32_t k,
                                                    const shared_ptr<thread_pool>& pool);

        static uint32_t partial_wing_decomposition3(const shared_ptr<abstract_bipartite_graph> &G,
                                                    const shared_ptr<BE_index> &bloom_index,
                                                    const shared_ptr<unordered_map<shared_ptr<abstract_bipartite_edge>, shared_ptr<mutex>>> &edge_mutex_map,
                                                    const shared_ptr<unordered_map<shared_ptr<abstract_bipartite_edge>, uint32_t>> &edge_rank_map,
                                                    const shared_ptr<unordered_map<shared_ptr<abstract_bipartite_edge>, uint32_t>> &edge_wing_map,
                                                    const shared_ptr<unordered_set<shared_ptr<abstract_bipartite_edge>>> &candidate_edge_set,
                                                    const shared_ptr<unordered_map<shared_ptr<abstract_bipartite_edge>, uint32_t>> &candidate_edge_support_map,
                                                    const shared_ptr<unordered_map<shared_ptr<abstract_bipartite_edge>, uint32_t>> &WS,
                                                    uint32_t k,
                                                    const shared_ptr<thread_pool> &pool);

        static uint32_t partial_wing_decomposition4(const shared_ptr<abstract_bipartite_graph> &G,
                                                    const shared_ptr<unordered_map<shared_ptr<abstract_bipartite_edge>,shared_ptr<mutex>>>& edge_mutex_map,
                                                    const shared_ptr<unordered_map<shared_ptr<abstract_bipartite_edge>,uint32_t>>& edge_rank_map,
                                                    const shared_ptr<unordered_map<shared_ptr<abstract_bipartite_edge>, uint32_t>> &edge_wing_map,
                                                    const shared_ptr<unordered_set<shared_ptr<abstract_bipartite_edge>>> &candidate_edge_set,
                                                    const shared_ptr<unordered_map<shared_ptr<abstract_bipartite_edge>, uint32_t>> &candidate_edge_support_map,
                                                    const shared_ptr<unordered_map<shared_ptr<abstract_bipartite_edge>, uint32_t>> &WS,
                                                    const shared_ptr<unordered_map<uint32_t,shared_ptr<map<uint32_t,shared_ptr<unordered_set<uint32_t>>>>>> &WL,
                                                    uint32_t k,
                                                    const shared_ptr<thread_pool>& pool);


        static void remove_unsatisfied_edges(const shared_ptr<abstract_bipartite_graph> &G,
                                             const shared_ptr<unordered_map<shared_ptr<abstract_bipartite_edge>, shared_ptr<mutex>>> &edge_mutex_map,
                                             const shared_ptr<unordered_map<shared_ptr<abstract_bipartite_edge>, uint32_t>> &edge_rank_map,
                                             const shared_ptr<unordered_map<shared_ptr<abstract_bipartite_edge>, uint32_t>> &edge_wing_map,
                                             const shared_ptr<unordered_set<shared_ptr<abstract_bipartite_edge>>> &current_edge_set,
                                             const shared_ptr<unordered_set<shared_ptr<abstract_bipartite_edge>>> &candidate_edge_set,
                                             const shared_ptr<unordered_map<shared_ptr<abstract_bipartite_edge>,uint32_t>>& candidate_edge_support_map,
                                             const shared_ptr<unordered_set<shared_ptr<abstract_bipartite_edge>>> &evicted_edge_set,
                                             uint32_t k,
                                             const shared_ptr<thread_pool> &pool);

        static void remove_unsatisfied_edges(const shared_ptr<abstract_bipartite_graph> &G,
                                             const shared_ptr<unordered_map<shared_ptr<abstract_bipartite_edge>, shared_ptr<mutex>>> &edge_mutex_map,
                                             const shared_ptr<unordered_map<shared_ptr<abstract_bipartite_edge>, uint32_t>> &edge_rank_map,
                                             const shared_ptr<unordered_map<shared_ptr<abstract_bipartite_edge>, uint32_t>> &edge_wing_map,
                                             const shared_ptr<unordered_set<shared_ptr<abstract_bipartite_edge>>> &current_edge_set,
                                             const shared_ptr<unordered_set<shared_ptr<abstract_bipartite_edge>>> &candidate_edge_set,
                                             const shared_ptr<unordered_map<shared_ptr<abstract_bipartite_edge>,uint32_t>>& candidate_edge_support_map,
                                             const shared_ptr<unordered_set<shared_ptr<abstract_bipartite_edge>>> &evicted_edge_set,
                                             const shared_ptr<unordered_map<uint32_t,shared_ptr<map<uint32_t,shared_ptr<unordered_set<uint32_t>>>>>> &WL,
                                             uint32_t k,
                                             const shared_ptr<thread_pool> &pool);



        static void remove_unsatisfied_edges(const shared_ptr<abstract_bipartite_graph> &G,
                                             const shared_ptr<unordered_map<shared_ptr<abstract_bipartite_edge>, shared_ptr<mutex>>> &edge_mutex_map,
                                             const shared_ptr<unordered_map<shared_ptr<abstract_bipartite_edge>, uint32_t>> &edge_rank_map,
                                             const shared_ptr<unordered_map<shared_ptr<abstract_bipartite_edge>, uint32_t>> &edge_wing_map,
                                             const shared_ptr<unordered_set<shared_ptr<abstract_bipartite_edge>>> &current_edge_set,
                                             const shared_ptr<unordered_set<shared_ptr<abstract_bipartite_edge>>> &candidate_edge_set,
                                             const shared_ptr<unordered_map<shared_ptr<abstract_bipartite_edge>,uint32_t>>& candidate_edge_support_map,
                                             const shared_ptr<unordered_set<shared_ptr<abstract_bipartite_edge>>> &rectangle_edge_set,
                                             const shared_ptr<unordered_map<shared_ptr<abstract_bipartite_edge>, shared_ptr<unordered_set<shared_ptr<abstract_bipartite_edge>>>>>& next_edge_map,
                                             const shared_ptr<unordered_set<shared_ptr<abstract_bipartite_edge>>> &evicted_edge_set,
                                             uint32_t k,
                                             const shared_ptr<thread_pool> &pool);

        static void remove_unsatisfied_edges(const shared_ptr<abstract_bipartite_graph> &G,
                                             const shared_ptr<unordered_map<shared_ptr<abstract_bipartite_edge>, shared_ptr<mutex>>> &edge_mutex_map,
                                             const shared_ptr<unordered_map<shared_ptr<abstract_bipartite_edge>, uint32_t>> &edge_rank_map,
                                             const shared_ptr<unordered_map<shared_ptr<abstract_bipartite_edge>, uint32_t>> &edge_wing_map,
                                             const shared_ptr<unordered_set<shared_ptr<abstract_bipartite_edge>>> &current_edge_set,
                                             const shared_ptr<unordered_set<shared_ptr<abstract_bipartite_edge>>> &candidate_edge_set,
                                             const shared_ptr<unordered_map<shared_ptr<abstract_bipartite_edge>,uint32_t>>& candidate_edge_support_map,
                                             const shared_ptr<unordered_set<shared_ptr<abstract_bipartite_edge>>> &rectangle_edge_set,
                                             const shared_ptr<unordered_map<shared_ptr<abstract_bipartite_edge>, shared_ptr<unordered_set<shared_ptr<abstract_bipartite_edge>>>>>& next_edge_map,
                                             const shared_ptr<unordered_set<shared_ptr<abstract_bipartite_edge>>> &evicted_edge_set,
                                             const shared_ptr<unordered_map<uint32_t,shared_ptr<map<uint32_t,shared_ptr<unordered_set<uint32_t>>>>>> &WL,
                                             uint32_t k,
                                             const shared_ptr<thread_pool> &pool);

        static void remove_unsatisfied_edges(const shared_ptr<abstract_bipartite_graph> &G,
                                             const shared_ptr<BE_index> &bloom_index,
                                             const shared_ptr<unordered_map<shared_ptr<abstract_bipartite_edge>, shared_ptr<mutex>>> &edge_mutex_map,
                                             const shared_ptr<unordered_map<shared_ptr<abstract_bipartite_edge>, uint32_t>> &edge_rank_map,
                                             const shared_ptr<unordered_map<shared_ptr<abstract_bipartite_edge>, uint32_t>> &edge_wing_map,
                                             const shared_ptr<unordered_set<shared_ptr<abstract_bipartite_edge>>> &current_edge_set,
                                             const shared_ptr<unordered_set<shared_ptr<abstract_bipartite_edge>>> &candidate_edge_set,
                                             const shared_ptr<unordered_map<shared_ptr<abstract_bipartite_edge>, uint32_t>> &candidate_edge_support_map,
                                             const shared_ptr<unordered_set<shared_ptr<abstract_bipartite_edge>>> &evicted_edge_set,
                                             uint32_t k,
                                             const shared_ptr<thread_pool> &pool);

        static void remove_unsatisfied_edges(const shared_ptr<abstract_bipartite_graph> &G,
                                             const shared_ptr<BE_index> &bloom_index,
                                             const shared_ptr<unordered_map<shared_ptr<abstract_bipartite_edge>, shared_ptr<mutex>>> &edge_mutex_map,
                                             const shared_ptr<unordered_map<shared_ptr<abstract_bipartite_edge>, uint32_t>> &edge_rank_map,
                                             const shared_ptr<unordered_map<shared_ptr<abstract_bipartite_edge>, uint32_t>> &edge_wing_map,
                                             const shared_ptr<unordered_set<shared_ptr<abstract_bipartite_edge>>> &current_edge_set,
                                             const shared_ptr<unordered_set<shared_ptr<abstract_bipartite_edge>>> &candidate_edge_set,
                                             const shared_ptr<unordered_map<shared_ptr<abstract_bipartite_edge>,uint32_t>>& candidate_edge_support_map,
                                             const shared_ptr<unordered_set<shared_ptr<abstract_bipartite_edge>>> &rectangle_edge_set,
                                             const shared_ptr<unordered_map<shared_ptr<abstract_bipartite_edge>, shared_ptr<unordered_set<shared_ptr<abstract_bipartite_edge>>>>>& next_edge_map,
                                             const shared_ptr<unordered_set<shared_ptr<abstract_bipartite_edge>>> &evicted_edge_set,
                                             uint32_t k,
                                             const shared_ptr<thread_pool> &pool);

        static void right_index_construction(const shared_ptr<abstract_bipartite_graph> &G,
                                             const shared_ptr<unordered_map<uint32_t,uint32_t>>& vertex_priority_map,
                                             const shared_ptr<unordered_map<shared_ptr<abstract_bipartite_edge>, uint32_t>> &edge_support_map,
                                             const shared_ptr<unordered_map<shared_ptr<abstract_bipartite_edge>,shared_ptr<mutex>>>& edge_mutex_map,
                                             const shared_ptr<BE_index> &bloom_index,
                                             const shared_ptr<thread_pool>& pool);


        static void set_edge_rank(const shared_ptr<unordered_set<shared_ptr<abstract_bipartite_edge>>> &edge_set,
                                  const shared_ptr<unordered_map<shared_ptr<abstract_bipartite_edge>, uint32_t>> &edge_rank_map,
                                  const shared_ptr<uint32_t> &rank_id);

        static void update_single_wing(const shared_ptr<abstract_bipartite_graph> &G,
                                       const shared_ptr<unordered_map<shared_ptr<abstract_bipartite_edge>, shared_ptr<mutex>>> &edge_mutex_map,
                                       const shared_ptr<unordered_map<shared_ptr<abstract_bipartite_edge>, uint32_t>> &edge_rank_map,
                                       const shared_ptr<unordered_map<shared_ptr<abstract_bipartite_edge>, uint32_t>> &edge_wing_map,
                                       const shared_ptr<unordered_set<shared_ptr<abstract_bipartite_edge>>> &edge_set,
                                       const shared_ptr<unordered_map<shared_ptr<abstract_bipartite_edge>, uint32_t>> &WS,
                                       const shared_ptr<unordered_set<shared_ptr<abstract_bipartite_edge>>>& evicted_edge_set,
                                       uint32_t k,
                                       const shared_ptr<thread_pool> &pool);

        static void update_single_wing2(const shared_ptr<abstract_bipartite_graph> &G,
                                        const shared_ptr<unordered_map<shared_ptr<abstract_bipartite_edge>, shared_ptr<mutex>>> &edge_mutex_map,
                                        const shared_ptr<unordered_map<shared_ptr<abstract_bipartite_edge>, uint32_t>> &edge_rank_map,
                                        const shared_ptr<unordered_map<shared_ptr<abstract_bipartite_edge>, uint32_t>> &edge_wing_map,
                                        const shared_ptr<unordered_set<shared_ptr<abstract_bipartite_edge>>> &edge_set,
                                        const shared_ptr<unordered_map<shared_ptr<abstract_bipartite_edge>, uint32_t>> &WS,
                                        const shared_ptr<unordered_set<shared_ptr<abstract_bipartite_edge>>>& evicted_edge_set,
                                        uint32_t k,
                                        const shared_ptr<thread_pool> &pool);

        static void update_single_wing3(const shared_ptr<abstract_bipartite_graph> &G,
                                        const shared_ptr<BE_index> &bloom_index,
                                        const shared_ptr<unordered_map<shared_ptr<abstract_bipartite_edge>, shared_ptr<mutex>>> &edge_mutex_map,
                                        const shared_ptr<unordered_map<shared_ptr<abstract_bipartite_edge>, uint32_t>> &edge_rank_map,
                                        const shared_ptr<unordered_map<shared_ptr<abstract_bipartite_edge>, uint32_t>> &edge_wing_map,
                                        const shared_ptr<unordered_set<shared_ptr<abstract_bipartite_edge>>> &edge_set,
                                        const shared_ptr<unordered_map<shared_ptr<abstract_bipartite_edge>, uint32_t>> &WS,
                                        const shared_ptr<unordered_set<shared_ptr<abstract_bipartite_edge>>> &evicted_edge_set,
                                        uint32_t k,
                                        const shared_ptr<thread_pool> &pool);

        static void update_single_wing4(const shared_ptr<abstract_bipartite_graph> &G,
                                        const shared_ptr<unordered_map<shared_ptr<abstract_bipartite_edge>, shared_ptr<mutex>>> &edge_mutex_map,
                                        const shared_ptr<unordered_map<shared_ptr<abstract_bipartite_edge>, uint32_t>> &edge_rank_map,
                                        const shared_ptr<unordered_map<shared_ptr<abstract_bipartite_edge>, uint32_t>> &edge_wing_map,
                                        const shared_ptr<unordered_set<shared_ptr<abstract_bipartite_edge>>> &edge_set,
                                        const shared_ptr<unordered_map<shared_ptr<abstract_bipartite_edge>, uint32_t>> &WS,
                                        const shared_ptr<unordered_map<uint32_t,shared_ptr<map<uint32_t,shared_ptr<unordered_set<uint32_t>>>>>> &WL,
                                        const shared_ptr<unordered_set<shared_ptr<abstract_bipartite_edge>>>& evicted_edge_set,
                                        uint32_t k,
                                        const shared_ptr<thread_pool> &pool);



        static void update_edge_wing_support(const shared_ptr<abstract_bipartite_graph>& G,
                                             const shared_ptr<unordered_map<shared_ptr<abstract_bipartite_edge>, shared_ptr<mutex>>> &edge_mutex_map,
                                             const shared_ptr<unordered_map<shared_ptr<abstract_bipartite_edge>, uint32_t>> &edge_rank_map,
                                             const shared_ptr<unordered_map<shared_ptr<abstract_bipartite_edge>, uint32_t>> &edge_wing_map,
                                             const shared_ptr<unordered_map<shared_ptr<abstract_bipartite_edge>, uint32_t>> &WS,
                                             const shared_ptr<unordered_set<shared_ptr<abstract_bipartite_edge>>> &candidate_edge_set,
                                             uint32_t k,
                                             const shared_ptr<thread_pool> &pool);

        static void update_edge_wing_support(const shared_ptr<abstract_bipartite_graph> &G,
                                             const shared_ptr<BE_index> &bloom_index,
                                             const shared_ptr<unordered_map<shared_ptr<abstract_bipartite_edge>, shared_ptr<mutex>>> &edge_mutex_map,
                                             const shared_ptr<unordered_map<shared_ptr<abstract_bipartite_edge>, uint32_t>> &edge_rank_map,
                                             const shared_ptr<unordered_map<shared_ptr<abstract_bipartite_edge>, uint32_t>> &edge_wing_map,
                                             const shared_ptr<unordered_map<shared_ptr<abstract_bipartite_edge>, uint32_t>> &WS,
                                             const shared_ptr<unordered_set<shared_ptr<abstract_bipartite_edge>>> &candidate_edge_set,
                                             uint32_t k,
                                             const shared_ptr<thread_pool> &pool);

        static void update_edge_wing_support(const shared_ptr<abstract_bipartite_graph>& G,
                                             const shared_ptr<unordered_map<shared_ptr<abstract_bipartite_edge>, shared_ptr<mutex>>> &edge_mutex_map,
                                             const shared_ptr<unordered_map<shared_ptr<abstract_bipartite_edge>, uint32_t>> &edge_rank_map,
                                             const shared_ptr<unordered_map<shared_ptr<abstract_bipartite_edge>, uint32_t>> &edge_wing_map,
                                             const shared_ptr<unordered_map<shared_ptr<abstract_bipartite_edge>, uint32_t>> &WS,
                                             const shared_ptr<unordered_map<uint32_t,shared_ptr<map<uint32_t,shared_ptr<unordered_set<uint32_t>>>>>> &WL,
                                             const shared_ptr<unordered_set<shared_ptr<abstract_bipartite_edge>>> &candidate_edge_set,
                                             uint32_t k,
                                             const shared_ptr<thread_pool> &pool);

        static void wl_move(const shared_ptr<abstract_bipartite_edge> &e,
                            const shared_ptr<unordered_map<uint32_t,shared_ptr<map<uint32_t,shared_ptr<unordered_set<uint32_t>>>>>> &WL,
                            uint32_t source,
                            uint32_t destination);



        static void vertex_priority_computation(const shared_ptr<abstract_bipartite_graph>& G,
                                                const shared_ptr<unordered_map<uint32_t,uint32_t>>& vertex_priority_map,
                                                const shared_ptr<thread_pool> &pool);

    };
}
