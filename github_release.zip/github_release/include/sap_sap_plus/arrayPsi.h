




























#ifndef ARRAY_PSI_H
#define ARRAY_PSI_H
#include <vector>
#include <algorithm>
#include <functional>
using namespace std;



static void arrayBuildPsi(BEGraphLoMem &BEG, const vector<intE> &phi, vector<intE> &psi)
{
    const intE n = BEG.numU;              
    psi.assign(n, 0);

    
    vector<intE> wlev(BEG.bloomEI.size(), 0);
    for (intB b = 0; b < BEG.numV; b++) {
        const intB lo = BEG.bloomVI[b];
        const intE d  = BEG.bloomDegree[b];
        if (d <= 0) continue;
        for (intE j = 0; j < d; j++) {
            const intE c1 = BEG.bloomEI[lo + j].first;
            const intE c2 = BEG.bloomEI[lo + j].second;
            const intE l1 = (c1 < n) ? phi[c1] : (intE)0;
            const intE l2 = (c2 < n) ? phi[c2] : (intE)0;
            wlev[lo + j] = min(l1, l2);
        }
        sort(wlev.begin() + lo, wlev.begin() + lo + d, greater<intE>());
    }

    
    for (intE e = 0; e < n; e++) {
        const intE k = phi[e];
        intE acc = 0;
        for (intB bi = BEG.edgeVI[e]; bi < BEG.edgeVI[e + 1]; bi++) {
            const intB b  = BEG.edgeEI[bi].first;
            const intE tw = BEG.edgeEI[bi].second;
            if (b < 0 || b >= BEG.numV) continue;
            if (tw >= n) continue;
            if (phi[tw] < k) continue;        
            const intB lo = BEG.bloomVI[b];
            const intE d  = BEG.bloomDegree[b];
            if (d <= 0) continue;
            
            
            
            
            
            auto first = wlev.begin() + lo;
            auto last  = wlev.begin() + lo + d;
            const intE cnt = (intE)(upper_bound(first, last, k, greater<intE>()) - first);
            if (cnt >= 1) acc += cnt - 1;     
        }
        psi[e] = acc;
    }
}

#endif
