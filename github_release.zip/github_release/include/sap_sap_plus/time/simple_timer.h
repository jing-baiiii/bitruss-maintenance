







#pragma once
#include "time/time_utility.h"

namespace scnu
{
    



    class simple_timer
    {
    public:
        simple_timer();

        double get_elapse_millisecond();

        double get_elapse_second();

    private:
        high_resolution_clock::time_point end_time;
        high_resolution_clock::time_point start_time;
    };
}




