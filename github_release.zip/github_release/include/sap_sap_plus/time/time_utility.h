






#pragma once
#include <chrono>

using std::ratio;
using std::chrono::milliseconds;
using std::chrono::duration;
using std::chrono::high_resolution_clock;
