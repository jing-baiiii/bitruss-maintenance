







#pragma once
#include "thread/thread_utility.h"

namespace scnu
{
    



    class join_thread
    {
    public:
        explicit join_thread(std::vector<std::thread>& other_thread_vector);

        ~join_thread();
    private:
        std::vector<std::thread>& thread_vector;
    };
}




