#ifndef BAI_DELETION_COUNTERS_H
#define BAI_DELETION_COUNTERS_H
#include <unordered_set>
#include <array>
namespace baiDeletion {
inline std::array<long long,24> guards{};
inline int activeSite=0;
inline long long phiWrites=0, firstHop=0, candidateTests=0;
inline std::unordered_set<const void*> tested, peeled;
inline void reset(){guards.fill(0);activeSite=0;phiWrites=firstHop=candidateTests=0;tested.clear();peeled.clear();}
}
#ifdef ABP_COUNT_OPS
#define BAI_DEL(statement) do { statement; } while(0)
#else
#define BAI_DEL(statement) do {} while(0)
#endif
#endif
