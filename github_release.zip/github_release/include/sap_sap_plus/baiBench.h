#ifndef BAI_BENCH_H
#define BAI_BENCH_H
#include "insertionAllocation.h"
struct BaiBench {
    using Edge=shared_ptr<abstract_bipartite_edge>;using Values=unordered_map<Edge,uint32_t>;
    shared_ptr<abstract_bipartite_graph> graph;vector<Edge> edges;
    shared_ptr<Values> phi,ws,rank,scratch;
    shared_ptr<unordered_map<Edge,shared_ptr<mutex>>> locks;
    shared_ptr<scnu::thread_pool> pool;shared_ptr<uint32_t> maxPhi;
    BaiBench(const InsertionState& initial,const vector<intE>& psi) {
        PI_MEMORY_BLOCK(Graph,graph=make_shared<abstract_bipartite_graph>();edges.reserve(initial.edges()+1));
        PI_MEMORY_BLOCK(Output,phi=make_shared<Values>();ws=make_shared<Values>();maxPhi=make_shared<uint32_t>(0));
        PI_MEMORY_BLOCK(Aux,rank=make_shared<Values>();scratch=make_shared<Values>();pool=make_shared<scnu::thread_pool>(1,true));
        PI_MEMORY_BLOCK(Idle,locks=make_shared<unordered_map<Edge,shared_ptr<mutex>>>());
        for(size_t e=0;e<initial.edges();++e) {
            auto uv=initial.endpoints(e);if(!initial.base->left[uv.first])swap(uv.first,uv.second);
            Edge edge;PI_MEMORY_BLOCK(Graph,edge=make_shared<abstract_bipartite_edge>(uv.first,uv.second);graph->insert_edge(edge);edges.push_back(edge));
            PI_MEMORY_BLOCK(Output,phi->emplace(edge,initial.phi[e]);ws->emplace(edge,psi[e]));
            *maxPhi=max(*maxPhi,initial.phi[e]);
        }
        PI_MEMORY_BLOCK(Aux,scnu::quasi_wing_maintenance::init(phi,locks,rank,scratch,pool));
    }
    void insert(const shared_ptr<unordered_set<Edge>>& set) {
        scnu::quasi_wing_maintenance::insert2(graph,locks,set,rank,scratch,phi,ws,maxPhi,pool);
    }
    void restore(const InsertionState& initial,const vector<intE>& psi,const Edge& edge) {
        graph->remove_edge(edge);phi->erase(edge);ws->erase(edge);rank->erase(edge);scratch->erase(edge);locks->erase(edge);
        *maxPhi=0;
        for(size_t e=0;e<initial.edges();++e) {
            auto old=edges[e];phi->at(old)=initial.phi[e];ws->at(old)=psi[e];rank->at(old)=UINT32_MAX;scratch->at(old)=0;
            *maxPhi=max(*maxPhi,initial.phi[e]);
        }
    }
};
#endif
