
























#ifndef ARRAY_BMI_H
#define ARRAY_BMI_H
#include "graph.h"
#include "ThresholdFilteredEdge_vec.h"
#include <vector>
#include <algorithm>
#include <unordered_map>
#include <unordered_set>
#include <functional>
using namespace std;

static const intE ABI_NOE = (intE)-1;
static const intV ABI_NOV = (intV)-1;

static inline intV abi_findWdgVer(const pair<intV,intV>&e1,const pair<intV,intV>&e2){
    if(e1.first==e2.first||e1.first==e2.second) return e1.first;
    if(e1.second==e2.first||e1.second==e2.second) return e1.second;
    return ABI_NOV;
}









struct ABIMetrics { long long R=0, C=0, U=0, Baff=0, bfl=0, bflB=0; };


static void abi_buildMasterToBloom(const BEGraphLoMem& BEG, unordered_map<pair<intV,intV>,intB,pair_hash>& m){
    m.clear(); m.reserve(BEG.numV*2);
    for(intB b=0;b<BEG.numV;b++){
        intV a=BEG.bloomMaster[b].first, c=BEG.bloomMaster[b].second;
        m[make_pair(min(a,c),max(a,c))]=b;
    }
}













static vector<intE> arrayBMI(BEGraphLoMem& BEG, vector<intE>& bitr, vector<intE>& es,
                             const vector<intB>& vAdjVI, const vector<intV>& vAdjNbr, const vector<intE>& vAdjEid,
                             const vector<pair<intV,intV>>& eIdToV,
                             const unordered_map<pair<intV,intV>,intB,pair_hash>& masterToBloom,
                             const Graph& G, intV u1, intV v1, intE eid,
                             ABIMetrics* outM=nullptr)
{
    long long mR=0,mC=0,mU=0,mBaff=0,mBfl=0,mBflB=0;
    const intE n = BEG.numU;                 

    
    auto E2=[&](intV a,intV b)->intE{
        if((size_t)a+1>=vAdjVI.size()) return ABI_NOE;
        intB lo=vAdjVI[a],hi=vAdjVI[a+1];
        while(lo<hi){ intB mid=lo+((hi-lo)>>1); if(vAdjNbr[mid]<b) lo=mid+1; else hi=mid; }
        if(lo<vAdjVI[a+1]&&vAdjNbr[lo]==b) return vAdjEid[lo];
        return ABI_NOE;
    };

    
    const intB newBloomBase = BEG.numV;
    
    vector<pair<intV,intV>> nbMaster;         
    vector<intE> nbWdgCnt;                     
    unordered_map<intB, vector<pair<intE,intE>>> exWedges;  
    unordered_map<intE, vector<pair<intB,intE>>> exMemb;    
    
    auto BWDG=[&](intB b)->intE{
        return (b<newBloomBase)? BEG.bloomWdgCnt[b] : nbWdgCnt[b-newBloomBase];
    };
    
    auto BMAS=[&](intB b)->pair<intV,intV>{
        return (b<newBloomBase)? BEG.bloomMaster[b] : nbMaster[b-newBloomBase];
    };

    
    auto forEachWedge=[&](intB b, const std::function<void(intE,intE)>& fn){
        if(b<newBloomBase){
            for(intB j=BEG.bloomVI[b]; j<BEG.bloomVI[b]+(intB)BEG.bloomDegree[b]; j++)
                fn(BEG.bloomEI[j].first, BEG.bloomEI[j].second);
        }
        auto it=exWedges.find(b);
        if(it!=exWedges.end()) for(auto&pr:it->second) fn(pr.first, pr.second);
    };
    
    auto forEachMemb=[&](intE e, const std::function<void(intB,intE)>& fn){
        if(e<n){
            for(intB i=BEG.edgeVI[e]; i<BEG.edgeVI[e+1]; i++){
                intB b=BEG.edgeEI[i].first;
                if(b>=0) fn(b, BEG.edgeEI[i].second);
            }
        }
        auto it=exMemb.find(e);
        if(it!=exMemb.end()) for(auto&pr:it->second) fn(pr.first, pr.second);
    };
    
    auto addWedge=[&](intB b, intV wv){
        auto mp=BMAS(b); intV a=mp.first, c=mp.second;
        intE e1=E2(wv,a), e2=E2(wv,c);
        if(e1==ABI_NOE||e2==ABI_NOE) return;
        exWedges[b].push_back({e1,e2});
        if(b<newBloomBase) BEG.bloomWdgCnt[b]++; else nbWdgCnt[b-newBloomBase]++;
        exMemb[e1].push_back({b,e2});
        exMemb[e2].push_back({b,e1});
    };

    
    
    
    intV degU1=0; const vector<intV>& u1N = ((Graph&)G).get_neigh(u1,degU1);
    intV degV1=0; const vector<intV>& v1N = ((Graph&)G).get_neigh(v1,degV1);
    unordered_set<intV> v1set(v1N.begin(), v1N.end());
    unordered_set<pair<intV,intV>,pair_hash> isProc;
    vector<pair<intV,intV>> bloomPairs;        
    unordered_map<pair<intV,intV>,intV,pair_hash> newBloomWedge;  
    bool found=false;
    for(intV v: u1N){
        if(v==v1) continue;
        intV degV=0; const vector<intV>& vN=((Graph&)G).get_neigh(v,degV);
        for(intV u: vN){
            if(u==u1) continue;
            if(!v1set.count(u)) continue;
            found=true;
            intV mn=min(min(u,v),min(u1,v1));
            pair<intV,intV> mp;
            if(mn==u||mn==u1) mp=make_pair(min(u,u1),max(u,u1));   
            else              mp=make_pair(min(v,v1),max(v,v1));   
            if(isProc.count(mp)) continue;
            isProc.insert(mp);
            bloomPairs.push_back(mp);
            
            auto it=masterToBloom.find(mp);
            bool empty = (it==masterToBloom.end()) || (BEG.bloomWdgCnt[it->second]==0);
            if(empty) newBloomWedge[mp] = (mn==u||mn==u1)? v : u;
        }
    }
    v1set.clear(); isProc.clear();

    if(!found){ 
        if(outM){ outM->R=0; outM->C=0; outM->U=0; outM->Baff=0; outM->bfl=0; }
        return bitr;
    }

    
    for(auto&mp: bloomPairs){
        auto it=masterToBloom.find(mp);
        intE wc = (it!=masterToBloom.end())? BEG.bloomWdgCnt[it->second] : 0;
        mR += (wc==0)? 1 : wc;
    }

    
    
    const intE N = n+1;
    vector<intE> Q(N);
    vector<char> visited(N,0), hasBeenProcessed(N,0), isUpdated(N,0), onTouched(N,0);
    vector<intB> se(N,0);
    vector<intE> seToUpdate(N);
    vector<intE> touched; touched.reserve(256);
    auto touch=[&](intE e){ if(!onTouched[e]){ onTouched[e]=1; touched.push_back(e); } };

    
    for(auto& mp : bloomPairs){
        intV uid=mp.first, wid=mp.second;
        
        intB bloomId;
        auto it=masterToBloom.find(mp);
        bool isNew = (it==masterToBloom.end());
        if(!isNew) bloomId=it->second;
        else { bloomId=newBloomBase+(intB)nbMaster.size(); nbMaster.push_back(mp); nbWdgCnt.push_back(0); }

        
        
        intV spokeNew = (u1==uid||u1==wid)? v1 : u1;

        
        if(BWDG(bloomId)==0){
            auto nbw=newBloomWedge.find(mp);
            if(nbw!=newBloomWedge.end()) addWedge(bloomId, nbw->second);
        }

        
        vector<intV> wedgeVers;
        forEachWedge(bloomId, [&](intE we1,intE we2){
            intV wv=abi_findWdgVer(eIdToV[we1], eIdToV[we2]);
            if(wv!=ABI_NOV) wedgeVers.push_back(wv);
        });

        vector<intV> addedB; addedB.reserve(wedgeVers.size()+1);
        
        intE thirdEdge = E2(spokeNew, uid);
        intE fourthEdge= E2(spokeNew, wid);

        for(intV vid : wedgeVers){
            addedB.push_back(vid);
            intV curAddedIdx = (intV)addedB.size();   
            intE firstEdge = E2(vid, uid);
            intE secondEdge= E2(vid, wid);
            if(firstEdge==ABI_NOE||secondEdge==ABI_NOE||thirdEdge==ABI_NOE||fourthEdge==ABI_NOE) continue;

            
            es[firstEdge]++; es[secondEdge]++; es[thirdEdge]++; es[fourthEdge]++;

            intB BLevel = min(min(bitr[firstEdge],bitr[secondEdge]),min(bitr[thirdEdge],bitr[fourthEdge]));

            intV start_idx=0,end_idx=0;
            
            auto seed=[&](intE e){ if(bitr[e]==BLevel && !visited[e]){ touch(e); Q[end_idx++]=e; visited[e]=1; touch(e); se[e]++; } };
            
            if(bitr[firstEdge]==BLevel){ touch(firstEdge); Q[end_idx++]=firstEdge; visited[firstEdge]=1; se[firstEdge]++; }
            if(bitr[secondEdge]==BLevel){ touch(secondEdge); Q[end_idx++]=secondEdge; visited[secondEdge]=1; se[secondEdge]++; }
            if(bitr[thirdEdge]==BLevel){ touch(thirdEdge); Q[end_idx++]=thirdEdge; visited[thirdEdge]=1; se[thirdEdge]++; }
            if(bitr[fourthEdge]==BLevel){ touch(fourthEdge); Q[end_idx++]=fourthEdge; visited[fourthEdge]=1; se[fourthEdge]++; }
            (void)seed;

            
            for(intV j=0;j<curAddedIdx-1;j++){
                intV w=addedB[j];
                intE e1=E2(w,uid), e2=E2(w,wid);
                if(e1==ABI_NOE||e2==ABI_NOE) continue;
                if(bitr[e1]>=BLevel && bitr[e2]>=BLevel){
                    if(bitr[e1]==BLevel){ if(!visited[e1]){ touch(e1); Q[end_idx++]=e1; visited[e1]=1; } touch(e1); se[e1]++; }
                    if(bitr[e2]==BLevel){ if(!visited[e2]){ touch(e2); Q[end_idx++]=e2; visited[e2]=1; } touch(e2); se[e2]++; }
                    if(bitr[thirdEdge]==BLevel){ se[thirdEdge]++; }
                    if(bitr[fourthEdge]==BLevel){ se[fourthEdge]++; }
                }
            }

            ThresholdFilteredEdgeHeap_vec edgeHeap;
            
            while(start_idx<end_idx){
                intE e=Q[start_idx++];
                forEachMemb(e, [&](intB bID, intE etwin){
                    mBfl += (BWDG(bID)>=1)? (long long)BWDG(bID)-1 : 0;
                    if(BWDG(bID)<2) return;
                    if(bitr[etwin]<BLevel) return;
                    auto ms=BMAS(bID); intV a=ms.first, bb=ms.second;
                    forEachWedge(bID, [&](intE ce1,intE ce2){
                        mBflB++;   
                        if(e==ce1||e==ce2) return;
                        if(bitr[ce1]<BLevel||bitr[ce2]<BLevel) return;
                        touch(e); se[e]++;
                        if(!visited[ce1]&&bitr[ce1]==BLevel){ touch(ce1); Q[end_idx++]=ce1; visited[ce1]=1; }
                        if(!visited[ce2]&&bitr[ce2]==BLevel){ touch(ce2); Q[end_idx++]=ce2; visited[ce2]=1; }
                        if(!visited[etwin]&&bitr[etwin]==BLevel){ touch(etwin); Q[end_idx++]=etwin; visited[etwin]=1; }
                        (void)a;(void)bb;
                    });
                });
                mBaff += se[e];
                edgeHeap.addEdge(e, se[e]);
            }
            mC += end_idx;

            
            
            while(edgeHeap.hasEdgesLessOrEqual(BLevel)){
                vector<intE> edgesToProcess = edgeHeap.removeAllEdgesLessOrEqual(BLevel);
                intE seToUpdateIdx=0;
                for(intE e : edgesToProcess){
                    
                    forEachMemb(e, [&](intB bID, intE etwin){
                        if(BWDG(bID)<2) return;
                        if(bitr[etwin]<BLevel || hasBeenProcessed[etwin]) return;
                        forEachWedge(bID, [&](intE ce1,intE ce2){
                            mBflB++;   
                            if(e==ce1||e==ce2) return;
                            if(bitr[ce1]<BLevel||bitr[ce2]<BLevel) return;
                            if(hasBeenProcessed[ce1]||hasBeenProcessed[ce2]) return;
                            if(edgeHeap.contains(ce1)){ touch(ce1); se[ce1]--; if(!isUpdated[ce1]){seToUpdate[seToUpdateIdx++]=ce1; isUpdated[ce1]=1;} }
                            if(edgeHeap.contains(ce2)){ touch(ce2); se[ce2]--; if(!isUpdated[ce2]){seToUpdate[seToUpdateIdx++]=ce2; isUpdated[ce2]=1;} }
                            if(edgeHeap.contains(etwin)){ touch(etwin); se[etwin]--; if(!isUpdated[etwin]){seToUpdate[seToUpdateIdx++]=etwin; isUpdated[etwin]=1;} }
                        });
                    });
                    
                    if((e==thirdEdge && bitr[fourthEdge]>=BLevel && !hasBeenProcessed[fourthEdge]) ||
                       (e==fourthEdge && bitr[thirdEdge]>=BLevel && !hasBeenProcessed[thirdEdge])){
                        for(intV j=0;j<(intV)addedB.size();j++){
                            intV w=addedB[j]; intE e1=E2(w,uid), e2=E2(w,wid);
                            if(e1==ABI_NOE||e2==ABI_NOE) continue;
                            if(bitr[e1]>=BLevel && bitr[e2]>=BLevel && !hasBeenProcessed[e1] && !hasBeenProcessed[e2]){
                                intE other = (e==thirdEdge)? fourthEdge : thirdEdge;
                                if(edgeHeap.contains(other)){ touch(other); se[other]--; if(!isUpdated[other]){seToUpdate[seToUpdateIdx++]=other; isUpdated[other]=1;} }
                                if(edgeHeap.contains(e1)){ touch(e1); se[e1]--; if(!isUpdated[e1]){seToUpdate[seToUpdateIdx++]=e1; isUpdated[e1]=1;} }
                                if(edgeHeap.contains(e2)){ touch(e2); se[e2]--; if(!isUpdated[e2]){seToUpdate[seToUpdateIdx++]=e2; isUpdated[e2]=1;} }
                            }
                        }
                    }
                    
                    for(intV j=0;j<(intV)addedB.size();j++){
                        intV w=addedB[j]; intE e1=E2(w,uid), e2=E2(w,wid);
                        if(e1==ABI_NOE||e2==ABI_NOE) continue;
                        if(e!=e1 && e!=e2) continue;
                        if(e==e1 && bitr[e2]>=BLevel && !hasBeenProcessed[e2] && !hasBeenProcessed[thirdEdge] && !hasBeenProcessed[fourthEdge]){
                            if(edgeHeap.contains(e2)){ touch(e2); se[e2]--; if(!isUpdated[e2]){seToUpdate[seToUpdateIdx++]=e2; isUpdated[e2]=1;} }
                            if(edgeHeap.contains(thirdEdge)){ touch(thirdEdge); se[thirdEdge]--; if(!isUpdated[thirdEdge]){seToUpdate[seToUpdateIdx++]=thirdEdge; isUpdated[thirdEdge]=1;} }
                            if(edgeHeap.contains(fourthEdge)){ touch(fourthEdge); se[fourthEdge]--; if(!isUpdated[fourthEdge]){seToUpdate[seToUpdateIdx++]=fourthEdge; isUpdated[fourthEdge]=1;} }
                        }
                        if(e==e2 && bitr[e1]>=BLevel && !hasBeenProcessed[e1] && !hasBeenProcessed[thirdEdge] && !hasBeenProcessed[fourthEdge]){
                            if(edgeHeap.contains(e1)){ touch(e1); se[e1]--; if(!isUpdated[e1]){seToUpdate[seToUpdateIdx++]=e1; isUpdated[e1]=1;} }
                            if(edgeHeap.contains(thirdEdge)){ touch(thirdEdge); se[thirdEdge]--; if(!isUpdated[thirdEdge]){seToUpdate[seToUpdateIdx++]=thirdEdge; isUpdated[thirdEdge]=1;} }
                            if(edgeHeap.contains(fourthEdge)){ touch(fourthEdge); se[fourthEdge]--; if(!isUpdated[fourthEdge]){seToUpdate[seToUpdateIdx++]=fourthEdge; isUpdated[fourthEdge]=1;} }
                        }
                    }
                    hasBeenProcessed[e]=1;
                }
                for(intE i=0;i<seToUpdateIdx;i++){ intE e=seToUpdate[i]; edgeHeap.updateEdgeWeight(e, se[e]); isUpdated[e]=0; }
                mU += seToUpdateIdx;
            }
            
            for(intE e : edgeHeap.getAllEdges()){ bitr[e]=BLevel+1; }

            
            for(intE t: touched){ se[t]=0; visited[t]=0; hasBeenProcessed[t]=0; isUpdated[t]=0; onTouched[t]=0; }
            touched.clear();
        }

        
        addWedge(bloomId, spokeNew);
    }

    vector<intE> ret = bitr;
    if(outM){ outM->R=mR; outM->C=mC; outM->U=mU; outM->Baff=mBaff; outM->bfl=mBfl; outM->bflB=mBflB; }
    return ret;
}

#endif
