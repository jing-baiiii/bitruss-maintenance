



















#ifndef ARRAY_BMD_PLUS_H
#define ARRAY_BMD_PLUS_H
#include "graph.h"
#include "arrayOpsCount.h"
#include "ThresholdFilteredEdge_vec.h"
#include <vector>
#include <algorithm>
#include <set>
#include <tuple>
#include <array>

using namespace std;

static const intE ABP_NOE = (intE)-1;   
static const intV ABP_NOV = (intV)-1;   


static inline intV abp_findWdgVer(const pair<intV,intV>&e1,const pair<intV,intV>&e2){
    if(e1.first==e2.first||e1.first==e2.second) return e1.first;
    if(e1.second==e2.first||e1.second==e2.second) return e1.second;
    return ABP_NOV;
}


static inline void abp_removeMembership(BEGraphLoMem &BEG, intE e, intB b){
    if(e==ABP_NOE || e>=BEG.numU) return;
    for(intB i=BEG.edgeVI[e]; i<BEG.edgeVI[e+1]; i++){
        OPS_ALG();   
        if(BEG.edgeEI[i].first==b) BEG.edgeEI[i].first=-1;
    }
}




static inline intB abp_maxKBloom(intE e, BEGraphLoMem &BEG, intB bloomCurrent, intE thirdEdge, intE fourthEdge){
    if(e==ABP_NOE || e>=BEG.numU) return 0;
    intB mx=0;
    const bool excludeCur = (e==thirdEdge || e==fourthEdge);
    for(intB i=BEG.edgeVI[e]; i<BEG.edgeVI[e+1]; i++){
        OPS_ALG();   
        intB b=BEG.edgeEI[i].first;
        if(b<0) continue;
        if(excludeCur && b==bloomCurrent) continue;
        if((intB)BEG.bloomWdgCnt[b]>mx) mx=(intB)BEG.bloomWdgCnt[b];
    }
    return mx;
}


















struct ABPMetrics {
    long long R=0, C=0, U=0, Uraw=0, Baff=0, bfl=0, bflU=0, bflB=0;
    long long Cfull=0, Cmat=0, lostButterflies=0;
    size_t residentWorkspaceBytes=0;
    long long bfsAttempts=0, bfsGuardPass=0, matAttempts=0, matGuardPass=0;
    long long propagateAttempts=0, propagateGuardPass=0, cascadeAttempts=0, cascadeGuardPass=0;
    long long memoHits=0, memoBuilds=0, memoBuildAttempts=0, memoQualifiedWedges=0, memoSupportContributions=0;
    long long candidateUnique=0, phiWrites=0, supportDec=0, supportCompensation=0;
    long long membershipScans=0, pruningQueries=0, pruningMembershipScans=0;
    long long candidateDeletedOccurrences=0;
};
#ifdef ABP_COUNT_OPS
#define ABP_EVENT(field, amount) do { if(outM) outM->field += (amount); } while(0)
#else
#define ABP_EVENT(field, amount) do {} while(0)
#endif












static void arrayBMD_plus(BEGraphLoMem& BEG, vector<intE>& bitr, vector<intE>& es,
                                 const vector<intB>& vAdjVI, const vector<intV>& vAdjNbr, const vector<intE>& vAdjEid,
                                 const vector<pair<intV,intV>>& eIdToV,
                                 intV u1, intV v1, intE eid, bool levelDesc,
                                 ABPMetrics* outM = nullptr,
                                 vector<pair<long long,long long>>* perBOut = nullptr,
                                 bool useBloomPruning = true)   
{
    long long mR=0, mC=0, mU=0, mBaff=0, mBfl=0, mBflU=0, mBflB=0;
    const intE n = BEG.numU;
    
    auto E2 = [&](intV a, intV b)->intE{
        if(a+1>=vAdjVI.size()) return ABP_NOE;
        intB lo=vAdjVI[a], hi=vAdjVI[a+1];
        while(lo<hi){ intB mid=lo+((hi-lo)>>1); if(vAdjNbr[mid]<b) lo=mid+1; else hi=mid; }
        if(lo<vAdjVI[a+1] && vAdjNbr[lo]==b) return vAdjEid[lo];
        return ABP_NOE;
    };

    
    
    
    vector<intE> Q(n);
    vector<char> visited(n,0), hasBeenProcessed(n,0), isUpdated(n,0), onTouched(n,0);
    vector<intB> se(n,0), preSE(n,0);
    vector<intE> seToUpdate(n);
    vector<intE> touched; touched.reserve(256);   
    
    auto touch=[&](intE e){ if(!onTouched[e]){ onTouched[e]=1; touched.push_back(e); } };

    
    
    
    auto maxKB=[&](intE x, intB bloomCur, intE third, intE fourth)->intB{
        if(!useBloomPruning) return 0;
        if(x>=n) return 0;
        return abp_maxKBloom(x,BEG,bloomCur,third,fourth);
    };

    
    vector<intB> changingBlooms;
    for (intB i=BEG.edgeVI[eid]; i<BEG.edgeVI[eid+1]; i++){
        intB b=BEG.edgeEI[i].first;
        if(b>=0) changingBlooms.push_back(b);
    }
    
    for (intB b : changingBlooms){
        intB wdg = (intB)BEG.bloomWdgCnt[b];
        mR += (wdg==0) ? 1 : wdg;
    }
    
    
    
    
    
    
    
    
    
    
    (void)levelDesc;
#ifndef ABP_NO_SORT
    {
        vector<intE> keyWdg(changingBlooms.size());
        for(size_t i=0;i<changingBlooms.size();i++) keyWdg[i]=BEG.bloomWdgCnt[changingBlooms[i]];
        vector<size_t> ord(changingBlooms.size());
        for(size_t i=0;i<ord.size();i++) ord[i]=i;
  #ifdef ABP_SORT_DESC
        std::sort(ord.begin(), ord.end(), [&](size_t x, size_t y){ return keyWdg[x] > keyWdg[y]; });
  #else
        std::sort(ord.begin(), ord.end(), [&](size_t x, size_t y){ return keyWdg[x] < keyWdg[y]; });   
  #endif
        vector<intB> sorted; sorted.reserve(changingBlooms.size());
        for(size_t i : ord) sorted.push_back(changingBlooms[i]);
        changingBlooms.swap(sorted);
    }
#endif

    
    for (intB bloomId : changingBlooms) {
        const intV uid = BEG.bloomMaster[bloomId].first;
        const intV wid = BEG.bloomMaster[bloomId].second;
        
        const intV spoke0 = (u1==uid||u1==wid) ? v1 : u1;

        
        if(BEG.bloomWdgCnt[bloomId]>0){ BEG.bloomWdgCnt[bloomId]--; }

        
        vector<intV> wedgeSpokes;
        for (intB j=BEG.bloomVI[bloomId]; j<BEG.bloomVI[bloomId]+(intB)BEG.bloomDegree[bloomId]; j++){
            intE we1=BEG.bloomEI[j].first, we2=BEG.bloomEI[j].second;
            if(we1>=n||we2>=n) continue;
            intV sp = abp_findWdgVer(eIdToV[we1], eIdToV[we2]);
            if(sp!=ABP_NOV) wedgeSpokes.push_back(sp);
        }
#ifdef ABP_REV_WEDGE
        std::reverse(wedgeSpokes.begin(), wedgeSpokes.end());
#endif

        vector<intV> deletedB; deletedB.reserve(wedgeSpokes.size());

        
        for (intV vid : wedgeSpokes) {
            if (vid == spoke0) continue;   
            deletedB.push_back(vid);
            const intE firstEdge  = E2(vid, uid);
            const intE secondEdge = E2(vid, wid);
            const intE thirdEdge  = E2(spoke0, uid);
            const intE fourthEdge = E2(spoke0, wid);
            if(firstEdge>=n||secondEdge>=n||thirdEdge>=n||fourthEdge>=n) continue;

            es[firstEdge]--; es[secondEdge]--; es[thirdEdge]--; es[fourthEdge]--;
            const intB b1=bitr[firstEdge], b2=bitr[secondEdge], b3=bitr[thirdEdge], b4=bitr[fourthEdge];
            const intB BLevel = std::min(std::min(b1,b2), std::min(b3,b4));

            intV start_idx=0, end_idx=0;
            long long bDowngraded=0;   
            ThresholdFilteredEdgeHeap_vec edgeHeap;

            
            if(b1==BLevel && maxKB(firstEdge,bloomId,thirdEdge,fourthEdge)-1<BLevel){ Q[end_idx++]=firstEdge; touch(firstEdge); visited[firstEdge]=1; preSE[firstEdge]++; }
            if(b2==BLevel && maxKB(secondEdge,bloomId,thirdEdge,fourthEdge)-1<BLevel){ Q[end_idx++]=secondEdge; touch(secondEdge); visited[secondEdge]=1; preSE[secondEdge]++; }
            if(b3==BLevel && maxKB(thirdEdge,bloomId,thirdEdge,fourthEdge)-1<BLevel){ Q[end_idx++]=thirdEdge; touch(thirdEdge); visited[thirdEdge]=1; preSE[thirdEdge]++; }
            if(b4==BLevel && maxKB(fourthEdge,bloomId,thirdEdge,fourthEdge)-1<BLevel){ Q[end_idx++]=fourthEdge; touch(fourthEdge); visited[fourthEdge]=1; preSE[fourthEdge]++; }

            
            for (size_t jj=0; jj+1<deletedB.size(); jj++){   
                intV w=deletedB[jj];
                intE e1=E2(w,uid), e2=E2(w,wid);
                if(e1>=n||e2>=n) continue;
                if(bitr[e1]>=BLevel && bitr[e2]>=BLevel){
                    if(bitr[e1]==BLevel && maxKB(e1,bloomId,thirdEdge,fourthEdge)-1<BLevel){ if(!visited[e1]){Q[end_idx++]=e1;touch(e1);visited[e1]=1;} touch(e1); preSE[e1]++; }
                    if(bitr[e2]==BLevel && maxKB(e2,bloomId,thirdEdge,fourthEdge)-1<BLevel){ if(!visited[e2]){Q[end_idx++]=e2;touch(e2);visited[e2]=1;} touch(e2); preSE[e2]++; }
                    if(bitr[thirdEdge]==BLevel && maxKB(thirdEdge,bloomId,thirdEdge,fourthEdge)-1<BLevel){ touch(thirdEdge); preSE[thirdEdge]++; }
                    if(bitr[fourthEdge]==BLevel && maxKB(fourthEdge,bloomId,thirdEdge,fourthEdge)-1<BLevel){ touch(fourthEdge); preSE[fourthEdge]++; }
                }
            }

            
            while(start_idx<end_idx){
                intE e=Q[start_idx++];
                for(intB bi=BEG.edgeVI[e]; bi<BEG.edgeVI[e+1]; bi++){
                    intB bID=BEG.edgeEI[bi].first; intE etwin=BEG.edgeEI[bi].second;
                    if(bID<0) continue;
                    
                    
                    { intB wdg=(intB)BEG.bloomWdgCnt[bID]; if(wdg>=1) mBfl += wdg-1; }
                    if(etwin>=n || bitr[etwin]<BLevel) continue;   
                    for(intB wj=BEG.bloomVI[bID]; wj<BEG.bloomVI[bID]+(intB)BEG.bloomDegree[bID]; wj++){
                        mBflB++;   
                        
                        
                        intE ce1=BEG.bloomEI[wj].first, ce2=BEG.bloomEI[wj].second;
                        if(ce1>=n||ce2>=n) continue;
                        if(e==ce1||e==ce2) continue;
                        if(bitr[ce1]<BLevel||bitr[ce2]<BLevel) continue;
                        touch(e); se[e]++;
                        if(!visited[ce1] && bitr[ce1]==BLevel && maxKB(ce1,bloomId,thirdEdge,fourthEdge)-1<BLevel){ Q[end_idx++]=ce1; touch(ce1); visited[ce1]=1; }
                        if(!visited[ce2] && bitr[ce2]==BLevel && maxKB(ce2,bloomId,thirdEdge,fourthEdge)-1<BLevel){ Q[end_idx++]=ce2; touch(ce2); visited[ce2]=1; }
                        if(!visited[etwin] && bitr[etwin]==BLevel && maxKB(etwin,bloomId,thirdEdge,fourthEdge)-1<BLevel){ Q[end_idx++]=etwin; touch(etwin); visited[etwin]=1; }
                    }
                }
                touch(e); se[e]=se[e]-preSE[e];
                mBaff += se[e];   
                edgeHeap.addEdge(e, se[e]);
            }
            mC += end_idx;   

            
            
            
            while(edgeHeap.hasEdgesLessOrEqual(BLevel-1)){
                vector<intE> edgesToProcess = edgeHeap.removeAllEdgesLessOrEqual(BLevel-1);
                intE seToUpdateIdx=0;
                auto markUpd=[&](intE ee){ if(edgeHeap.contains(ee) && !isUpdated[ee]){ seToUpdate[seToUpdateIdx++]=ee; isUpdated[ee]=1; } };

                for(intE e : edgesToProcess){
                    
                    if((e==thirdEdge && bitr[fourthEdge]>=BLevel && !hasBeenProcessed[fourthEdge]) ||
                       (e==fourthEdge && bitr[thirdEdge]>=BLevel && !hasBeenProcessed[thirdEdge])){
                        for(size_t jj=0; jj<deletedB.size(); jj++){
                            intV w=deletedB[jj]; intE e1=E2(w,uid), e2=E2(w,wid);
                            if(e1>=n||e2>=n) continue;
                            if(bitr[e1]>=BLevel && bitr[e2]>=BLevel && !hasBeenProcessed[e1] && !hasBeenProcessed[e2]){
                                if(e==thirdEdge){
                                    if(se[fourthEdge]>BLevel-1){ touch(fourthEdge); se[fourthEdge]++; markUpd(fourthEdge); }
                                    if(se[e1]>BLevel-1){ touch(e1); se[e1]++; markUpd(e1); }
                                    if(se[e2]>BLevel-1){ touch(e2); se[e2]++; markUpd(e2); }
                                }
                                if(e==fourthEdge){
                                    if(se[thirdEdge]>BLevel-1){ touch(thirdEdge); se[thirdEdge]++; markUpd(thirdEdge); }
                                    if(se[e1]>BLevel-1){ touch(e1); se[e1]++; markUpd(e1); }
                                    if(se[e2]>BLevel-1){ touch(e2); se[e2]++; markUpd(e2); }
                                }
                            }
                        }
                    }
                    
                    for(size_t jj=0; jj<deletedB.size(); jj++){
                        intV w=deletedB[jj]; intE e1=E2(w,uid), e2=E2(w,wid);
                        if(e1>=n||e2>=n) continue;
                        if(e!=e1 && e!=e2) continue;
                        if(e==e1 && bitr[e2]>=BLevel && !hasBeenProcessed[e2] && !hasBeenProcessed[thirdEdge] && !hasBeenProcessed[fourthEdge]){
                            if(se[e2]>BLevel-1){ touch(e2); se[e2]++; markUpd(e2); }
                            if(se[thirdEdge]>BLevel-1){ touch(thirdEdge); se[thirdEdge]++; markUpd(thirdEdge); }
                            if(se[fourthEdge]>BLevel-1){ touch(fourthEdge); se[fourthEdge]++; markUpd(fourthEdge); }
                        }
                        if(e==e2 && bitr[e1]>=BLevel && !hasBeenProcessed[e1] && !hasBeenProcessed[thirdEdge] && !hasBeenProcessed[fourthEdge]){
                            if(se[e1]>BLevel-1){ touch(e1); se[e1]++; markUpd(e1); }
                            if(se[thirdEdge]>BLevel-1){ touch(thirdEdge); se[thirdEdge]++; markUpd(thirdEdge); }
                            if(se[fourthEdge]>BLevel-1){ touch(fourthEdge); se[fourthEdge]++; markUpd(fourthEdge); }
                        }
                    }

                    
                    for(intB bi=BEG.edgeVI[e]; bi<BEG.edgeVI[e+1]; bi++){
                        intB bID=BEG.edgeEI[bi].first; intE etwin=BEG.edgeEI[bi].second;
                        if(bID<0) continue;
                        if(etwin>=n || bitr[etwin]<BLevel || hasBeenProcessed[etwin]) continue;
                        for(intB wj=BEG.bloomVI[bID]; wj<BEG.bloomVI[bID]+(intB)BEG.bloomDegree[bID]; wj++){
                            mBflB++;   
                            
                            intE ce1=BEG.bloomEI[wj].first, ce2=BEG.bloomEI[wj].second;
                            if(ce1>=n||ce2>=n) continue;
                            if(e==ce1||e==ce2) continue;
                            if(bitr[ce1]<BLevel||bitr[ce2]<BLevel) continue;
                            if(hasBeenProcessed[ce1]||hasBeenProcessed[ce2]) continue;
                            if(se[ce1]>BLevel-1){ touch(ce1); se[ce1]--; markUpd(ce1); }
                            if(se[ce2]>BLevel-1){ touch(ce2); se[ce2]--; markUpd(ce2); }
                            if(se[etwin]>BLevel-1){ touch(etwin); se[etwin]--; markUpd(etwin); }
                        }
                    }
                    touch(e); hasBeenProcessed[e]=1;
                }
                for(intE l=0;l<seToUpdateIdx;l++){ intE ee=seToUpdate[l]; if(edgeHeap.contains(ee)) edgeHeap.updateEdgeWeight(ee, se[ee]); }
                mU += seToUpdateIdx;   
                for(intE e : edgesToProcess){ bitr[e]=BLevel-1; bDowngraded++; }
                
                for(intE l=0;l<seToUpdateIdx;l++) isUpdated[seToUpdate[l]]=0;
            }

            if(perBOut) perBOut->push_back(make_pair((long long)end_idx, bDowngraded));   
            
            for(intE ee : touched){ se[ee]=0; preSE[ee]=0; visited[ee]=0; hasBeenProcessed[ee]=0; onTouched[ee]=0; }
            touched.clear();
            
        }

        
        {
            const intE thirdEdge  = E2(spoke0, uid);
            const intE fourthEdge = E2(spoke0, wid);
            
            for (intB j=BEG.bloomVI[bloomId]; j<BEG.bloomVI[bloomId]+(intB)BEG.bloomDegree[bloomId]; j++){
                intE we1=BEG.bloomEI[j].first, we2=BEG.bloomEI[j].second;
                if(we1==eid||we2==eid){
                    std::swap(BEG.bloomEI[j], BEG.bloomEI[BEG.bloomVI[bloomId]+(intB)BEG.bloomDegree[bloomId]-1]);
                    BEG.bloomDegree[bloomId]--; break;
                }
            }
            if(BEG.bloomWdgCnt[bloomId]==1){
                
                for (intB j=BEG.bloomVI[bloomId]; j<BEG.bloomVI[bloomId]+(intB)BEG.bloomDegree[bloomId]; j++){
                    intE we1=BEG.bloomEI[j].first, we2=BEG.bloomEI[j].second;
                    abp_removeMembership(BEG, we1, bloomId);
                    abp_removeMembership(BEG, we2, bloomId);
                }
                BEG.bloomDegree[bloomId]=0;
                BEG.bloomWdgCnt[bloomId]=0;
            }
            
            abp_removeMembership(BEG, thirdEdge, bloomId);
            abp_removeMembership(BEG, fourthEdge, bloomId);
        }
    }

    bitr[eid]=0;   
    if(outM){ outM->R=mR; outM->C=mC; outM->U=mU; outM->Baff=mBaff; outM->bfl=mBfl; outM->bflU=mBflU; outM->bflB=mBflB; }
    
}










static void arrayBMD_pp(BEGraphLoMem& BEG, vector<intE>& bitr, vector<intE>& es,
                                 const vector<intB>& vAdjVI, const vector<intV>& vAdjNbr, const vector<intE>& vAdjEid,
                                 const vector<pair<intV,intV>>& eIdToV,
                                 intV u1, intV v1, intE eid, bool levelDesc,
                                 ABPMetrics* outM = nullptr,
                                 vector<pair<long long,long long>>* perBOut = nullptr,
                                 bool useBloomPruning = true,   
                                 bool countUniqueBfl = false)   
{
    long long mR=0, mC=0, mU=0, mBaff=0, mBfl=0, mBflU=0, mBflB=0;
    const intE n = BEG.numU;
    
    std::set<std::array<intE,4>> uniqBfl;
    auto addUniqBfl=[&](intE a,intE b,intE c,intE d){
        if(!countUniqueBfl) return;
        std::array<intE,4> key{a,b,c,d}; std::sort(key.begin(),key.end());
        if(uniqBfl.insert(key).second) mBflU++;   
    };
    
    auto E2 = [&](intV a, intV b)->intE{
        if(a+1>=vAdjVI.size()) return ABP_NOE;
        intB lo=vAdjVI[a], hi=vAdjVI[a+1];
        while(lo<hi){ intB mid=lo+((hi-lo)>>1); if(vAdjNbr[mid]<b) lo=mid+1; else hi=mid; }
        if(lo<vAdjVI[a+1] && vAdjNbr[lo]==b) return vAdjEid[lo];
        return ABP_NOE;
    };

    
    
    
    vector<intE> Q(n);
    vector<char> visited(n,0), hasBeenProcessed(n,0), isUpdated(n,0), onTouched(n,0);
    vector<intB> se(n,0), preSE(n,0);
    vector<intE> seToUpdate(n);
    vector<intE> touched; touched.reserve(256);   
    
    auto touch=[&](intE e){ if(!onTouched[e]){ onTouched[e]=1; touched.push_back(e); } };

    
    
    
    auto maxKB=[&](intE x, intB bloomCur, intE third, intE fourth)->intB{
        if(!useBloomPruning) return 0;
        if(x>=n) return 0;
        return abp_maxKBloom(x,BEG,bloomCur,third,fourth);
    };

    
    vector<intB> changingBlooms;
    for (intB i=BEG.edgeVI[eid]; i<BEG.edgeVI[eid+1]; i++){
        intB b=BEG.edgeEI[i].first;
        if(b>=0) changingBlooms.push_back(b);
    }
    
    for (intB b : changingBlooms){
        intB wdg = (intB)BEG.bloomWdgCnt[b];
        mR += (wdg==0) ? 1 : wdg;
    }
    
    
    
    
    
    
    
    
    
    
    (void)levelDesc;
#ifndef ABP_NO_SORT
    {
        vector<intE> keyWdg(changingBlooms.size());
        for(size_t i=0;i<changingBlooms.size();i++) keyWdg[i]=BEG.bloomWdgCnt[changingBlooms[i]];
        vector<size_t> ord(changingBlooms.size());
        for(size_t i=0;i<ord.size();i++) ord[i]=i;
  #ifdef ABP_SORT_DESC
        std::sort(ord.begin(), ord.end(), [&](size_t x, size_t y){ return keyWdg[x] > keyWdg[y]; });
  #else
        std::sort(ord.begin(), ord.end(), [&](size_t x, size_t y){ return keyWdg[x] < keyWdg[y]; });   
  #endif
        vector<intB> sorted; sorted.reserve(changingBlooms.size());
        for(size_t i : ord) sorted.push_back(changingBlooms[i]);
        changingBlooms.swap(sorted);
    }
#endif

    
    for (intB bloomId : changingBlooms) {
        const intV uid = BEG.bloomMaster[bloomId].first;
        const intV wid = BEG.bloomMaster[bloomId].second;
        
        const intV spoke0 = (u1==uid||u1==wid) ? v1 : u1;

        
        if(BEG.bloomWdgCnt[bloomId]>0){ BEG.bloomWdgCnt[bloomId]--; }

        
        vector<intV> wedgeSpokes;
        for (intB j=BEG.bloomVI[bloomId]; j<BEG.bloomVI[bloomId]+(intB)BEG.bloomDegree[bloomId]; j++){
            intE we1=BEG.bloomEI[j].first, we2=BEG.bloomEI[j].second;
            if(we1>=n||we2>=n) continue;
            intV sp = abp_findWdgVer(eIdToV[we1], eIdToV[we2]);
            if(sp!=ABP_NOV) wedgeSpokes.push_back(sp);
        }
#ifdef ABP_REV_WEDGE
        std::reverse(wedgeSpokes.begin(), wedgeSpokes.end());
#endif

        vector<intV> deletedB; deletedB.reserve(wedgeSpokes.size());

        
        for (intV vid : wedgeSpokes) {
            if (vid == spoke0) continue;   
            deletedB.push_back(vid);
            const intE firstEdge  = E2(vid, uid);
            const intE secondEdge = E2(vid, wid);
            const intE thirdEdge  = E2(spoke0, uid);
            const intE fourthEdge = E2(spoke0, wid);
            if(firstEdge>=n||secondEdge>=n||thirdEdge>=n||fourthEdge>=n) continue;

            es[firstEdge]--; es[secondEdge]--; es[thirdEdge]--; es[fourthEdge]--;
            const intB b1=bitr[firstEdge], b2=bitr[secondEdge], b3=bitr[thirdEdge], b4=bitr[fourthEdge];
            const intB BLevel = std::min(std::min(b1,b2), std::min(b3,b4));

            intV start_idx=0, end_idx=0;
            long long bDowngraded=0;   
            ThresholdFilteredEdgeHeap_vec edgeHeap;

            
            if(b1==BLevel && maxKB(firstEdge,bloomId,thirdEdge,fourthEdge)-1<BLevel){ Q[end_idx++]=firstEdge; touch(firstEdge); visited[firstEdge]=1; preSE[firstEdge]++; }
            if(b2==BLevel && maxKB(secondEdge,bloomId,thirdEdge,fourthEdge)-1<BLevel){ Q[end_idx++]=secondEdge; touch(secondEdge); visited[secondEdge]=1; preSE[secondEdge]++; }
            if(b3==BLevel && maxKB(thirdEdge,bloomId,thirdEdge,fourthEdge)-1<BLevel){ Q[end_idx++]=thirdEdge; touch(thirdEdge); visited[thirdEdge]=1; preSE[thirdEdge]++; }
            if(b4==BLevel && maxKB(fourthEdge,bloomId,thirdEdge,fourthEdge)-1<BLevel){ Q[end_idx++]=fourthEdge; touch(fourthEdge); visited[fourthEdge]=1; preSE[fourthEdge]++; }

            
            for (size_t jj=0; jj+1<deletedB.size(); jj++){   
                intV w=deletedB[jj];
                intE e1=E2(w,uid), e2=E2(w,wid);
                if(e1>=n||e2>=n) continue;
                if(bitr[e1]>=BLevel && bitr[e2]>=BLevel){
                    if(bitr[e1]==BLevel && maxKB(e1,bloomId,thirdEdge,fourthEdge)-1<BLevel){ if(!visited[e1]){Q[end_idx++]=e1;touch(e1);visited[e1]=1;} touch(e1); preSE[e1]++; }
                    if(bitr[e2]==BLevel && maxKB(e2,bloomId,thirdEdge,fourthEdge)-1<BLevel){ if(!visited[e2]){Q[end_idx++]=e2;touch(e2);visited[e2]=1;} touch(e2); preSE[e2]++; }
                    if(bitr[thirdEdge]==BLevel && maxKB(thirdEdge,bloomId,thirdEdge,fourthEdge)-1<BLevel){ touch(thirdEdge); preSE[thirdEdge]++; }
                    if(bitr[fourthEdge]==BLevel && maxKB(fourthEdge,bloomId,thirdEdge,fourthEdge)-1<BLevel){ touch(fourthEdge); preSE[fourthEdge]++; }
                }
            }

            
            
            
            
            auto propagate=[&](intE e){
                for(intB bi=BEG.edgeVI[e]; bi<BEG.edgeVI[e+1]; bi++){
                    intB bID=BEG.edgeEI[bi].first; intE etwin=BEG.edgeEI[bi].second;
                    if(bID<0) continue;
                    if(etwin>=n || bitr[etwin]<BLevel) continue;
                    for(intB wj=BEG.bloomVI[bID]; wj<BEG.bloomVI[bID]+(intB)BEG.bloomDegree[bID]; wj++){
                        mBflB++;   
                        intE ce1=BEG.bloomEI[wj].first, ce2=BEG.bloomEI[wj].second;
                        if(ce1>=n||ce2>=n) continue;
                        if(e==ce1||e==ce2) continue;
                        if(bitr[ce1]<BLevel||bitr[ce2]<BLevel) continue;
                        if(!visited[ce1] && bitr[ce1]==BLevel && maxKB(ce1,bloomId,thirdEdge,fourthEdge)-1<BLevel){ Q[end_idx++]=ce1; touch(ce1); visited[ce1]=1; }
                        if(!visited[ce2] && bitr[ce2]==BLevel && maxKB(ce2,bloomId,thirdEdge,fourthEdge)-1<BLevel){ Q[end_idx++]=ce2; touch(ce2); visited[ce2]=1; }
                        if(!visited[etwin] && bitr[etwin]==BLevel && maxKB(etwin,bloomId,thirdEdge,fourthEdge)-1<BLevel){ Q[end_idx++]=etwin; touch(etwin); visited[etwin]=1; }
                    }
                }
            };
            while(start_idx<end_idx){
                intE e=Q[start_idx++];
                for(intB bi=BEG.edgeVI[e]; bi<BEG.edgeVI[e+1]; bi++){
                    intB bID=BEG.edgeEI[bi].first; intE etwin=BEG.edgeEI[bi].second;
                    if(bID<0) continue;
                    { intB wdg=(intB)BEG.bloomWdgCnt[bID]; if(wdg>=1) mBfl += wdg-1; }
                    if(etwin>=n || bitr[etwin]<BLevel) continue;
                    for(intB wj=BEG.bloomVI[bID]; wj<BEG.bloomVI[bID]+(intB)BEG.bloomDegree[bID]; wj++){
                        mBflB++;   
                        intE ce1=BEG.bloomEI[wj].first, ce2=BEG.bloomEI[wj].second;
                        if(ce1>=n||ce2>=n) continue;
                        if(e==ce1||e==ce2) continue;
                        if(bitr[ce1]<BLevel||bitr[ce2]<BLevel) continue;
                        touch(e); se[e]++;
                        addUniqBfl(e,etwin,ce1,ce2);   
                    }
                }
                touch(e); se[e]=se[e]-preSE[e];
                mBaff += se[e];
                edgeHeap.addEdge(e, se[e]);
                if(se[e] < BLevel) propagate(e);   
            }
            mC += end_idx;   

            
            
            
            
            auto materialize=[&](intE ce){
                for(intB bi=BEG.edgeVI[ce]; bi<BEG.edgeVI[ce+1]; bi++){
                    intB bID=BEG.edgeEI[bi].first; intE etwin=BEG.edgeEI[bi].second;
                    if(bID<0) continue;
                    { intB wdg=(intB)BEG.bloomWdgCnt[bID]; if(wdg>=1) mBfl += wdg-1; }
                    if(etwin>=n || bitr[etwin]<BLevel) continue;
                    for(intB wj=BEG.bloomVI[bID]; wj<BEG.bloomVI[bID]+(intB)BEG.bloomDegree[bID]; wj++){
                        mBflB++;   
                        intE c1=BEG.bloomEI[wj].first, c2=BEG.bloomEI[wj].second;
                        if(c1>=n||c2>=n) continue;
                        if(ce==c1||ce==c2) continue;
                        if(bitr[c1]<BLevel||bitr[c2]<BLevel) continue;
                        touch(ce); se[ce]++;
                        addUniqBfl(ce,etwin,c1,c2);   
                    }
                }
                touch(ce); se[ce]=se[ce]-preSE[ce];
                mBaff += se[ce];
                edgeHeap.addEdge(ce, se[ce]);
            };
            
            auto propagateAndMaterialize=[&](intE e){
                intV pre=end_idx; propagate(e);
                for(intV q=pre; q<end_idx; q++) materialize(Q[q]);
            };
            while(edgeHeap.hasEdgesLessOrEqual(BLevel-1)){
                vector<intE> edgesToProcess = edgeHeap.removeAllEdgesLessOrEqual(BLevel-1);
                intE seToUpdateIdx=0;
                auto markUpd=[&](intE ee){ if(edgeHeap.contains(ee) && !isUpdated[ee]){ seToUpdate[seToUpdateIdx++]=ee; isUpdated[ee]=1; } };

                for(intE e : edgesToProcess){
                    propagateAndMaterialize(e);   
                    
                    if((e==thirdEdge && bitr[fourthEdge]>=BLevel && !hasBeenProcessed[fourthEdge]) ||
                       (e==fourthEdge && bitr[thirdEdge]>=BLevel && !hasBeenProcessed[thirdEdge])){
                        for(size_t jj=0; jj<deletedB.size(); jj++){
                            intV w=deletedB[jj]; intE e1=E2(w,uid), e2=E2(w,wid);
                            if(e1>=n||e2>=n) continue;
                            if(bitr[e1]>=BLevel && bitr[e2]>=BLevel && !hasBeenProcessed[e1] && !hasBeenProcessed[e2]){
                                if(e==thirdEdge){
                                    if(se[fourthEdge]>BLevel-1){ touch(fourthEdge); se[fourthEdge]++; markUpd(fourthEdge); }
                                    if(se[e1]>BLevel-1){ touch(e1); se[e1]++; markUpd(e1); }
                                    if(se[e2]>BLevel-1){ touch(e2); se[e2]++; markUpd(e2); }
                                }
                                if(e==fourthEdge){
                                    if(se[thirdEdge]>BLevel-1){ touch(thirdEdge); se[thirdEdge]++; markUpd(thirdEdge); }
                                    if(se[e1]>BLevel-1){ touch(e1); se[e1]++; markUpd(e1); }
                                    if(se[e2]>BLevel-1){ touch(e2); se[e2]++; markUpd(e2); }
                                }
                            }
                        }
                    }
                    
                    for(size_t jj=0; jj<deletedB.size(); jj++){
                        intV w=deletedB[jj]; intE e1=E2(w,uid), e2=E2(w,wid);
                        if(e1>=n||e2>=n) continue;
                        if(e!=e1 && e!=e2) continue;
                        if(e==e1 && bitr[e2]>=BLevel && !hasBeenProcessed[e2] && !hasBeenProcessed[thirdEdge] && !hasBeenProcessed[fourthEdge]){
                            if(se[e2]>BLevel-1){ touch(e2); se[e2]++; markUpd(e2); }
                            if(se[thirdEdge]>BLevel-1){ touch(thirdEdge); se[thirdEdge]++; markUpd(thirdEdge); }
                            if(se[fourthEdge]>BLevel-1){ touch(fourthEdge); se[fourthEdge]++; markUpd(fourthEdge); }
                        }
                        if(e==e2 && bitr[e1]>=BLevel && !hasBeenProcessed[e1] && !hasBeenProcessed[thirdEdge] && !hasBeenProcessed[fourthEdge]){
                            if(se[e1]>BLevel-1){ touch(e1); se[e1]++; markUpd(e1); }
                            if(se[thirdEdge]>BLevel-1){ touch(thirdEdge); se[thirdEdge]++; markUpd(thirdEdge); }
                            if(se[fourthEdge]>BLevel-1){ touch(fourthEdge); se[fourthEdge]++; markUpd(fourthEdge); }
                        }
                    }

                    
                    for(intB bi=BEG.edgeVI[e]; bi<BEG.edgeVI[e+1]; bi++){
                        intB bID=BEG.edgeEI[bi].first; intE etwin=BEG.edgeEI[bi].second;
                        if(bID<0) continue;
                        if(etwin>=n || bitr[etwin]<BLevel || hasBeenProcessed[etwin]) continue;
                        for(intB wj=BEG.bloomVI[bID]; wj<BEG.bloomVI[bID]+(intB)BEG.bloomDegree[bID]; wj++){
                            mBflB++;   
                            
                            intE ce1=BEG.bloomEI[wj].first, ce2=BEG.bloomEI[wj].second;
                            if(ce1>=n||ce2>=n) continue;
                            if(e==ce1||e==ce2) continue;
                            if(bitr[ce1]<BLevel||bitr[ce2]<BLevel) continue;
                            if(hasBeenProcessed[ce1]||hasBeenProcessed[ce2]) continue;
                            if(se[ce1]>BLevel-1){ touch(ce1); se[ce1]--; markUpd(ce1); }
                            if(se[ce2]>BLevel-1){ touch(ce2); se[ce2]--; markUpd(ce2); }
                            if(se[etwin]>BLevel-1){ touch(etwin); se[etwin]--; markUpd(etwin); }
                        }
                    }
                    touch(e); hasBeenProcessed[e]=1;
                }
                for(intE l=0;l<seToUpdateIdx;l++){ intE ee=seToUpdate[l]; if(edgeHeap.contains(ee)) edgeHeap.updateEdgeWeight(ee, se[ee]); }
                mU += seToUpdateIdx;   
                for(intE e : edgesToProcess){ bitr[e]=BLevel-1; bDowngraded++; }
                
                for(intE l=0;l<seToUpdateIdx;l++) isUpdated[seToUpdate[l]]=0;
            }

            if(perBOut) perBOut->push_back(make_pair((long long)end_idx, bDowngraded));   
            
            for(intE ee : touched){ se[ee]=0; preSE[ee]=0; visited[ee]=0; hasBeenProcessed[ee]=0; onTouched[ee]=0; }
            touched.clear();
            
        }

        
        {
            const intE thirdEdge  = E2(spoke0, uid);
            const intE fourthEdge = E2(spoke0, wid);
            
            for (intB j=BEG.bloomVI[bloomId]; j<BEG.bloomVI[bloomId]+(intB)BEG.bloomDegree[bloomId]; j++){
                intE we1=BEG.bloomEI[j].first, we2=BEG.bloomEI[j].second;
                if(we1==eid||we2==eid){
                    std::swap(BEG.bloomEI[j], BEG.bloomEI[BEG.bloomVI[bloomId]+(intB)BEG.bloomDegree[bloomId]-1]);
                    BEG.bloomDegree[bloomId]--; break;
                }
            }
            if(BEG.bloomWdgCnt[bloomId]==1){
                
                for (intB j=BEG.bloomVI[bloomId]; j<BEG.bloomVI[bloomId]+(intB)BEG.bloomDegree[bloomId]; j++){
                    intE we1=BEG.bloomEI[j].first, we2=BEG.bloomEI[j].second;
                    abp_removeMembership(BEG, we1, bloomId);
                    abp_removeMembership(BEG, we2, bloomId);
                }
                BEG.bloomDegree[bloomId]=0;
                BEG.bloomWdgCnt[bloomId]=0;
            }
            
            abp_removeMembership(BEG, thirdEdge, bloomId);
            abp_removeMembership(BEG, fourthEdge, bloomId);
        }
    }

    bitr[eid]=0;   
    if(outM){ outM->R=mR; outM->C=mC; outM->U=mU; outM->Baff=mBaff; outM->bfl=mBfl; outM->bflU=mBflU; outM->bflB=mBflB; }
    
}






static vector<intE> arrayBMD_plus_valcopy(BEGraphLoMem BEG, vector<intE> bitr, vector<intE> es,
                                 const vector<intB>& vAdjVI, const vector<intV>& vAdjNbr, const vector<intE>& vAdjEid,
                                 const vector<pair<intV,intV>>& eIdToV,
                                 intV u1, intV v1, intE eid, bool levelDesc,
                                 ABPMetrics* outM = nullptr)
{
    arrayBMD_plus(BEG, bitr, es, vAdjVI, vAdjNbr, vAdjEid, eIdToV, u1, v1, eid, levelDesc, outM);
    return bitr;
}

#endif
