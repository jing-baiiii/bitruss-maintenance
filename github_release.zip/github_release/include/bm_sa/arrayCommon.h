




#ifndef ARRAY_COMMON_H
#define ARRAY_COMMON_H


#include <vector>
#include <algorithm>
#include <unordered_map>
using namespace std;



static vector<intE> arrayStaticDecomp(Graph &G)
{
    label_edges(G);
    edgeId_to_vertices(G);
    vector<intE> opCnt(G.numE, 0);
    vector<intV> wedgeCnt(G.numT, 0);
    BEGraphLoMem BEG;
    creat_BEIndex(G, opCnt, BEG, wedgeCnt);
    vector<intE> tipVal;  tipVal.swap(opCnt);
    vector<intE> outSupp(G.numE, 0);
    fine_peel_part_wing(BEG, tipVal, outSupp);
    return outSupp;
}


static void arrayBuildBase(Graph &G, BEGraphLoMem &BEG, vector<intE> &baseSupp, vector<intE> &basePhi)
{
    label_edges(G);
    edgeId_to_vertices(G);
    vector<intE> opCnt(G.numE, 0);
    vector<intV> wedgeCnt(G.numT, 0);
    creat_BEIndex(G, opCnt, BEG, wedgeCnt);
    baseSupp = opCnt;
    vector<intE> tip = opCnt;
    basePhi.assign(G.numE, 0);
    BEGraphLoMem BEGp = BEG;                 
    fine_peel_part_wing(BEGp, tip, basePhi);
}


static void buildVertexAdj(Graph &G, vector<intB> &vAdjVI, vector<intV> &vAdjNbr, vector<intE> &vAdjEid)
{
    const intV numT = G.numT;
    const intE m = min((intE)G.numE, (intE)G.eIdToV.size());
    vAdjVI.assign(numT+1, 0);
    for (intE i=0;i<m;i++){ auto uv=G.eIdToV[i]; vAdjVI[uv.first+1]++; vAdjVI[uv.second+1]++; }
    for (intV u=0;u<numT;u++) vAdjVI[u+1]+=vAdjVI[u];
    const intB total = vAdjVI[numT];
    vAdjNbr.assign(total, 0); vAdjEid.assign(total, 0);
    vector<intB> cur(vAdjVI.begin(), vAdjVI.end()-1);
    for (intE i=0;i<m;i++){
        auto uv=G.eIdToV[i];
        vAdjNbr[cur[uv.first]]=uv.second;  vAdjEid[cur[uv.first]++]=i;
        vAdjNbr[cur[uv.second]]=uv.first;  vAdjEid[cur[uv.second]++]=i;
    }
    for (intV u=0;u<numT;u++){
        intB lo=vAdjVI[u], hi=vAdjVI[u+1];
        if(hi-lo<=1) continue;
        vector<pair<intV,intE>> tmp; tmp.reserve(hi-lo);
        for(intB k=lo;k<hi;k++) tmp.push_back({vAdjNbr[k], vAdjEid[k]});
        sort(tmp.begin(), tmp.end(), [](const pair<intV,intE>&a, const pair<intV,intE>&b){ return a.first<b.first; });
        for(intB k=lo;k<hi;k++){ vAdjNbr[k]=tmp[k-lo].first; vAdjEid[k]=tmp[k-lo].second; }
    }
}


static void deleteEdgeFromG(Graph &G, intV u, intV v)
{
    auto &au = G.adj[u]; au.erase(std::remove(au.begin(), au.end(), v), au.end()); G.deg[u]--;
    auto &av = G.adj[v]; av.erase(std::remove(av.begin(), av.end(), u), av.end()); G.deg[v]--;
    G.numE--;
}


static void insertEdgeIntoG(Graph &G, intV u, intV v)
{
    G.adj[u].push_back(v); G.deg[u]++; std::stable_sort(G.adj[u].begin(), G.adj[u].end());
    G.adj[v].push_back(u); G.deg[v]++; std::stable_sort(G.adj[v].begin(), G.adj[v].end());
    G.numE++;
}



static long getVmHWM_KB()
{
    FILE* fp = fopen("/proc/self/status", "r");
    if(!fp) return 0;
    char line[256]; long kb = 0;
    while(fgets(line, sizeof(line), fp)){
        if(strncmp(line, "VmHWM:", 6) == 0){ sscanf(line + 6, "%ld", &kb); break; }
    }
    fclose(fp);
    return kb;
}


static long getVmRSS_KB()
{
    FILE* fp = fopen("/proc/self/status", "r");
    if(!fp) return 0;
    char line[256]; long kb = 0;
    while(fgets(line, sizeof(line), fp)){
        if(strncmp(line, "VmRSS:", 6) == 0){ sscanf(line + 6, "%ld", &kb); break; }
    }
    fclose(fp);
    return kb;
}




static void resetVmHWM_KB()
{
    FILE* fp = fopen("/proc/self/clear_refs", "w");
    if(fp){ fputs("5\n", fp); fclose(fp); }
}


static vector<intE> arrayStaticDecompTimed(Graph &G, double &buildMs, double &peelMs)
{
    label_edges(G);
    edgeId_to_vertices(G);
    vector<intE> opCnt(G.numE, 0);
    vector<intV> wedgeCnt(G.numT, 0);
    BEGraphLoMem BEG;
    clock_t b0 = clock();
    creat_BEIndex(G, opCnt, BEG, wedgeCnt);
    clock_t b1 = clock();
    vector<intE> tipVal;  tipVal.swap(opCnt);
    vector<intE> outSupp(G.numE, 0);
    fine_peel_part_wing(BEG, tipVal, outSupp);
    clock_t b2 = clock();
    buildMs = double(b1-b0)/CLOCKS_PER_SEC*1000.0;
    peelMs  = double(b2-b1)/CLOCKS_PER_SEC*1000.0;
    return outSupp;
}


static void buildEdgeToId(Graph &G, unordered_map<pair<intV,intV>,intE,pair_hash> &e2t)
{
    e2t.clear(); e2t.reserve(G.numE*2);
    for (intE i = 0; i < G.numE && i < (intE)G.eIdToV.size(); i++) {
        auto uv = G.eIdToV[i];
        e2t[make_pair(uv.first, uv.second)] = i;
        e2t[make_pair(uv.second, uv.first)] = i;
    }
}

#endif