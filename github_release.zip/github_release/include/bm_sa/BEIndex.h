







#include "draw.h"

#ifndef BEIndex_h
#define BEIndex_h


void edgeId_to_vertices (Graph &G, std::vector<std::pair<intV, intV>> &eIdToV);



void label_edges (Graph &G)
{
    std::unordered_map<uint64_t, intE> labels;
    labels.reserve(2*G.numE);
    intE currLabel = 0;
    for (intV i=0; i<G.numT; i++)
    {
        intV deg = 0;
        std::vector<intV>& neighList = G.get_neigh(i, deg);
        for (intV j=0; j<deg; j++)
        {
            intV neigh = neighList[j];
            if (neigh < i)
            {
                uint64_t key = ((uint64_t)i)*((uint64_t)G.numT) + ((uint64_t)neigh);
                labels[key] = currLabel++;
            }
            else
                break;
        }
    }
    
    






    

    G.eId.resize(G.numT);
    

    for (intV i=0; i<G.numT; i++)
    {
        intV deg = 0;
        std::vector<intV>& neighList = G.get_neigh(i, deg);
        G.eId[i].resize(deg);
        for (intV j=0; j<deg; j++)
        {
            intV neigh = neighList[j];
            uint64_t key = ((uint64_t)std::max(i, neigh))*((uint64_t)G.numT) + ((uint64_t)std::min(i,neigh));
            G.eId[i][j] = labels[key];
        
        }

    }
    
    

}


void edgeId_to_vertices (Graph &G)
{
    if (G.eIdToV.size() < G.numE) G.eIdToV.resize(G.numE);

    for (intV i=0; i<G.numT; i++)
    {
        for (intV j=0; j<G.deg[i]; j++)
        {
            intV neigh = G.adj[i][j];
            if (neigh >= i) break;
            intE eId = G.eId[i][j];
             G.eIdToV[eId] = std::make_pair(i, neigh);
            assert(neigh < G.numT);
        }
    }
    
    
}
















void creat_BEIndex (Graph &G, vector<intE> &opCnt, BEGraphLoMem &BEG, vector<intV> &wedgeCnt)
{

    
    if (opCnt.size() < G.numE)
        opCnt.resize(G.numE,(intE)0);
    

    std::vector<intE> perVertexBloomEdges (G.numT);
    std::vector<intV> perVertexBlooms (G.numT);
    std::vector<intE> perEdgeBlooms (G.numE,0); 

    
    
    {
        std::vector<intV> &numW = wedgeCnt;
        std::vector<intV> hop2Neighs (std::max(G.numU, G.numV));
        intV hop2NeighsPtr = 0;

        for (intV i=0; i<G.numT; i++)
        {
            
            intE vBloomEdges = 0;
            intV vBloomCnt = 0;
            for (intV j=0; j<G.deg[i]; j++)
            {
                intV neigh = G.adj[i][j];
                for (intV k=0; k<G.deg[neigh]; k++)
                {
                    intV neighOfNeigh = G.adj[neigh][k];
                    if ((neighOfNeigh>=neigh)||(neighOfNeigh>=i))
                        break;
                    if (numW[neighOfNeigh]==0)
                        hop2Neighs[hop2NeighsPtr++] = neighOfNeigh;
                    numW[neighOfNeigh]++;
                }
            }
            for (intV j=0; j<G.deg[i]; j++)
            {
                intE e1 = G.eId[i][j];
                intE e1ButterflyLocSum = 0; 
                intE e1BloomLocSum = 0; 
                intV neigh = G.adj[i][j];
                for (intV k=0; k<G.deg[neigh]; k++)
                {
                    intV neighOfNeigh = G.adj[neigh][k];
                    if ((neighOfNeigh >= neigh) || (neighOfNeigh >= i)) break;
                    if (numW[neighOfNeigh] < 2) continue;

                    intE e2 = G.eId[neigh][k];
                    vBloomEdges += 1;

                    intE butterflies = numW[neighOfNeigh] - 1;
                    __sync_fetch_and_add(&opCnt[e2], butterflies);
                    __sync_fetch_and_add(&perEdgeBlooms[e2], 1);

                    e1ButterflyLocSum += butterflies;
                    e1BloomLocSum += 1;
                }
                __sync_fetch_and_add(&opCnt[e1], e1ButterflyLocSum);
                __sync_fetch_and_add(&perEdgeBlooms[e1], e1BloomLocSum);
            }
            for (intV j=0; j<hop2NeighsPtr; j++)
            {
                if (numW[hop2Neighs[j]] >= 2)
                    vBloomCnt++;
                numW[hop2Neighs[j]] = 0;
            }
            perVertexBlooms[i] = vBloomCnt;
            perVertexBloomEdges[i] += vBloomEdges;
            hop2NeighsPtr = 0;
        }
    }

    intE sum = 0;
    for (intE val : opCnt) {
        sum += val;
    }
    double result = sum / 4.0;
    cout << "sum = " << sum << ", result = " << result << endl;
    
    








    std::vector<intB> vertexBloomOffset(G.numT+1,0);
    std::vector<intB> vertexEdgeOffset(G.numT+1,0);

    prefix_sum(vertexEdgeOffset, perVertexBloomEdges);
    free_vec(perVertexBloomEdges);

    prefix_sum(vertexBloomOffset, perVertexBlooms);
    free_vec(perVertexBlooms);
    








    
    BEG.numU = G.numE;
    BEG.numV = vertexBloomOffset[G.numT];
    BEG.numE = 2*vertexEdgeOffset[G.numT];
    
    

    BEG.edgeEI.resize(BEG.numE); 
    init(BEG.edgeEI, std::make_pair<intB, intE>(0,0));
    BEG.bloomEI.resize(BEG.numE/2); 
    init(BEG.bloomEI, std::make_pair<intE, intE>(0, 0));
    BEG.bloomVI.resize(BEG.numV+1); 
    BEG.bloomVI[0] = 0;
    init(BEG.bloomVI, (intB)0);
    BEG.bloomDegree.resize(BEG.numV);
    init(BEG.bloomDegree, (intE)0);
    BEG.bloomWdgCnt.resize(BEG.numV);
    init(BEG.bloomWdgCnt, (intE)0); 
    BEG.bloomMaster.resize(BEG.numV);
    init(BEG.bloomMaster, std::make_pair<intV,intV>(0,0)); 
    intB maxSizeOfBloom = 0;

    prefix_sum(BEG.edgeVI, perEdgeBlooms);

    init(perEdgeBlooms, (intE)0);
    init(BEG.bloomDegree, (intE)0);

    

    {
        std::vector<intV> &numW = wedgeCnt;
        std::vector<intV> hop2Neighs (std::max(G.numU, G.numV));
        intV hop2NeighsPtr = 0;

        for (intV i=0; i<G.numT; i++)
        {
            for (intV j=0; j<G.deg[i]; j++)
            {
                intV neigh = G.adj[i][j];
                for (intV k=0; k<G.deg[neigh]; k++)
                {
                    intV neighOfNeigh = G.adj[neigh][k];
                    if ((neighOfNeigh>=neigh)||(neighOfNeigh>=i))
                        break;
                    if (numW[neighOfNeigh]==0)
                        hop2Neighs[hop2NeighsPtr++] = neighOfNeigh;
                    numW[neighOfNeigh]++;
                }
            }
            
            intB bloomIdBase = vertexBloomOffset[i];
            intV bloomIdOff = 1; 
            BEG.bloomVI[bloomIdBase] = vertexEdgeOffset[i];
            
            for (intV j=0; j<hop2NeighsPtr; j++)
            {
                intV neighOfNeigh = hop2Neighs[j];
                if (numW[neighOfNeigh] >= 2)
                {
                    intB bloomId = bloomIdBase + (intB)bloomIdOff - 1;
                    assert(bloomId < vertexBloomOffset[i+1]);

                    BEG.bloomVI[bloomId+1] = BEG.bloomVI[bloomId] + numW[neighOfNeigh];
                    BEG.bloomWdgCnt[bloomId] = numW[neighOfNeigh];
                    BEG.bloomMaster[bloomId] = std::make_pair(i, neighOfNeigh);
                    maxSizeOfBloom = std::max(maxSizeOfBloom, (intB)numW[neighOfNeigh]);
                    
                    numW[neighOfNeigh] = bloomIdOff++;
                }
                else
                    numW[neighOfNeigh] = 0;
            }

            for (intV j=0; j<G.deg[i]; j++)
            {
                intE e1 = G.eId[i][j];
                intV neigh = G.adj[i][j];
                for (intV k=0; k<G.deg[neigh]; k++)
                {
                    intV neighOfNeigh = G.adj[neigh][k];
                    if ((neighOfNeigh >= neigh) || (neighOfNeigh >= i)) break;
                    if (numW[neighOfNeigh] == 0) continue;

                    intE e2 = G.eId[neigh][k];

                    intB bloomId = bloomIdBase + (intB)numW[neighOfNeigh] - 1;
                    intB BEedgeId = BEG.bloomVI[bloomId] + BEG.bloomDegree[bloomId];

                    BEG.bloomEI[BEedgeId] = std::make_pair(e1, e2);

                    BEG.bloomDegree[bloomId] += 1;

                    BEedgeId = BEG.edgeVI[e1] + __sync_fetch_and_add(&perEdgeBlooms[e1], 1);
                    BEG.edgeEI[BEedgeId] = std::make_pair(bloomId, e2);

                    BEedgeId = BEG.edgeVI[e2] + __sync_fetch_and_add(&perEdgeBlooms[e2], 1);
                    BEG.edgeEI[BEedgeId] = std::make_pair(bloomId, e1);
                }
            }
            for (intV j=0; j<hop2NeighsPtr; j++)
                numW[hop2Neighs[j]] = 0;
            hop2NeighsPtr = 0;
        }
    }
    BEG.edgeDegree.swap(perEdgeBlooms);
    








}














void  fine_peel_part_wing(BEGraphLoMem &BEG, std::vector<intE> &supp, std::vector<intE> &outSupp)
{
    
    
    
    if (supp.size() < BEG.numU) supp.resize (BEG.numU);
    KHeap<intE, intE> queue (BEG.numU);
    for (intE i=0; i<BEG.numU; i++)
    {
        queue.update(i, supp[i]);
    }
    


    
    vector<intB> activeBlooms (BEG.numV, 0);
    vector<intE> bloomUpdates (BEG.numV, 0);
    vector<bool> isPeeled (BEG.numU, 0);
    if (bloomUpdates.size() < BEG.numV) bloomUpdates.resize(BEG.numV);
    init(bloomUpdates, (intE)0);
    
    intB activeBloomPtr = 0;

    while(!queue.empty())
    {
        
        std::pair<intE, intE> kv = queue.top();
        intE e = kv.first; intE k = kv.second;

        
        intE nk = k;
        while(nk==k)
        {

            queue.pop();
            isPeeled[e] = true;
            outSupp[e] = k;

            for (intB i=BEG.edgeVI[e]; i<BEG.edgeVI[e+1]; i++)
            {
                intB bloomId = BEG.edgeEI[i].first;
                intE neighEId = BEG.edgeEI[i].second;

                if (isPeeled[neighEId] || (BEG.bloomWdgCnt[bloomId]<2)) continue;

                intE updateVal = BEG.bloomWdgCnt[bloomId] - 1;

                if (neighEId < BEG.numU)
                {

                    supp[neighEId] = std::max(supp[neighEId]-updateVal, k);
                    queue.update(neighEId, supp[neighEId]);

                }

                if (bloomUpdates[bloomId]==0)
                {
                    activeBlooms[activeBloomPtr++] = bloomId;

                }
                bloomUpdates[bloomId]++;

            }
            if (queue.empty()) break;
            kv = queue.top();
            e = kv.first;
            nk = kv.second;

        }
        if (queue.empty()) break;
        for (intB i=0; i<activeBloomPtr; i++)
        {
            intB bloomId = activeBlooms[i];





            intE numDels = bloomUpdates[bloomId];
            bloomUpdates[bloomId] = 0;

            assert(BEG.bloomWdgCnt[bloomId] >= numDels);
            BEG.bloomWdgCnt[bloomId] -= numDels;

            intB baseEId = BEG.bloomVI[bloomId];
            assert(baseEId + BEG.bloomDegree[bloomId] <= BEG.bloomVI[bloomId+1]);
            for (intE j=0; j<BEG.bloomDegree[bloomId]; j++)
            {
                intE e1 = BEG.bloomEI[baseEId+j].first; assert(e1 < BEG.numU);
                intE e2 = BEG.bloomEI[baseEId+j].second; assert (e2 < BEG.numU+2);
                if (isPeeled[e1] || isPeeled[e2])
                {
                    std::swap(BEG.bloomEI[baseEId+j], BEG.bloomEI[baseEId + BEG.bloomDegree[bloomId] - 1]);
                    j--;
                    BEG.bloomDegree[bloomId]--;

                    continue;
                }

                assert(supp[e1] >= numDels);
                supp[e1] = std::max(k, supp[e1]-numDels);
                queue.update(e1, supp[e1]);
                if (e2 > BEG.numU) continue;

                assert(supp[e2] >= numDels);
                supp[e2] = std::max(k, supp[e2]-numDels);
                queue.update(e2, supp[e2]);
            }
        }
        activeBloomPtr = 0;
    }


   cout << "supp:";
   print_vec(supp);

}

void BEIndex (Graph &G,vector<const char*> drawname_array,intV times, std::vector<intE>& tipVal_out)
{
    label_edges(G);    
    edgeId_to_vertices(G);
    
    vector<intE> opCnt (G.numE,0);
    vector<intV> wedgeCnt (G.numE,0);  
    BEGraphLoMem BEG;
    clock_t BEIndex_construction_start = clock();
    creat_BEIndex(G, opCnt, BEG, wedgeCnt);
    clock_t BEIndex_construction_end = clock();
    cout << "BEIndex_construction running time = " << double(BEIndex_construction_end - BEIndex_construction_start)/CLOCKS_PER_SEC * 1000 << " ms." << endl;
    std::vector<intE> tipVal; 
    tipVal.swap(opCnt);

    std::vector<intE> outSupp (G.numE,0);
    
    fine_peel_part_wing(BEG, tipVal, outSupp);
    clock_t BEIndex_peeling_end = clock();
    cout << "fine_peel_part_wing running time = " << double(BEIndex_peeling_end - BEIndex_construction_end)/CLOCKS_PER_SEC * 1000 << " ms." << endl;
    
    cout << "sumTime = " << double(BEIndex_peeling_end - BEIndex_construction_start)/CLOCKS_PER_SEC * 1000 << " ms." << endl;

    
    

    
    tipVal_out = std::move(outSupp);
    return;
    
    
    
    
    
    
    
    
    
    

    

    
    
    
    
    
    
    
    

    
    
    

    
    
    
    
    
    
    

    
    
    
    
    
    
    
    
    

    
    
    
    
    

    
    
    
    
    
    
    
    
    
}

























































































































#endif 
