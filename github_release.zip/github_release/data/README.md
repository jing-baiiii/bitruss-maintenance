# Data and Results

This directory contains two small input graphs, the frozen update sequences used by the experiments, and machine-readable experiment results.

## Datasets

`datasets/DS_dbpedia-starring.txt` and `datasets/GH_github.txt` are the exact graph inputs used for the DS and GH full-graph experiments. They use the unweighted bipartite edge-list format distributed by the KONECT collection. Lines beginning with `%` are metadata; each remaining line contains two endpoint IDs. The parser accepts this format.

The other experiment graphs are not bundled. Their public dataset names are listed in `results/dataset_statistics.csv`. Obtain them from the cited collection and pass their paths to the corresponding program.

## Samples

`samples/` contains 500-edge insertion and deletion sequences for each of the nine experiment datasets. Each file has two integer endpoint IDs per line. Files ending in `_ours` use the internal vertex labels used by our algorithms; files ending in `_bai` use the source graph's endpoint labels used by the Bai baseline. Keep each sequence paired with its matching graph and loader.

The frozen sequences are the exact update events used in the reported measurements. Candidate attempts rejected during sample generation are omitted; those attempt pools are substantially larger and are not required to replay the experiments.

## Results

`results/` includes the audited timing table, per-event median timings, paired comparisons, work and memory metrics, stage timings, allocation statistics, initialization costs, query measurements, index checkpoints, and continuous-stream results. The full-graph experiment compares all five methods: BAI, BM, SA, SAP, and SAP+. Their repeated per-event timing records are together in `full_graph_events/`, with 500 events and three measurements per event. `scale_events/` also contains all five methods for the scale experiment. `ablation_time_summary.csv`, `ablation_work_summary.csv`, and related tables provide additional BM/SA ablation measurements. `plots/` contains the numeric data used to produce the experiment figures.

Times are in milliseconds unless a table specifies another unit. Rows with an experiment identifier distinguish the full-graph, continuous-update, and ablation protocols. Local source paths have been removed from exported tables.
