# Algorithm and Reproduction Notes

## Algorithm Mapping

| Algorithm | Insertion | Deletion |
| --- | --- | --- |
| BM | `arrayInsertionLayer.h`, relaxed eligibility with support-path enumeration | `arrayBMDLayer.h`, pruning and support memoization disabled |
| SA | `arrayInsertionLayer.h`, relaxed eligibility with algebraic support reads | `arrayBMDLayer.h`, pruning disabled with support memoization enabled |
| SAP | `arrayInsertionLayer.h` | `arrayBMDLayer.h` |
| SAP+ | `arrayInsertionPersistent.h` | `arrayBMDPersistent.h` |

BM and SA share the same entry points and are selected by runtime variant parameters. SAP and SAP+ use the shared state entry points. `src/sap_sap_plus/vendor/` contains the Bai baseline implementation, while `src/sap_sap_plus/include/` preserves the relative include layout required by that source.

## Input Convention

Graph files and sample files are two-column integer edge lists. Benchmark entry points generally accept a graph file, a sample file, a direction (`insert` or `delete`), a variant, a sample count, a repeat count, an output file, and a label. Check the `usage` text in each `main*.cpp` file for the exact argument order.

## Reproducibility

Samples are read in file order and do not depend on random numbers. Compile timing and counting variants separately so counting instrumentation does not affect timing measurements.
