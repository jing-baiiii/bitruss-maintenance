






#include "Header.h"
#include "graph.h"
#include "utils.h"
#include "KHeap.h"
#include "statistics.h"
#include "BEIndex.h"
#include "arrayCommon.h"
#include "arrayInsertionLayer.h"
#include "arrayBMDLayer.h"
#include <filesystem>
#include <fcntl.h>
#include <unistd.h>
#include <sys/wait.h>

int main(int argc,char**argv) {
    try {
        if(argc!=8)throw runtime_error("usage: graph samples insert|delete BL|BLC2 N out.tsv dataset");
        string path=argv[1],sampPath=argv[2],dir=argv[3],var=argv[4],outPath=argv[6],label=argv[7];
        size_t N=stoul(argv[5]);
        if((dir!="insert"&&dir!="delete")||(var!="BL"&&var!="BLC2"))throw runtime_error("bad args");
        const bool relax=true,enumer=(var=="BL");          
        const bool pruning=false,memo=(var!="BL");          
        int fd=open(outPath.c_str(),O_WRONLY|O_CREAT|O_EXCL,0644);if(fd<0)throw runtime_error("output exists");close(fd);
        ofstream out(outPath);
        out<<"# dataset="<<label<<" direction="<<dir<<" variant="<<var<<" N="<<N<<" metric=rss_vmhwm forked_cold=1\n";
        out<<"event_id\tu\tv\tbaseline_rss_kib\tpeak_vmhwm_kib\tdelta_kib\n";

        
        shared_ptr<InsertionBase> ibase; InsertionState* iinit=nullptr;
        BEGraphLoMem dbase; vector<intE> diphi,disupp; unordered_map<pair<intV,intV>,intE,pair_hash> dids;
        vector<pair<intV,intV>> ev;
        if(dir=="insert") {
            ibase=make_shared<InsertionBase>();ibase->graph.read_graph(path,0);
            auto& g=ibase->graph;vector<intV> o,inv;g.sort_deg(o);invertMap(o,inv);g.reorder_in_place(inv);
            ibase->left.resize(g.numT);for(intV v=0;v<g.numT;++v)ibase->left[v]=o[v]<g.numU;
            vector<intE> phi,su;arrayBuildBase(g,ibase->index,su,phi);
            iinit=new InsertionState(ibase,phi,vector<uint64_t>(su.begin(),su.end()));
            ifstream in(sampPath);string line;
            while(getline(in,line)&&ev.size()<N){if(line.empty()||line[0]=='#'||line[0]=='%')continue;
                istringstream r(line);uint64_t a,b;if(!(r>>a>>b))continue;
                if(a>=(uint64_t)g.numT||b>=(uint64_t)g.numT||ibase->left[a]==ibase->left[b]
                   ||!g.deg[a]||!g.deg[b]||iinit->findEdge(a,b)!=InsertionState::noEdge)continue;
                ev.push_back({(intV)a,(intV)b});}
        } else {
            Graph g;g.read_graph(path,0);vector<intV> o,inv;g.sort_deg(o);invertMap(o,inv);g.reorder_in_place(inv);
            arrayBuildBase(g,dbase,disupp,diphi);
            for(intE e=0;e<g.numE;++e){auto uv=g.eIdToV[e];dids[{min(uv.first,uv.second),max(uv.first,uv.second)}]=e;}
            ifstream in(sampPath);string line;
            while(getline(in,line)&&ev.size()<N){if(line.empty()||line[0]=='#'||line[0]=='%')continue;
                istringstream r(line);intV a,b;if(!(r>>a>>b))continue;
                if(!dids.count({min(a,b),max(a,b)}))continue; ev.push_back({a,b});}
        }
        if(ev.size()<N)throw runtime_error("insufficient samples");

        for(size_t i=0;i<ev.size();++i) {
            int pipefd[2];if(pipe(pipefd))throw runtime_error("pipe");
            pid_t pid=fork();
            if(pid<0)throw runtime_error("fork");
            if(pid==0) {                                   
                close(pipefd[0]);
                long base_rss=getVmRSS_KB(); resetVmHWM_KB();
                if(dir=="insert"){auto s=*iinit;double mt=0;s.insert(ev[i].first,ev[i].second,nullptr,relax,enumer,&mt);}
                else{auto ix=dbase;auto p=diphi;auto su=disupp;double mt=0;
                     const intE d=dids.at({min(ev[i].first,ev[i].second),max(ev[i].first,ev[i].second)});
                     arrayBMD_layer(ix,p,su,d,pruning,1,nullptr,memo,&mt);}
                long peak=getVmHWM_KB();
                long vals[2]={base_rss,peak};
                ssize_t w=write(pipefd[1],vals,sizeof(vals));(void)w;close(pipefd[1]);_exit(0);
            }
            close(pipefd[1]);
            long vals[2]={0,0}; ssize_t r=read(pipefd[0],vals,sizeof(vals));(void)r;close(pipefd[0]);
            int st;waitpid(pid,&st,0);
            out<<i<<'\t'<<ev[i].first<<'\t'<<ev[i].second<<'\t'<<vals[0]<<'\t'<<vals[1]<<'\t'<<(vals[1]-vals[0])<<'\n';
            out.flush();
        }
        if(!out)throw runtime_error("output failure");
        cout<<"MEM_DONE dataset="<<label<<" dir="<<dir<<" variant="<<var<<" N="<<N<<endl;
    }catch(const exception& e){cerr<<"MEM_FAIL "<<e.what()<<endl;return 1;}
}
