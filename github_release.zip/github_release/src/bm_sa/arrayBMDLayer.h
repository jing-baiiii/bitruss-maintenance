






#ifndef ARRAY_BMD_LAYER_H
#define ARRAY_BMD_LAYER_H
#include "arrayBMDplus.h"
#include <map>
#include <omp.h>
#include <chrono>


struct LayerMetrics {
    long long C=0, candidateUnique=0, supportInitializations=0, phiWrites=0;
    long long seedAttempts=0, seedLost=0, admissionAttempts=0, protectedAdmissions=0;
    long long pruningMemberships=0, supportMemberships=0, supportScans=0;
    long long bloomBuilds=0, bloomHits=0, cascadeBloomGroups=0, cascadeScans=0;
    long long cascadeApplyWedges=0, supportWrites=0, supportLogicalDec=0;
    long long layers=0, batches=0, commitScans=0;
    long long parallelBloomJobs=0, parallelSupportJobs=0;
    size_t residentBytes=0;
};
#ifdef ABP_COUNT_OPS
#define LAYER_EVENT(field, amount) do { if(metrics) metrics->field += (amount); } while(0)
#else
#define LAYER_EVENT(field, amount) do {} while(0)
#endif

struct LayerWorkspace {
    vector<intB> support, bound, good;
    vector<intE> edgeLevel, bloomLevel, touched;
    vector<char> edgeTouched, candidateSeen, pending, peeling;
    vector<intB> bloomTouched;
    vector<long long> bloomBatch;
    long long batchEpoch=0;
    void prepare(size_t n, size_t b) {
        if(support.size()<n) {
            support.resize(n,-1); bound.resize(n,-1); edgeLevel.resize(n,ABP_NOE);
            edgeTouched.resize(n,0); candidateSeen.resize(n,0); pending.resize(n,0); peeling.resize(n,0);
        }
        if(good.size()<b) {
            good.resize(b,0); bloomLevel.resize(b,ABP_NOE); bloomBatch.resize(b,0);
        }
    }
    size_t bytes() const {
        return (support.capacity()+bound.capacity()+good.capacity())*sizeof(intB)
            +(edgeLevel.capacity()+bloomLevel.capacity()+touched.capacity())*sizeof(intE)
            +(edgeTouched.capacity()+candidateSeen.capacity()+pending.capacity()+peeling.capacity())*sizeof(char)
            +bloomBatch.capacity()*sizeof(long long)+bloomTouched.capacity()*sizeof(intB);
    }
};
static thread_local LayerWorkspace layerWorkspace;

static void arrayBMD_layer(BEGraphLoMem& index, vector<intE>& phi, vector<intE>& es,
                            intE deleted, bool pruning=true, int threads=1,
                            LayerMetrics* metrics=nullptr, bool memoSupport=true,
                            double* maintenanceMs=nullptr) {
    auto& ws=layerWorkspace;
    const intE n=phi.size();
    ws.prepare(n,index.bloomDegree.size());
    map<intE,vector<intE>,greater<intE>> roots;
    const intE deletedLevel=phi[deleted];
    vector<pair<intB,intE>> changing;
    for(intB i=index.edgeVI[deleted];i<index.edgeVI[deleted+1];++i)
        if(index.edgeEI[i].first>=0) changing.push_back(index.edgeEI[i]);

    
    
    auto _mt0=std::chrono::steady_clock::now();
    for(auto item:changing) {
        const intB b=item.first; const intE twin=item.second;
        const intB start=index.bloomVI[b], end=start+index.bloomDegree[b];
        intB removedPosition=-1, lost=0;
        for(intB j=start;j<end;++j) {
            LAYER_EVENT(seedAttempts,1);
            auto wedge=index.bloomEI[j];
            if(wedge.first==deleted||wedge.second==deleted) {removedPosition=j;continue;}
            ++lost; --es[wedge.first]; --es[wedge.second];
            const intE L=min(min(deletedLevel,phi[twin]),min(phi[wedge.first],phi[wedge.second]));
            if(L) for(intE e:{twin,wedge.first,wedge.second}) if(phi[e]==L) roots[L].push_back(e);
        }
        es[twin]-=lost;
        LAYER_EVENT(seedLost,lost);
        if(removedPosition<0) throw runtime_error("删除边归属缺少对应 wedge");
        swap(index.bloomEI[removedPosition],index.bloomEI[end-1]);
        --index.bloomDegree[b];
        index.bloomWdgCnt[b]=index.bloomDegree[b];
        abp_removeMembership(index,deleted,b);
        abp_removeMembership(index,twin,b);
        if(index.bloomDegree[b]<=1) {
            for(intB j=start;j<start+index.bloomDegree[b];++j) {
                auto wedge=index.bloomEI[j];
                abp_removeMembership(index,wedge.first,b);
                abp_removeMembership(index,wedge.second,b);
            }
            index.bloomDegree[b]=index.bloomWdgCnt[b]=0;
        }
    }
    es[deleted]=0; phi[deleted]=0;
    
    if(maintenanceMs) *maintenanceMs=std::chrono::duration<double,std::milli>(
        std::chrono::steady_clock::now()-_mt0).count();

    auto protect=[&](intE e,intE L) {
        if(!pruning) return false;
        if(ws.bound[e]<0) {
            ws.bound[e]=0;
            for(intB i=index.edgeVI[e];i<index.edgeVI[e+1];++i) {
                LAYER_EVENT(pruningMemberships,1);
                const intB b=index.edgeEI[i].first;
                if(b>=0) ws.bound[e]=max(ws.bound[e],(intB)index.bloomWdgCnt[b]);
            }
        }
        return ws.bound[e]-1>=(intB)L;
    };
    while(!roots.empty()) {
        auto it=roots.begin(); const intE L=it->first;
        vector<intE> initial=move(it->second); roots.erase(it);
        vector<intE> current, next;
        LAYER_EVENT(layers,1);
        auto activate=[&](intE e) {
            LAYER_EVENT(admissionAttempts,1);
            if(phi[e]!=L||ws.peeling[e]) return;
            if(!ws.edgeTouched[e]) {
                ws.edgeTouched[e]=1; ws.touched.push_back(e);
            }
            if(ws.edgeLevel[e]!=L) {
                ws.edgeLevel[e]=L; ws.support[e]=-1;
                if(protect(e,L)) {LAYER_EVENT(protectedAdmissions,1);return;}
                LAYER_EVENT(C,1);
                ws.candidateSeen[e]=1;
            } else if(protect(e,L)) return;
            if(!ws.pending[e]&&(ws.support[e]<0||ws.support[e]<(intB)L)) {
                ws.pending[e]=1; next.push_back(e);
            }
        };
        for(intE e:initial) activate(e);
        while(!next.empty()) {
            current.clear(); current.swap(next);
            vector<intE> need;
            vector<intB> builds;
            for(intE e:current) {
                ws.pending[e]=0;
                if(ws.support[e]>=0) continue;
                need.push_back(e);
                if(!memoSupport) continue;
                for(intB i=index.edgeVI[e];i<index.edgeVI[e+1];++i) {
                    LAYER_EVENT(supportMemberships,1);
                    const auto item=index.edgeEI[i]; const intB b=item.first;
                    if(b<0||phi[item.second]<L) continue;
                    if(ws.bloomLevel[b]==L) {LAYER_EVENT(bloomHits,1);continue;}
                    if(ws.bloomLevel[b]==ABP_NOE) ws.bloomTouched.push_back(b);
                    ws.bloomLevel[b]=L; builds.push_back(b);
                    LAYER_EVENT(bloomBuilds,1);
                    LAYER_EVENT(supportScans,index.bloomDegree[b]);
                }
            }
            
            if(threads>1&&builds.size()>=64) LAYER_EVENT(parallelBloomJobs,builds.size());
#ifndef L_SINGLE_ONLY
            #pragma omp parallel for num_threads(threads) if(threads>1 && builds.size()>=64) schedule(dynamic,16)
#endif
            for(size_t bi=0;bi<builds.size();++bi) {
                const intB b=builds[bi]; intB g=0;
                for(intB j=index.bloomVI[b];j<index.bloomVI[b]+index.bloomDegree[b];++j) {
                    auto wedge=index.bloomEI[j];
                    if(phi[wedge.first]>=L&&phi[wedge.second]>=L) ++g;
                }
                ws.good[b]=g;
            }
            LAYER_EVENT(supportInitializations,need.size());
            if(threads>1&&need.size()>=64) LAYER_EVENT(parallelSupportJobs,need.size());
            vector<long long> explicitScans;
#ifdef ABP_COUNT_OPS
            if(!memoSupport) explicitScans.resize(need.size(),0);
#endif
#ifndef L_SINGLE_ONLY
            #pragma omp parallel for num_threads(threads) if(threads>1 && need.size()>=64) schedule(dynamic,16)
#endif
            for(size_t ei=0;ei<need.size();++ei) {
                const intE e=need[ei]; intB s=0;
                for(intB i=index.edgeVI[e];i<index.edgeVI[e+1];++i) {
                    const auto item=index.edgeEI[i];
                    if(item.first<0||phi[item.second]<L) continue;
                    if(memoSupport) s+=ws.good[item.first]-1;
                    else {
                        const intB b=item.first;
                        for(intB j=index.bloomVI[b];j<index.bloomVI[b]+index.bloomDegree[b];++j) {
                            auto wedge=index.bloomEI[j];
#ifdef ABP_COUNT_OPS
                            ++explicitScans[ei];
#endif
                            if(wedge.first!=e&&wedge.second!=e&&phi[wedge.first]>=L&&phi[wedge.second]>=L) ++s;
                        }
                    }
                }
                ws.support[e]=s;
            }
            for(auto count:explicitScans) LAYER_EVENT(supportScans,count);
            LAYER_EVENT(supportMemberships, [&](){long long total=0;for(intE e:need)total+=index.edgeVI[e+1]-index.edgeVI[e];return total;}());
            vector<intE> peel;
            vector<intB> affected;
            ++ws.batchEpoch;
            for(intE e:current) if(ws.support[e]<(intB)L) {
                peel.push_back(e); ws.peeling[e]=1;
                for(intB i=index.edgeVI[e];i<index.edgeVI[e+1];++i) {
                    const auto item=index.edgeEI[i]; const intB b=item.first;
                    if(b>=0&&phi[item.second]>=L&&ws.bloomBatch[b]!=ws.batchEpoch) {
                        ws.bloomBatch[b]=ws.batchEpoch; affected.push_back(b);
                    }
                }
            }
            if(peel.empty()) continue;
            LAYER_EVENT(batches,1);
            for(intB b:affected) {
                LAYER_EVENT(cascadeBloomGroups,1);
                vector<pair<intE,intE>> active;
                intB broken=0;
                for(intB j=index.bloomVI[b];j<index.bloomVI[b]+index.bloomDegree[b];++j) {
                    LAYER_EVENT(cascadeScans,1);
                    auto wedge=index.bloomEI[j];
                    if(phi[wedge.first]<L||phi[wedge.second]<L) continue;
                    active.push_back(wedge);
                    if(ws.peeling[wedge.first]||ws.peeling[wedge.second]) ++broken;
                }
                const intB g=active.size();
                
                for(auto wedge:active) {
                    LAYER_EVENT(cascadeApplyWedges,1);
                    const intB loss=(ws.peeling[wedge.first]||ws.peeling[wedge.second])?g-1:broken;
                    for(intE e:{wedge.first,wedge.second}) if(phi[e]==L&&!ws.peeling[e]&&loss>0) {
                        if(ws.edgeLevel[e]==L&&ws.support[e]>=0) {
                            ws.support[e]-=loss;
                            LAYER_EVENT(supportWrites,1); LAYER_EVENT(supportLogicalDec,loss);
                        }
                        activate(e);
                    }
                }
                if(ws.bloomLevel[b]==ABP_NOE) ws.bloomTouched.push_back(b);
                ws.good[b]=g-broken; ws.bloomLevel[b]=L;
            }
            for(intE e:peel) {
                phi[e]=L-1; ws.peeling[e]=0;
                LAYER_EVENT(phiWrites,1);
                if(L>1) roots[L-1].push_back(e);
            }
        }
    }
    if(metrics) {
        
        size_t unique=0;
        for(intE e:ws.touched) if(ws.candidateSeen[e]) ++unique;
        metrics->candidateUnique=unique;
        metrics->residentBytes=ws.bytes();
    }
    for(intE e:ws.touched) {
        ws.edgeTouched[e]=ws.candidateSeen[e]=0; ws.edgeLevel[e]=ABP_NOE; ws.support[e]=-1;
        ws.bound[e]=-1; ws.pending[e]=ws.peeling[e]=0;
    }
    ws.touched.clear();
    for(intB b:ws.bloomTouched) ws.bloomLevel[b]=ABP_NOE;
    ws.bloomTouched.clear();
}
#undef LAYER_EVENT
#endif
