






#include "Header.h"
#include "graph.h"
#include "utils.h"
#include "KHeap.h"
#include "statistics.h"
#include "BEIndex.h"
#include "arrayCommon.h"
#include "arrayBMDLayer.h"
#include <filesystem>

static void oneThread() {
    size_t n=0;for(auto& p:std::filesystem::directory_iterator("/proc/self/task")){(void)p;++n;}
    if(n!=1)throw runtime_error("actual thread count not one");
}

int main(int argc,char**argv) {
    string context;
    try {
        if(argc!=5)throw runtime_error("usage: graph del_samples N dataset_label");
        string path=argv[1];size_t N=stoul(argv[3]);string label=argv[4];
        oneThread();
        Graph graph;graph.read_graph(path,0);
        vector<intV> order,inverse;graph.sort_deg(order);invertMap(order,inverse);graph.reorder_in_place(inverse);
        BEGraphLoMem base;vector<intE> initialPhi,initialSupport;arrayBuildBase(graph,base,initialSupport,initialPhi);
        unordered_map<pair<intV,intV>,intE,pair_hash> edgeIds;edgeIds.reserve(graph.numE);
        for(intE e=0;e<graph.numE;++e){auto uv=graph.eIdToV[e];edgeIds[{min(uv.first,uv.second),max(uv.first,uv.second)}]=e;}
        ifstream input(argv[2]);if(!input)throw runtime_error("samples missing");
        vector<pair<intV,intV>> events;string line;
        while(getline(input,line)&&events.size()<N) {
            if(line.empty()||line[0]=='#'||line[0]=='%')continue;
            istringstream row(line);intV a,b;if(!(row>>a>>b))continue;
            if(!edgeIds.count({min(a,b),max(a,b)}))throw runtime_error("deletion sample edge absent");
            events.push_back({a,b});
        }
        if(events.size()<N)throw runtime_error("insufficient deletion samples");
        struct V {const char* name;bool pruning,memo;};
        vector<V> variants={{"SL",true,true},{"BLC2",false,true},{"BL",false,false}};
        size_t checks=0;
        for(auto var:variants) {
            for(size_t i=0;i<events.size();++i) {
                context="variant="+string(var.name)+" dataset="+label+" event="+to_string(i);
                auto uv=events[i];const intE deleted=edgeIds.at({min(uv.first,uv.second),max(uv.first,uv.second)});
                auto index=base;auto phi=initialPhi;auto support=initialSupport;
                arrayBMD_layer(index,phi,support,deleted,var.pruning,1,nullptr,var.memo);oneThread();
                Graph remaining=graph;deleteEdgeFromG(remaining,uv.first,uv.second);
                auto gold=arrayStaticDecomp(remaining);
                if(phi[deleted]!=0)throw runtime_error("deleted edge phi not zero");
                for(intE e=0;e<remaining.numE&&e<(intE)remaining.eIdToV.size();++e) {
                    auto ep=remaining.eIdToV[e];
                    intE orig=edgeIds.at({min(ep.first,ep.second),max(ep.first,ep.second)});
                    if((intE)phi[orig]!=(intE)gold[e]) {
                        cerr<<"DELETE_GOLD_FAIL "<<context<<" edge="<<orig<<" actual="<<phi[orig]<<" gold="<<gold[e]<<endl;return 4;
                    }
                }
                ++checks;
            }
            cout<<"DELETE_VARIANT_OK variant="<<var.name<<" dataset="<<label<<" events="<<events.size()<<endl;
        }
        cout<<"DELETE_GOLD_ALL_OK dataset="<<label<<" variants=3 checks="<<checks<<" actual_threads=1"<<endl;
    }catch(const exception& e){cerr<<"DELETE_GOLD_ERROR "<<context<<' '<<e.what()<<endl;return 1;}
}
