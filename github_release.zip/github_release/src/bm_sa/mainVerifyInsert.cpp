







#include "Header.h"
#include "graph.h"
#include "utils.h"
#include "KHeap.h"
#include "statistics.h"
#include "BEIndex.h"
#include "arrayCommon.h"
#include "arrayInsertionLayer.h"
#include <chrono>
#include <filesystem>

static void oneThread() {
    size_t n=0;for(auto& p:std::filesystem::directory_iterator("/proc/self/task")){(void)p;++n;}
    if(n!=1)throw runtime_error("actual thread count not one");
}


static long long compareGold(const InsertionState& state,Graph baseGraph,intV u,intV v) {
    insertEdgeIntoG(baseGraph,u,v);                 
    auto gold=arrayStaticDecomp(baseGraph);          
    
    map<pair<intV,intV>,intE> goldByUV;
    for(intE e=0;e<baseGraph.numE&&e<(intE)baseGraph.eIdToV.size();++e) {
        auto uv=baseGraph.eIdToV[e];
        goldByUV[{min(uv.first,uv.second),max(uv.first,uv.second)}]=gold[e];
    }
    for(intE e=0;e<(intE)state.edges();++e) {
        auto uv=state.endpoints(e);
        auto it=goldByUV.find({min(uv.first,uv.second),max(uv.first,uv.second)});
        if(it==goldByUV.end())return e;              
        if((intE)state.phi[e]!=it->second)return e;
    }
    return -1;
}

int main(int argc,char**argv) {
    string context;
    try {
        if(argc!=5)throw runtime_error("usage: graph ins_samples N dataset_label");
        string path=argv[1];size_t N=stoul(argv[3]);string label=argv[4];
        oneThread();
        auto base=make_shared<InsertionBase>();base->graph.read_graph(path,0);
        auto& graph=base->graph;vector<intV> order,inverse;graph.sort_deg(order);invertMap(order,inverse);graph.reorder_in_place(inverse);
        base->left.resize(graph.numT);for(intV v=0;v<graph.numT;++v)base->left[v]=order[v]<graph.numU;
        vector<intE> phi,support;arrayBuildBase(graph,base->index,support,phi);
        InsertionState initial(base,phi,vector<uint64_t>(support.begin(),support.end()));
        Graph baseGraph=graph;                       
        ifstream input(argv[2]);if(!input)throw runtime_error("samples missing");
        vector<pair<intV,intV>> events;string line;
        while(getline(input,line)&&events.size()<N) {
            if(line.empty()||line[0]=='#'||line[0]=='%')continue;
            istringstream row(line);uint64_t a,b;if(!(row>>a>>b))continue;
            if(a>=(uint64_t)graph.numT||b>=(uint64_t)graph.numT||base->left[a]==base->left[b]
               ||!graph.deg[a]||!graph.deg[b]||initial.findEdge(a,b)!=InsertionState::noEdge)
                throw runtime_error("invalid insertion sample row");
            events.push_back({(intV)a,(intV)b});
        }
        if(events.size()<N)throw runtime_error("insufficient insertion samples");
        struct V {const char* name;bool relax,enumer;};
        vector<V> variants={{"SL",false,false},{"BLC2",true,false},{"BL",true,true}};
        size_t checks=0;
        for(auto var:variants) {
            for(size_t i=0;i<events.size();++i) {
                context="variant="+string(var.name)+" dataset="+label+" event="+to_string(i);
                auto state=initial;auto uv=events[i];InsertionMetrics metrics;
                state.insert(uv.first,uv.second,&metrics,var.relax,var.enumer);oneThread();
                long long bad=compareGold(state,baseGraph,uv.first,uv.second);
                if(bad>=0){cerr<<"INSERT_GOLD_FAIL "<<context<<" edge="<<bad<<" phi="<<state.phi[bad]<<endl;return 4;}
                ++checks;
            }
            cout<<"INSERT_VARIANT_OK variant="<<var.name<<" dataset="<<label<<" events="<<events.size()<<endl;
        }
        cout<<"INSERT_GOLD_ALL_OK dataset="<<label<<" variants=3 checks="<<checks<<" actual_threads=1"<<endl;
    }catch(const exception& e){cerr<<"INSERT_GOLD_ERROR "<<context<<' '<<e.what()<<endl;return 1;}
}
