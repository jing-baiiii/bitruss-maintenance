









#include "Header.h"
#include "graph.h"
#include "utils.h"
#include "KHeap.h"
#include "statistics.h"
#include "BEIndex.h"
#include "arrayCommon.h"
#include "arrayInsertionLayer.h"
#include "arrayBMDLayer.h"
#include <chrono>
#include <filesystem>
#include <fcntl.h>
#include <unistd.h>

using Clock=std::chrono::steady_clock;
static void oneThread() {
    size_t n=0;for(auto& p:std::filesystem::directory_iterator("/proc/self/task")){(void)p;++n;}
    if(n!=1)throw runtime_error("actual thread count not one");
}
static double ms_since(Clock::time_point t){return std::chrono::duration<double,std::milli>(Clock::now()-t).count();}

int main(int argc,char**argv) {
    try {
        if(argc!=9)throw runtime_error("usage: graph samples insert|delete BL|BLC2|SL N repeats out.tsv dataset");
        string path=argv[1],sampPath=argv[2],dir=argv[3],var=argv[4],outPath=argv[7],label=argv[8];
        size_t N=stoul(argv[5]);int repeats=atoi(argv[6]);
        if((dir!="insert"&&dir!="delete")||(var!="BL"&&var!="BLC2"&&var!="SL")||!N||repeats<1)
            throw runtime_error("invalid arguments");
        
        const bool relax=(var!="SL"),enumer=(var=="BL");
        
        const bool pruning=(var=="SL"),memo=(var!="BL");
        oneThread();

        int fd=open(outPath.c_str(),O_WRONLY|O_CREAT|O_EXCL,0644);if(fd<0)throw runtime_error("output exists");close(fd);
        ofstream out(outPath);
        out<<"# dataset="<<label<<" direction="<<dir<<" variant="<<var<<" N="<<N<<" repeats="<<repeats
           <<" threads=1 warmup=1 clock=steady\n";
#ifdef BENCH_COUNT
        out<<"# mode=count time_is_diagnostic=1\n";
        out<<"event_id\trepeat\tu\tv\ttotal_ms\tmaintenance_ms\tdecomp_ms\talgebra_reads\tpath_pair_probes"
             "\tcandidates\tcandidate_unique\tsupport_scans\tbloom_builds\tbloom_hits\tlayers\tbatches\n";
#else
        out<<"# mode=time counts=0\n";
        out<<"event_id\trepeat\tu\tv\ttotal_ms\tmaintenance_ms\tdecomp_ms\n";
#endif

        if(dir=="insert") {
            auto base=make_shared<InsertionBase>();base->graph.read_graph(path,0);
            auto& graph=base->graph;vector<intV> order,inverse;graph.sort_deg(order);invertMap(order,inverse);graph.reorder_in_place(inverse);
            base->left.resize(graph.numT);for(intV v=0;v<graph.numT;++v)base->left[v]=order[v]<graph.numU;
            vector<intE> phi,support;arrayBuildBase(graph,base->index,support,phi);
            InsertionState initial(base,phi,vector<uint64_t>(support.begin(),support.end()));
            ifstream input(sampPath);vector<pair<intV,intV>> ev;string line;
            while(getline(input,line)&&ev.size()<N){if(line.empty()||line[0]=='#'||line[0]=='%')continue;
                istringstream r(line);uint64_t a,b;if(!(r>>a>>b))continue;
                if(a>=(uint64_t)graph.numT||b>=(uint64_t)graph.numT||base->left[a]==base->left[b]
                   ||!graph.deg[a]||!graph.deg[b]||initial.findEdge(a,b)!=InsertionState::noEdge)
                    throw runtime_error("invalid insertion sample");
                ev.push_back({(intV)a,(intV)b});}
            if(ev.size()<N)throw runtime_error("insufficient insertion samples");
            { auto s=initial;InsertionMetrics m;s.insert(ev[0].first,ev[0].second,&m,relax,enumer); } 
            for(int rep=0;rep<repeats;++rep)for(size_t i=0;i<ev.size();++i) {
                auto s=initial;double mt=0;
#ifdef BENCH_COUNT
                InsertionMetrics m;
                auto t0=Clock::now();s.insert(ev[i].first,ev[i].second,&m,relax,enumer,&mt);double tot=ms_since(t0);oneThread();
                out<<i<<'\t'<<rep<<'\t'<<ev[i].first<<'\t'<<ev[i].second<<'\t'<<setprecision(12)<<tot<<'\t'<<mt<<'\t'<<(tot-mt)
                   <<'\t'<<m.algebraReads<<'\t'<<m.pathPairProbes<<'\t'<<m.candidates<<'\t'<<m.candidateUnique
                   <<'\t'<<m.supportWedgeScans<<'\t'<<m.bloomBuilds<<'\t'<<m.bloomHits<<'\t'<<m.layers<<'\t'<<m.batches<<'\n';
#else
                auto t0=Clock::now();s.insert(ev[i].first,ev[i].second,nullptr,relax,enumer,&mt);double tot=ms_since(t0);oneThread();
                out<<i<<'\t'<<rep<<'\t'<<ev[i].first<<'\t'<<ev[i].second<<'\t'<<setprecision(12)<<tot<<'\t'<<mt<<'\t'<<(tot-mt)<<'\n';
#endif
                out.flush();
            }
        } else {
            Graph graph;graph.read_graph(path,0);
            vector<intV> order,inverse;graph.sort_deg(order);invertMap(order,inverse);graph.reorder_in_place(inverse);
            BEGraphLoMem base;vector<intE> iphi,isupp;arrayBuildBase(graph,base,isupp,iphi);
            unordered_map<pair<intV,intV>,intE,pair_hash> ids;ids.reserve(graph.numE);
            for(intE e=0;e<graph.numE;++e){auto uv=graph.eIdToV[e];ids[{min(uv.first,uv.second),max(uv.first,uv.second)}]=e;}
            ifstream input(sampPath);vector<pair<intV,intV>> ev;string line;
            while(getline(input,line)&&ev.size()<N){if(line.empty()||line[0]=='#'||line[0]=='%')continue;
                istringstream r(line);intV a,b;if(!(r>>a>>b))continue;
                if(!ids.count({min(a,b),max(a,b)}))throw runtime_error("deletion sample absent");
                ev.push_back({a,b});}
            if(ev.size()<N)throw runtime_error("insufficient deletion samples");
            { auto ix=base;auto p=iphi;auto su=isupp;const intE d=ids.at({min(ev[0].first,ev[0].second),max(ev[0].first,ev[0].second)});
              arrayBMD_layer(ix,p,su,d,pruning,1,nullptr,memo); } 
            for(int rep=0;rep<repeats;++rep)for(size_t i=0;i<ev.size();++i) {
                const intE d=ids.at({min(ev[i].first,ev[i].second),max(ev[i].first,ev[i].second)});
                auto ix=base;auto p=iphi;auto su=isupp;double mt=0;
#ifdef BENCH_COUNT
                LayerMetrics m;
                auto t0=Clock::now();arrayBMD_layer(ix,p,su,d,pruning,1,&m,memo,&mt);double tot=ms_since(t0);oneThread();
                
                
                long long algebra=memo?m.supportMemberships:0, probes=memo?0:m.supportScans;
                out<<i<<'\t'<<rep<<'\t'<<ev[i].first<<'\t'<<ev[i].second<<'\t'<<setprecision(12)<<tot<<'\t'<<mt<<'\t'<<(tot-mt)
                   <<'\t'<<algebra<<'\t'<<probes<<'\t'<<m.C<<'\t'<<m.candidateUnique
                   <<'\t'<<m.supportScans<<'\t'<<m.bloomBuilds<<'\t'<<m.bloomHits<<'\t'<<m.layers<<'\t'<<m.batches<<'\n';
#else
                auto t0=Clock::now();arrayBMD_layer(ix,p,su,d,pruning,1,nullptr,memo,&mt);double tot=ms_since(t0);oneThread();
                out<<i<<'\t'<<rep<<'\t'<<ev[i].first<<'\t'<<ev[i].second<<'\t'<<setprecision(12)<<tot<<'\t'<<mt<<'\t'<<(tot-mt)<<'\n';
#endif
                out.flush();
            }
        }
        if(!out)throw runtime_error("output failure");
        cout<<"BENCH_DONE dataset="<<label<<" dir="<<dir<<" variant="<<var<<" N="<<N<<" repeats="<<repeats<<endl;
    }catch(const exception& e){cerr<<"BENCH_FAIL "<<e.what()<<endl;return 1;}
}
