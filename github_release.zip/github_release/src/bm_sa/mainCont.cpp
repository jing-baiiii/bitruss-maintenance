






#include "Header.h"
#include "graph.h"
#include "utils.h"
#include "KHeap.h"
#include "statistics.h"
#include "BEIndex.h"
#include "arrayCommon.h"
#include "arrayInsertionLayer.h"
#include <chrono>
#include <filesystem>
#include <set>

using Clock=std::chrono::steady_clock;

int main(int argc,char**argv) {
    try {
        if(argc!=6)throw runtime_error("usage: graph ins_samples BL|BLC2 out_prefix dataset");
        string path=argv[1],sampPath=argv[2],var=argv[3],prefix=argv[4],label=argv[5];
        if(var!="BL"&&var!="BLC2")throw runtime_error("variant BL|BLC2");
        const bool relax=true,enumer=(var=="BL");
        auto base=make_shared<InsertionBase>();base->graph.read_graph(path,0);
        auto& g=base->graph;vector<intV> o,inv;g.sort_deg(o);invertMap(o,inv);g.reorder_in_place(inv);
        base->left.resize(g.numT);for(intV v=0;v<g.numT;++v)base->left[v]=o[v]<g.numU;
        vector<intE> phi,su;arrayBuildBase(g,base->index,su,phi);
        InsertionState state(base,phi,vector<uint64_t>(su.begin(),su.end()));
        
        ifstream in(sampPath);string line;vector<pair<intV,intV>> stream;set<pair<intV,intV>> seen;
        while(getline(in,line)){if(line.empty()||line[0]=='#'||line[0]=='%')continue;
            istringstream r(line);uint64_t a,b;if(!(r>>a>>b))continue;
            if(a>=(uint64_t)g.numT||b>=(uint64_t)g.numT||base->left[a]==base->left[b]||!g.deg[a]||!g.deg[b])continue;
            auto key=make_pair(min((intV)a,(intV)b),max((intV)a,(intV)b));
            if(!seen.insert(key).second)continue;
            if(state.findEdge((intV)a,(intV)b)!=InsertionState::noEdge)continue;
            stream.push_back({(intV)a,(intV)b});}
        if(stream.empty())throw runtime_error("empty stream");

        ofstream ev(prefix+"_events.tsv"),st(prefix+"_structures.tsv");
        ev<<"# dataset="<<label<<" variant="<<var<<" stream_len="<<stream.size()<<" direction=insert\n";
        ev<<"step\tu\tv\tnew_eid\tmaintenance_ms\tdecomp_ms\tstep_ms\tcumulative_ms\n";
        st<<"# dataset="<<label<<" variant="<<var<<"\n";
        st<<"step\tedges\tblooms\twedge_paths\tmemberships\n";
        auto structDump=[&](size_t step){
            
            size_t blooms=state.blooms();
            size_t wedgePaths=0,members=0;
            for(intB b=0;b<(intB)blooms;++b)state.wedges(b,[&](auto){++wedgePaths;});
            for(intE e=0;e<(intE)state.edges();++e)state.memberships(e,[&](auto){++members;});
            st<<step<<'\t'<<state.edges()<<'\t'<<blooms<<'\t'<<wedgePaths<<'\t'<<members<<'\n';
        };
        structDump(0);
        double cumulative=0;const size_t n=stream.size();
        set<size_t> checkpoints={0,n/4,n/2,(3*n)/4,n>0?n-1:0};
        for(size_t i=0;i<n;++i) {
            auto uv=stream[i];double mt=0;
            auto t0=Clock::now();intE added=state.insert(uv.first,uv.second,nullptr,relax,enumer,&mt);
            double step=std::chrono::duration<double,std::milli>(Clock::now()-t0).count();
            cumulative+=step;
            ev<<i<<'\t'<<uv.first<<'\t'<<uv.second<<'\t'<<added<<'\t'<<setprecision(12)<<mt<<'\t'<<(step-mt)
              <<'\t'<<step<<'\t'<<cumulative<<'\n';
            if(checkpoints.count(i))structDump(i+1);
        }
        ev.flush();st.flush();if(!ev||!st)throw runtime_error("output failure");
        cout<<"CONT_DONE dataset="<<label<<" variant="<<var<<" stream_len="<<n
            <<" final_edges="<<state.edges()<<" cumulative_ms="<<cumulative<<endl;
    }catch(const exception& e){cerr<<"CONT_FAIL "<<e.what()<<endl;return 1;}
}
