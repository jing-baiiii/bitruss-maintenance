#include "graph/abstract_bipartite_graph.h"
#include "wing/quasi_wing_maintenance.h"
#include "Header.h"
#include "graph.h"
#include "utils.h"
#include "KHeap.h"
#include "statistics.h"
#include "BEIndex.h"
#include "arrayCommon.h"
#include "arrayPsi.h"
#include "state.h"
using scnu::abstract_bipartite_edge;
using scnu::abstract_bipartite_graph;
#include "baiBench.h"
#include <filesystem>
#include <chrono>
#include <iomanip>
#include <sched.h>
#include <sys/resource.h>
#include <sys/wait.h>
#include <unistd.h>
#include <malloc.h>

using MemoryClock=std::chrono::steady_clock;
static double memoryMs(MemoryClock::time_point start) {
    return chrono::duration<double,milli>(MemoryClock::now()-start).count();
}
static long memoryField(const string& key) {
    ifstream f("/proc/self/status");string line;
    while(getline(f,line))if(line.rfind(key+":",0)==0) {
        istringstream value(line.substr(key.size()+1));long n;value>>n;return n;
    }
    throw runtime_error("missing proc memory field");
}
static void requireSingleThread() {
    if(memoryField("Threads")!=1)throw runtime_error("memory worker is not single threaded");
}
struct MemoryResult {long baseline,current,hwm,usage;double ms;uint64_t checksum;int error;};

int main(int argc,char** argv) {
    try {
        if(argc!=10)throw runtime_error("graph samples direction variant output repeats limit cpu mode required");
        string direction=argv[3],variant=argv[4];int limit=stoi(argv[7]),cpu=stoi(argv[8]);
        if((direction!="insert"&&direction!="delete")||stoi(argv[6])!=1||string(argv[9])!="rss"||limit<1||limit>500)
            throw runtime_error("invalid memory arguments");
        if(variant!="BAI"&&variant!="PB"&&variant!="SL"&&variant!="AF")throw runtime_error("invalid variant");
        cpu_set_t mask;CPU_ZERO(&mask);CPU_SET(cpu,&mask);
        if(sched_setaffinity(0,sizeof(mask),&mask))throw runtime_error("affinity failed");
        filesystem::path folder=argv[5];if(!filesystem::create_directory(folder))throw runtime_error("output exists");
        auto totalStart=MemoryClock::now(),start=totalStart;
        auto base=make_shared<InsertionBase>();string path=argv[1];base->graph.read_graph(path,0);
        double readMs=memoryMs(start);start=MemoryClock::now();
        vector<intV> order,inverse;base->graph.sort_deg(order);invertMap(order,inverse);base->graph.reorder_in_place(inverse);
        base->left.resize(base->graph.numT);for(intV v=0;v<base->graph.numT;++v)base->left[v]=order[v]<base->graph.numU;
        label_edges(base->graph);edgeId_to_vertices(base->graph);
        double orderMs=memoryMs(start);start=MemoryClock::now();
        vector<intE> es(base->graph.numE,0),phi(base->graph.numE,0);
        {vector<intV> wedgeCount(base->graph.numT,0);creat_BEIndex(base->graph,es,base->index,wedgeCount);}
        double indexMs=memoryMs(start);start=MemoryClock::now();
        {auto copy=base->index;auto tip=es;fine_peel_part_wing(copy,tip,phi);}
        double peelMs=memoryMs(start);
        auto sampleStart=MemoryClock::now();
        vector<pair<intV,intV>> updates;vector<intE> removed;
        ifstream sample(argv[2]);string line;
        while(getline(sample,line)) {
            if(line.empty()||line[0]=='#'||line[0]=='%')continue;
            istringstream row(line);intV u,v;if(!(row>>u>>v))throw runtime_error("invalid sample");
            updates.emplace_back(u,v);removed.push_back(findEntity(base->graph,u,v));
        }
        if(updates.size()!=500)throw runtime_error("expected 500 samples");
        for(size_t i=0;i<updates.size();++i)if((direction=="insert")!=(removed[i]==ABP_NOE))throw runtime_error("sample presence mismatch");
        double sampleMs=memoryMs(sampleStart);
        intE edges=base->graph.numE;intV vertices=base->graph.numT;
        unique_ptr<InsertionState> sl;unique_ptr<PBState> pb;unique_ptr<InsertionPersistentState> af;
        unique_ptr<DeleteState> deletion;unique_ptr<BaiBench> bai;
        double supportMs=0,bridgeMs=0;
        start=MemoryClock::now();
        if(variant=="BAI") {
            vector<intB> h;buildPersistentSupport(base->index,phi,h);
            vector<intE> own(h.begin(),h.end());supportMs=memoryMs(start);start=MemoryClock::now();
            InsertionState initial(base,phi,vector<uint64_t>(es.begin(),es.end()));
            bai=make_unique<BaiBench>(initial,own);bridgeMs=memoryMs(start);
        }else if(direction=="insert") {
            if(variant=="PB")pb=make_unique<PBState>(base,phi,vector<uint64_t>(es.begin(),es.end()));
            else if(variant=="SL")sl=make_unique<InsertionState>(base,phi,vector<uint64_t>(es.begin(),es.end()));
            else {
                InsertionState initial(base,phi,vector<uint64_t>(es.begin(),es.end()));
                auto hStart=MemoryClock::now();af=make_unique<InsertionPersistentState>(initial);supportMs=memoryMs(hStart);
            }
        }else {
            vector<intB> h;
            if(variant=="AF") {buildPersistentSupport(base->index,phi,h);supportMs=memoryMs(start);}
            deletion=make_unique<DeleteState>(*base,phi,es,h);
        }
        double stateMs=memoryMs(start);
        
        vector<intE>().swap(es);vector<intE>().swap(phi);vector<intV>().swap(order);vector<intV>().swap(inverse);
        if(bai||deletion)base.reset();
        malloc_trim(0);
        requireSingleThread();
        double preparationTotalMs=memoryMs(totalStart),totalMs=preparationTotalMs-sampleMs;
        ofstream events(folder/"events.tsv");events<<"event_id\treplicate\tbaseline_rss_kib\tcurrent_rss_kib\tpeak_rss_kib\trusage_peak_kib\tupdate_ms_diagnostic\tchecksum\n";
        auto one=[&](int id,bool emit) {
            int pipefd[2];if(pipe(pipefd))throw runtime_error("pipe failed");
            pid_t child=fork();if(child<0)throw runtime_error("fork failed");
            if(child==0) {
                close(pipefd[0]);MemoryResult result{};
                try {
                    requireSingleThread();
                    if(!bai&&!deletion) {
                        auto* state=pb?static_cast<InsertionState*>(pb.get()):af?static_cast<InsertionState*>(af.get()):sl.get();
                        state->phi.reserve(state->edges()+1);state->es.reserve(state->edges()+1);if(af)af->h.reserve(af->edges()+1);
                    }
                    result.baseline=memoryField("VmRSS");auto uv=updates[id];
                    auto t=MemoryClock::now();
                    if(bai) {
                        auto input=make_shared<unordered_set<BaiBench::Edge>>();
                        if(direction=="insert") {
                            
                            if(!bai->graph->get_left_vertex_map()->count(uv.first))swap(uv.first,uv.second);
                            auto edge=make_shared<abstract_bipartite_edge>(uv.first,uv.second);input->insert(edge);
                            uint32_t old=*bai->maxPhi;bai->insert(input);*bai->maxPhi=max(old,bai->phi->at(edge));
                        }else {
                            input->insert(bai->edges[removed[id]]);
                            scnu::quasi_wing_maintenance::remove2(bai->graph,bai->locks,input,bai->rank,bai->phi,bai->ws,bai->maxPhi,bai->pool);
                        }
                        result.checksum=*bai->maxPhi;
                    }else if(deletion) {deletion->remove(removed[id],variant);result.checksum=deletion->graph.numE;}
                    else {
                        auto* state=pb?static_cast<InsertionState*>(pb.get()):af?static_cast<InsertionState*>(af.get()):sl.get();
                        if(pb)pb->insert(uv.first,uv.second);else if(af)af->insert(uv.first,uv.second);else sl->insert(uv.first,uv.second);
                        result.checksum=state->edges();
                    }
                    result.ms=memoryMs(t);result.current=memoryField("VmRSS");result.hwm=memoryField("VmHWM");
                    requireSingleThread();
                    rusage usage{};getrusage(RUSAGE_SELF,&usage);result.usage=usage.ru_maxrss;
                }catch(const exception&) {result.error=1;}
                ssize_t n=write(pipefd[1],&result,sizeof(result));close(pipefd[1]);_exit(n==sizeof(result)&&!result.error?0:1);
            }
            close(pipefd[1]);MemoryResult result{};ssize_t received=read(pipefd[0],&result,sizeof(result));close(pipefd[0]);
            int status;waitpid(child,&status,0);
            if(received!=sizeof(result)||!WIFEXITED(status)||WEXITSTATUS(status)||result.error)throw runtime_error("memory worker failed");
            if(emit)events<<id<<"\t0\t"<<result.baseline<<'\t'<<result.current<<'\t'<<result.hwm<<'\t'<<result.usage<<'\t'<<setprecision(17)<<result.ms<<'\t'<<result.checksum<<'\n';
        };
        one(0,false);for(int i=0;i<limit;++i)one(i,true);
        ofstream status(folder/"status.json");
        status<<setprecision(17)<<"{\"events\":"<<limit<<",\"repeats\":1,\"warmup\":1,\"actual_threads\":1,\"cpu\":"<<cpu
              <<",\"verified\":0,\"vertices\":"<<vertices<<",\"edges\":"<<edges<<",\"read_ms\":"<<readMs<<",\"order_ms\":"<<orderMs
              <<",\"index_ms\":"<<indexMs<<",\"peel_ms\":"<<peelMs<<",\"support_ms\":"<<supportMs<<",\"state_ms\":"<<stateMs
              <<",\"bridge_ms\":"<<bridgeMs<<",\"initialization_total_ms\":"<<totalMs
              <<",\"sample_preparation_ms\":"<<sampleMs<<",\"preparation_total_ms\":"<<preparationTotalMs
              <<",\"mode\":\"rss\",\"variant\":\""<<variant<<"\",\"direction\":\""<<direction<<"\"}\n";
        if(!events||!status)throw runtime_error("output failed");
        cout<<"MEMORY_PASS "<<variant<<' '<<direction<<' '<<limit<<endl;
    }catch(const exception& e) {cerr<<"MEMORY_FAIL "<<e.what()<<endl;return 1;}
}
