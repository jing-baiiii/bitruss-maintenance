#include "Header.h"
#include "graph.h"
#include "utils.h"
#include "KHeap.h"
#include "statistics.h"
#include "BEIndex.h"
#include "arrayCommon.h"
#include "state.h"
#include "arrayBMDLayer.h"
#include "arrayBMDPersistent.h"
#include <chrono>
#include <filesystem>
#include <iomanip>
#include <sched.h>

using Clock = chrono::steady_clock;
static double elapsedMilliseconds(Clock::time_point start) {
    return chrono::duration<double,milli>(Clock::now()-start).count();
}
static void requireSingleThread() {
    size_t n=0;for(auto& entry:filesystem::directory_iterator("/proc/self/task")){(void)entry;++n;}
    if(n!=1)throw runtime_error("actual thread count not one");
}
static void writeHistogram(ofstream& out,size_t step,const string& kind,const vector<uint64_t>& values) {
    map<uint64_t,uint64_t> histogram;
    for(auto x:values)++histogram[x];
    for(auto item:histogram)out<<step<<'\t'<<kind<<'\t'<<item.first<<'\t'<<item.second<<'\n';
    out.flush();
}

int main(int argc,char** argv) {
    size_t event=0;string phase="initialization";
    try {
        if(argc!=7)throw runtime_error("mode graph samples output repeats cpu required");
        const bool insertion=string(argv[1])=="insert";
        if(!insertion&&string(argv[1])!="delete")throw runtime_error("invalid mode");
        const int repeats=stoi(argv[5]),cpu=stoi(argv[6]);
        if(repeats<1)throw runtime_error("invalid repeats");
        cpu_set_t affinity;CPU_ZERO(&affinity);CPU_SET(cpu,&affinity);
        if(sched_setaffinity(0,sizeof(affinity),&affinity))throw runtime_error("affinity failed");
        requireSingleThread();filesystem::path output=argv[4];
        if(!filesystem::create_directory(output))throw runtime_error("output exists");
        ofstream eventsOut(output/"events.tsv"),queryOut(output/"query_histograms.tsv"),structures(output/"structures.tsv");
        eventsOut<<"repeat\tevent\tu\tv\ttime_ms\trss_before_kib\trss_after_kib\thwm_after_kib\n";
        queryOut<<"step\tkind\tvalue\tfrequency\n";
        structures<<"step\tkind\tedges\tblooms\twedge_paths\tmemberships\n";
        auto started=Clock::now();
        auto base=make_shared<InsertionBase>();string filename=argv[2];base->graph.read_graph(filename,0);
        vector<intV> order,inverse;base->graph.sort_deg(order);invertMap(order,inverse);base->graph.reorder_in_place(inverse);
        base->left.resize(base->graph.numT);
        for(intV v=0;v<base->graph.numT;++v)base->left[v]=order[v]<base->graph.numU;
        vector<intE> initialPhi,initialES;
        arrayBuildBase(base->graph,base->index,initialES,initialPhi);
        const double loadBuildMs=elapsedMilliseconds(started);
        vector<pair<intV,intV>> events;set<pair<intV,intV>> seen;
        ifstream input(argv[3]);string line;size_t lines=0;
        if(!input)throw runtime_error("samples missing");
        while(getline(input,line)) {
            if(line.empty()||line[0]=='#'||line[0]=='%')continue;
            istringstream row(line);intV u,v;string extra;
            if(!(row>>u>>v)||(row>>extra)||u>=base->graph.numT||v>=base->graph.numT||base->left[u]==base->left[v])
                throw runtime_error("invalid sample");
            ++lines;if(seen.emplace(min(u,v),max(u,v)).second)events.push_back({u,v});
        }
        if(lines!=500)throw runtime_error("expected 500 input rows");
        auto findInitial=[&](intV u,intV v)->intE {
            const auto& list=base->graph.adj[u];auto it=lower_bound(list.begin(),list.end(),v);
            if(it==list.end()||*it!=v)return InsertionState::noEdge;
            return base->graph.eId[u][it-list.begin()];
        };
        vector<intE> deleted;
        for(auto uv:events) {
            auto id=findInitial(uv.first,uv.second);
            if(insertion?(id!=InsertionState::noEdge):(id==InsertionState::noEdge))throw runtime_error("sample presence mismatch");
            deleted.push_back(id);
        }
        started=Clock::now();
        unique_ptr<InsertionPersistentState> initial;
        vector<intB> initialH;
        if(insertion)initial=make_unique<InsertionPersistentState>(base,initialPhi,vector<uint64_t>(initialES.begin(),initialES.end()));
        else buildPersistentSupport(base->index,initialPhi,initialH);
        const double hInitMs=elapsedMilliseconds(started);
        size_t goldChecks=0;uint64_t checksum=0;long maintenanceHwm=0;
        for(int repeat=-1;repeat<repeats;++repeat) {
            unique_ptr<InsertionPersistentState> state;
            BEGraphLoMem index;vector<intE> phi,es;vector<intB> h;
            Graph currentGraph;if(!insertion)currentGraph=base->graph;
            vector<char> present(base->graph.numE,1);PersistentWorkspace work;
            if(insertion)state=make_unique<InsertionPersistentState>(*initial);
            else {index=base->index;phi=initialPhi;es=initialES;h=initialH;}
            const size_t count=repeat<0?1:events.size();
            auto checkpoint=[&](size_t step) {
                if(!insertion) {
                    size_t live=0;for(intE e=0;e<present.size();++e) {
                        auto uv=base->graph.eIdToV[e];
                        auto a=findEntity(currentGraph,uv.first,uv.second),b=findEntity(currentGraph,uv.second,uv.first);
                        if(present[e]) {++live;if(a!=e||b!=e)throw runtime_error("live adjacency mismatch");}
                        else if(a!=ABP_NOE||b!=ABP_NOE)throw runtime_error("deleted adjacency retained");
                    }
                    if(live!=currentGraph.numE)throw runtime_error("current edge count mismatch");
                    for(intV v=0;v<currentGraph.numT;++v)
                        if(currentGraph.deg[v]!=currentGraph.adj[v].size()||currentGraph.eId[v].size()!=currentGraph.adj[v].size())
                            throw runtime_error("current degree mismatch");
                }
                vector<uint64_t> degree(insertion?state->blooms():index.numV),q,slots;
                uint64_t blooms=0,paths=0,members=0;
                for(size_t b=0;b<degree.size();++b) {
                    if(insertion)state->wedges(b,[&](auto){++degree[b];});else degree[b]=index.bloomDegree[b];
                    if(degree[b]>=2){++blooms;paths+=degree[b];}
                }
                const size_t n=insertion?state->edges():phi.size();q.reserve(n);slots.reserve(n);
                for(intE e=0;e<n;++e) {
                    if(!insertion&&!present[e])continue;
                    uint64_t visits=0,memberSlots=0,totalSupport=0;
                    auto membership=[&](auto item) {
                        ++members;if(degree[item.first]<2)throw runtime_error("membership in degenerate bloom");
                        visits+=degree[item.first];totalSupport+=degree[item.first]-1;
                    };
                    if(insertion)state->memberships(e,[&](auto item){membership(item);++memberSlots;});
                    else for(intB j=index.edgeVI[e];j<index.edgeVI[e+1];++j) {
                        ++memberSlots;if(index.edgeEI[j].first>=0)membership(index.edgeEI[j]);
                    }
                    if(totalSupport!=(insertion?state->es[e]:(uint64_t)es[e]))throw runtime_error("query/index total support mismatch");
                    q.push_back(visits);slots.push_back(memberSlots);
                }
                if(members!=2*paths)throw runtime_error("asymmetric memberships");
                writeHistogram(queryOut,step,"maintained_wedge_visits",q);writeHistogram(queryOut,step,"maintained_membership_slots",slots);
                structures<<step<<"\tmaintained\t"<<q.size()<<'\t'<<blooms<<'\t'<<paths<<'\t'<<members<<'\n';structures.flush();
            };
            if(repeat==0)checkpoint(0);
            phase=repeat<0?"warmup":"maintenance";
            if(repeat>=0)resetVmHWM_KB();
            for(event=0;event<count;++event) {
                auto uv=events[event];const long rssBefore=getVmRSS_KB();auto t=Clock::now();
                if(insertion)state->insert(uv.first,uv.second);
                else {
                    arrayBMDPersistent(index,phi,es,h,deleted[event],work);
                    eraseEntity(currentGraph,deleted[event]);
                    present[deleted[event]]=0;
                }
                const double elapsed=elapsedMilliseconds(t);const long rssAfter=getVmRSS_KB(),hwm=getVmHWM_KB();
                maintenanceHwm=max(maintenanceHwm,hwm);requireSingleThread();
                if(repeat>=0) {
                    eventsOut<<repeat<<'\t'<<event<<'\t'<<uv.first<<'\t'<<uv.second<<'\t'<<setprecision(12)<<elapsed
                        <<'\t'<<rssBefore<<'\t'<<rssAfter<<'\t'<<hwm<<'\n';eventsOut.flush();
                    if(repeat==0&&(event+1==100||event+1==250||event+1==events.size()))checkpoint(event+1);
                }
            }
            if(repeat<0)continue;
            if(repeat==0) {
                phase="terminal_static_validation";Graph rebuilt=base->graph;
                for(auto uv:events) {
                    if(insertion)insertEdgeIntoG(rebuilt,uv.first,uv.second);else deleteEdgeFromG(rebuilt,uv.first,uv.second);
                }
                vector<intV> freshOrder,freshInverse;rebuilt.sort_deg(freshOrder);invertMap(freshOrder,freshInverse);rebuilt.reorder_in_place(freshInverse);
                BEGraphLoMem goldIndex;vector<intE> goldPhi,goldES;
                arrayBuildBase(rebuilt,goldIndex,goldES,goldPhi);
                vector<intB> goldH;buildPersistentSupport(goldIndex,goldPhi,goldH);
                vector<uint64_t> q,slots;q.reserve(rebuilt.numE);slots.reserve(rebuilt.numE);
                uint64_t paths=0,blooms=0;
                for(auto degree:goldIndex.bloomDegree)if(degree>=2){++blooms;paths+=degree;}
                for(intE e=0;e<rebuilt.numE;++e) {
                    auto uv=rebuilt.eIdToV[e];uv={freshOrder[uv.first],freshOrder[uv.second]};
                    const intE id=insertion?state->findEdge(uv.first,uv.second):findInitial(uv.first,uv.second);
                    if(id==InsertionState::noEdge||(!insertion&&!present[id]))throw runtime_error("terminal edge mapping mismatch");
                    if(goldPhi[e]!=(insertion?state->phi[id]:phi[id])||goldES[e]!=(insertion?state->es[id]:(uint64_t)es[id])
                        ||(uint64_t)goldH[e]!=(insertion?state->h[id]:(uint64_t)h[id]))throw runtime_error("terminal static phi/es/h mismatch");
                    uint64_t visits=0;
                    for(intB j=goldIndex.edgeVI[e];j<goldIndex.edgeVI[e+1];++j)visits+=goldIndex.bloomDegree[goldIndex.edgeEI[j].first];
                    q.push_back(visits);slots.push_back(goldIndex.edgeVI[e+1]-goldIndex.edgeVI[e]);checksum+=goldPhi[e];
                }
                if(rebuilt.numE!=(insertion?state->edges():base->graph.numE-events.size()))throw runtime_error("terminal edge count mismatch");
                writeHistogram(queryOut,events.size(),"rebuilt_wedge_visits",q);writeHistogram(queryOut,events.size(),"rebuilt_membership_slots",slots);
                structures<<events.size()<<"\trebuilt\t"<<rebuilt.numE<<'\t'<<blooms<<'\t'<<paths<<'\t'<<2*paths<<'\n';
                ++goldChecks;
            }
            cout<<"CONTINUOUS_REPEAT_DONE repeat="<<repeat<<" events="<<events.size()<<endl;
        }
        ofstream status(output/"status.json");
        status<<"{\"mode\":\""<<(insertion?"insert":"delete")<<"\",\"input_rows\":"<<lines<<",\"unique_events\":"<<events.size()
            <<",\"repeats\":"<<repeats<<",\"actual_threads\":1,\"cpu\":"<<cpu<<",\"warmup_independent_events\":1"
            <<",\"static_terminal_checks\":"<<goldChecks<<",\"every_event_static_gold\":false,\"load_build_ms\":"<<loadBuildMs
            <<",\"h_initialization_ms\":"<<hInitMs<<",\"maintenance_process_hwm_kib\":"<<maintenanceHwm
            <<",\"checksum\":"<<checksum<<",\"failures\":0}\n";
        if(!eventsOut||!queryOut||!structures||!status)throw runtime_error("output failure");
        cout<<"CONTINUOUS_PASS events="<<events.size()<<" repeats="<<repeats<<" terminal_static_checks="<<goldChecks<<endl;
    }catch(const exception& e){cerr<<"CONTINUOUS_FAIL phase="<<phase<<" event="<<event<<' '<<e.what()<<endl;return 1;}
}
