#ifndef STATE_H
#define STATE_H
#include "arrayInsertionLayer.h"
#include "arrayInsertionPB.h"
#include "arrayInsertionPersistent.h"
#include "arrayBMDplus.h"
#include "arrayDeletionPB.h"
#include "arrayBMDLayer.h"
#include "arrayBMDPersistent.h"

static void eraseEntity(Graph& graph,intE edge) {
    const auto uv=graph.eIdToV.at(edge);
    for(auto p:{uv,make_pair(uv.second,uv.first)}) {
        auto& adjacent=graph.adj.at(p.first);
        auto it=lower_bound(adjacent.begin(),adjacent.end(),p.second);
        if(it==adjacent.end()||*it!=p.second)throw runtime_error("deleted entity absent");
        size_t offset=it-adjacent.begin();
        if(graph.eId.at(p.first).at(offset)!=edge)throw runtime_error("entity identity mismatch");
        adjacent.erase(it);
        graph.eId[p.first].erase(graph.eId[p.first].begin()+offset);
        --graph.deg[p.first];
    }
    --graph.numE;
}


static intE findEntity(const Graph& graph,intV u,intV v) {
    const auto& row=graph.adj.at(u);
    const auto it=lower_bound(row.begin(),row.end(),v);
    return it==row.end()||*it!=v?ABP_NOE:graph.eId[u][it-row.begin()];
}

struct DeleteState {
    Graph graph;
    BEGraphLoMem index;
    vector<intE> phi,es;
    vector<intB> h;
    PersistentWorkspace workspace;
    DeleteState(const InsertionBase& base,const vector<intE>& p,const vector<intE>& s,
             const vector<intB>& own):graph(base.graph),index(base.index),phi(p),es(s),h(own) {}
    void remove(intE edge,const string& variant,ABPMetrics* pb=nullptr,
                LayerMetrics* sl=nullptr,PersistentMetrics* af=nullptr) {
        const auto uv=graph.eIdToV.at(edge);
        if(findEntity(graph,uv.first,uv.second)!=edge)throw runtime_error("invalid deletion");
        if(variant=="PB") {
            
            arrayBMD_pb(index,phi,es,graph,uv.first,uv.second,edge,true,pb,nullptr,false,false);
        } else if(variant=="SL")arrayBMD_layer(index,phi,es,edge,true,1,sl);
        else if(variant=="AF")arrayBMDPersistent(index,phi,es,h,edge,workspace,af);
        else throw runtime_error("unknown deletion variant");
        eraseEntity(graph,edge);
    }
};
#endif
