#include "graph/abstract_bipartite_graph.h"
#include "wing/quasi_wing_maintenance.h"
#include "Header.h"
#include "graph.h"
#include "utils.h"
#include "KHeap.h"
#include "statistics.h"
#include "BEIndex.h"
#include "arrayCommon.h"
#include "arrayPsi.h"
#include "state.h"
using scnu::abstract_bipartite_edge;
using scnu::abstract_bipartite_graph;
#include "baiBench.h"
#include <filesystem>
#include <chrono>
#include <iomanip>
#include <sched.h>
#ifdef OPS_BUILD_BUILD
#include "work.h"
#endif
#ifdef INSERT_COUNT
#include "baiInsertionCounters.h"
#ifdef DELETE_BUILD_BUILD
#include "deletionAudit.h"
#endif
#endif

using Clock=chrono::steady_clock;
static double elapsedMilliseconds(Clock::time_point start) {
    return chrono::duration<double,milli>(Clock::now()-start).count();
}
static void singleThreadCheck() {
    size_t count=0;for(const auto& p:filesystem::directory_iterator("/proc/self/task")){(void)p;++count;}
    if(count!=1)throw runtime_error("actual threads not one");
}
static vector<pair<intV,intV>> loadSamples(const string& path) {
    ifstream input(path);if(!input)throw runtime_error("samples missing");
    vector<pair<intV,intV>> result;string line;
    while(getline(input,line)) {
        if(line.empty()||line[0]=='#'||line[0]=='%')continue;
        istringstream row(line);uint64_t u,v;string extra;
        if(!(row>>u>>v)||(row>>extra)||u>UINT32_MAX||v>UINT32_MAX)throw runtime_error("invalid sample");
        result.push_back({u,v});
    }
    if(result.size()!=500)throw runtime_error("expected 500 samples");return result;
}
static void sameIndex(const BEGraphLoMem& a,const BEGraphLoMem& b) {
    if(a.edgeEI!=b.edgeEI||a.bloomDegree!=b.bloomDegree||a.bloomWdgCnt!=b.bloomWdgCnt)
        throw runtime_error("BE memberships/count mismatch");
    for(intB id=0;id<a.numV;++id) {
        vector<pair<intE,intE>> x,y;
        for(intB j=a.bloomVI[id];j<a.bloomVI[id]+a.bloomDegree[id];++j)x.push_back(a.bloomEI[j]);
        for(intB j=b.bloomVI[id];j<b.bloomVI[id]+b.bloomDegree[id];++j)y.push_back(b.bloomEI[j]);
        sort(x.begin(),x.end());sort(y.begin(),y.end());if(x!=y)throw runtime_error("BE live path mismatch");
    }
}
static vector<uint64_t> updatedOwn(const InsertionState& initial,const InsertionState& state,const vector<intB>& own) {
    vector<int64_t> result(own.begin(),own.end());result.push_back(0);
    unordered_set<intB> changed;
    for(intE e=0;e<initial.edges();++e)if(initial.phi[e]!=state.phi[e])
        state.memberships(e,[&](auto p){changed.insert(p.first);});
    for(const auto& item:state.addedWedges)changed.insert(item.first);
    auto apply=[&](const InsertionState& s,intB b,int sign) {
        vector<intE> levels;vector<InsertionState::Wedge> paths;
        s.wedges(b,[&](auto p){paths.push_back(p);levels.push_back(min(s.phi[p.first],s.phi[p.second]));});
        sort(levels.begin(),levels.end());
        for(auto p:paths)for(intE e:{p.first,p.second}) {
            intE twin=e==p.first?p.second:p.first;if(s.phi[twin]<s.phi[e])continue;
            auto count=levels.end()-lower_bound(levels.begin(),levels.end(),s.phi[e]);
            if(!count)throw runtime_error("own wedge missing");result[e]+=sign*int64_t(count-1);
        }
    };
    for(intB b:changed){if(b<initial.blooms())apply(initial,b,-1);apply(state,b,1);}
    vector<uint64_t> output;for(auto x:result){if(x<0)throw runtime_error("negative own support");output.push_back(x);}return output;
}
static void growth(const InsertionState& initial,const InsertionState& state,pair<intV,intV> uv) {
    auto expected=initial.es;expected.push_back(0);
    using Key=pair<intV,intV>;using Paths=set<pair<intE,intE>>;
    map<Key,Paths> additions,actual;
    auto path=[](intE a,intE b)->pair<intE,intE>{return {min(a,b),max(a,b)};};
    const auto& graph=initial.base->graph;intE added=initial.edges();
    for(size_t i=0;i<graph.adj[uv.first].size();++i)for(size_t j=0;j<graph.adj[uv.second].size();++j) {
        intV x=graph.adj[uv.first][i],y=graph.adj[uv.second][j];
        const auto& row=graph.adj[y];auto pos=lower_bound(row.begin(),row.end(),x);
        if(pos==row.end()||*pos!=x)continue;
        intE a=graph.eId[uv.first][i],b=graph.eId[uv.second][j],c=graph.eId[y][pos-row.begin()];
        for(intE e:{added,a,b,c})++expected[e];
        auto minimum=min(min(uv.first,uv.second),min(x,y));bool u=minimum==uv.first||minimum==y;
        Key key=u?Key{min(uv.first,y),max(uv.first,y)}:Key{min(uv.second,x),max(uv.second,x)};
        additions[key].insert(u?path(added,b):path(added,a));additions[key].insert(u?path(a,c):path(b,c));
    }
    if(state.es!=expected||state.addedEdges.size()!=1||state.findEdge(uv.first,uv.second)!=added||state.findEdge(uv.second,uv.first)!=added)
        throw runtime_error("entity/es growth mismatch");
    map<intE,vector<InsertionState::Membership>> members;
    for(const auto& item:state.addedWedges) {
        intB b=item.first;auto key=state.master(b);key={min(key.first,key.second),max(key.first,key.second)};
        for(auto p:item.second) {
            if(!actual[key].insert(path(p.first,p.second)).second)throw runtime_error("duplicate added wedge");
            members[p.first].push_back({b,p.second});members[p.second].push_back({b,p.first});
        }
        if(b<initial.blooms())initial.wedges(b,[&](auto p){additions[key].erase(path(p.first,p.second));});
    }
    if(actual!=additions||members.size()!=state.addedMemberships.size())throw runtime_error("growth relation mismatch");
    for(auto& item:members) {
        auto found=state.addedMemberships.find(item.first);if(found==state.addedMemberships.end())throw runtime_error("missing membership");
        auto got=found->second;sort(got.begin(),got.end());sort(item.second.begin(),item.second.end());
        if(got!=item.second)throw runtime_error("growth membership mismatch");
    }
}
static void staticCheck(const InsertionState& initial,pair<intV,intV> uv,bool insertion,intE deleted,const vector<intE>& expected) {
    Graph graph=initial.base->graph;
    if(insertion)insertEdgeIntoG(graph,uv.first,uv.second);else eraseEntity(graph,deleted);
    auto gold=arrayStaticDecomp(graph);
    for(intE e=0;e<expected.size();++e)if(insertion||e!=deleted) {
        auto p=e==initial.edges()?uv:initial.endpoints(e);
        auto id=findEntity(graph,p.first,p.second);
        if(id==ABP_NOE||gold[id]!=expected[e])throw runtime_error("static phi mismatch edge="+to_string(e));
    }
}

#define INSERT_FIELDS(X) X(firstHop) X(secondHop) X(edgeLookups) X(initialButterflies) X(masterMembershipScans) X(newBlooms) X(newWedges) X(newMemberships) X(totalSupportWrites) X(totalSupportLogicalInc) X(layers) X(candidates) X(candidateUnique) X(closureMemberships) X(bloomBuilds) X(bloomHits) X(supportWedgeScans) X(supportMemberships) X(supportInitializations) X(peelPairs) X(batches) X(cascadeGroups) X(cascadeMemberships) X(cascadeWedgeScans) X(cascadeEffectiveWedges) X(workSupportWrites) X(workSupportLogicalDec) X(phiWritesIncludingNew) X(phiWritesExcludingNew) X(promotedEdges)
#define PB_FIELDS(X) X(firstHop) X(secondHop) X(edgeLookups) X(initialButterflies) X(structuralWedges) X(supportWedges) X(propagationWedges) X(peelWedges) X(preexpandWedges) X(compensationWedges) X(memberships) X(candidates) X(newBlooms) X(newWedges) X(totalSupportWrites) X(phiWritesIncludingNew) X(phiWritesExcludingNew)
#define SL_DELETE_FIELDS(X) X(layers) X(batches) X(seedLost) X(seedAttempts) X(admissionAttempts) X(candidateUnique) X(protectedAdmissions) X(supportInitializations) X(phiWrites) X(supportScans) X(supportMemberships) X(pruningMemberships) X(cascadeScans) X(cascadeApplyWedges) X(cascadeBloomGroups) X(supportWrites) X(supportLogicalDec) X(bloomBuilds) X(bloomHits)
#define AF_DELETE_FIELDS(X) X(initialLost) X(initialScans) X(initialMemberships) X(esWrites) X(esLogical) X(initialWrites) X(initialLogical) X(initialDeficitTests) X(lowerDeficitTests) X(checkAttempts) X(checkedPairs) X(keptChecks) X(pruningMemberships) X(peelPairs) X(phiWrites) X(layers) X(batches) X(cascadeMemberships) X(cascadeScans) X(cascadeApplyWedges) X(cascadeGroups) X(cascadeWrites) X(cascadeLogical) X(recomputeWrites) X(recomputeMemberships) X(recomputeScans) X(recomputeBuilds) X(recomputeHits) X(structuralMemberships) X(cleanupWrites)
#define PB_DELETE_FIELDS(X) X(R) X(C) X(U) X(Baff) X(bfl) X(bflB)

int main(int argc,char** argv) {
    size_t current=0;string phase="arguments";
    try {
        if(argc!=10)throw runtime_error("graph samples direction variant output repeats limit cpu mode required");
        string direction=argv[3],variant=argv[4],mode=argv[9];
        if(direction!="insert"&&direction!="delete")throw runtime_error("invalid direction");
        if(variant!="BAI"&&variant!="PB"&&variant!="SL"&&variant!="AF")throw runtime_error("invalid variant");
        if(mode!="time"&&mode!="verify"&&mode!="ops"&&mode!="stage")throw runtime_error("invalid mode");
        const bool verifyState=mode!="time";
        int repeats=stoi(argv[6]),limit=stoi(argv[7]),cpu=stoi(argv[8]);
        if(repeats<1||limit<1||limit>500)throw runtime_error("invalid repeat/limit");
        cpu_set_t affinity;CPU_ZERO(&affinity);CPU_SET(cpu,&affinity);
        if(sched_setaffinity(0,sizeof(affinity),&affinity))throw runtime_error("affinity failed");singleThreadCheck();
        filesystem::path folder=argv[5];if(!filesystem::create_directory(folder))throw runtime_error("output exists");
        auto start=Clock::now();auto base=make_shared<InsertionBase>();string graphPath=argv[1];base->graph.read_graph(graphPath,0);
        double readMs=elapsedMilliseconds(start);start=Clock::now();
        vector<intV> order,inverse;base->graph.sort_deg(order);invertMap(order,inverse);base->graph.reorder_in_place(inverse);
        base->left.resize(base->graph.numT);for(intV v=0;v<base->graph.numT;++v)base->left[v]=order[v]<base->graph.numU;
        double orderMs=elapsedMilliseconds(start);start=Clock::now();
        label_edges(base->graph);edgeId_to_vertices(base->graph);
        vector<intE> es(base->graph.numE,0),phi(base->graph.numE,0);vector<intV> wedgeCount(base->graph.numT,0);
        creat_BEIndex(base->graph,es,base->index,wedgeCount);
        double indexMs=elapsedMilliseconds(start);start=Clock::now();
        {auto copy=base->index;auto tip=es;fine_peel_part_wing(copy,tip,phi);}
        double peelMs=elapsedMilliseconds(start);start=Clock::now();
        vector<intB> own;
        if(variant=="AF"||variant=="BAI"||verifyState)buildPersistentSupport(base->index,phi,own);
        double ownMs=elapsedMilliseconds(start);
        InsertionState initial(base,phi,vector<uint64_t>(es.begin(),es.end()));
        unique_ptr<PBState> pbInitial;unique_ptr<InsertionPersistentState> afInitial;
        if(variant=="PB"&&direction=="insert")pbInitial=make_unique<PBState>(base,phi,initial.es);
        if(variant=="AF"&&direction=="insert")afInitial=make_unique<InsertionPersistentState>(initial);
        auto samples=loadSamples(argv[2]);vector<intE> removed;
        ofstream pairing(folder/"pairing.tsv");pairing<<"event_id\tu\tv\toriginal_u\toriginal_v\tstable_edge\n";
        for(size_t event=0;event<samples.size();++event) {
            auto uv=samples[event];
            if(uv.first>=base->graph.numT||uv.second>=base->graph.numT||base->left[uv.first]==base->left[uv.second])throw runtime_error("sample partition mismatch");
            auto edge=initial.findEdge(uv.first,uv.second);
            if((direction=="insert")!=(edge==ABP_NOE))throw runtime_error("sample presence mismatch");removed.push_back(edge);
            pairing<<event<<'\t'<<uv.first<<'\t'<<uv.second<<'\t'<<order[uv.first]<<'\t'<<order[uv.second]<<'\t';
            if(edge!=ABP_NOE)pairing<<edge;pairing<<'\n';
        }
        unique_ptr<BaiBench> bai;vector<intE> ownLevels;
        if(variant=="BAI") {
            for(auto x:own){if(x<0||x>UINT32_MAX)throw runtime_error("WS range exceeded");ownLevels.push_back(x);}
            bai=make_unique<BaiBench>(initial,ownLevels);
#if defined(INSERT_COUNT) && defined(DELETE_BUILD_BUILD)
            for(intE e=0;e<bai->edges.size();++e)audit::record.originalIds[bai->edges[e].get()]=e;
#endif
        }
        ofstream events(folder/"events.tsv"),counts(folder/"counts.tsv");
        events<<"event_id\treplicate\tu\tv\ttime_ms\tverified\tchanged_edges\tphi_delta\tmax_phi\trss_kib\n";
        counts<<"event_id\tmetric\tvalue\n";
#ifdef STAGE_BUILD_BUILD
        ofstream stageOutput(folder/"stages.tsv");stageOutput<<"event_id\treplicate\tstage\tms\n";
#endif
        InsertionWorkspace insertionWork;PersistentWorkspace deletionWork;
        uint64_t checksum=0,verified=0,staticChecks=0,nativeMaxRepairs=0;
        auto run=[&](size_t id,int repetition,bool emit) {
            current=id;auto uv=samples[id];intE deleted=removed[id];
            unique_ptr<InsertionState> sl;unique_ptr<PBState> pb;unique_ptr<InsertionPersistentState> af;unique_ptr<DeleteState> d;
            BaiBench::Edge edge;shared_ptr<unordered_set<BaiBench::Edge>> set;
            if(variant=="BAI") {
                if(direction=="insert") {
                    if(!base->left[uv.first])swap(uv.first,uv.second);
                }else edge=bai->edges[deleted];
                set=make_shared<unordered_set<BaiBench::Edge>>();if(edge)set->insert(edge);
            } else if(direction=="insert") {
                if(variant=="PB") {pb=make_unique<PBState>(*pbInitial);sl.reset();}
                else if(variant=="AF")af=make_unique<InsertionPersistentState>(*afInitial);
                else sl=make_unique<InsertionState>(initial);
                auto* s=pb?static_cast<InsertionState*>(pb.get()):af?static_cast<InsertionState*>(af.get()):sl.get();
                s->phi.reserve(s->edges()+1);s->es.reserve(s->edges()+1);s->workspace=std::move(insertionWork);
                if(af)af->h.reserve(af->edges()+1);
            }else {
                d=make_unique<DeleteState>(*base,phi,es,variant=="AF"?own:vector<intB>{});d->workspace=std::move(deletionWork);
            }
            singleThreadCheck();InsertionMetrics sm;InsertionPersistentMetrics am;PBMetrics pm;
            ABPMetrics pd;LayerMetrics sd;PersistentMetrics ad;
            uint32_t previousMaximum=bai?*bai->maxPhi:0;
#ifdef INSERT_COUNT
            if(bai) {
                scnu::bai_reset_ops();scnu::bai_reset_probes();baiDeletion::reset();
                baiInsertion::reset(nullptr);
#ifdef DELETE_BUILD_BUILD
                audit::record.reset();
                for(const char* key:{"recompute_reset_writes","recompute_increment_writes","peel_batches","cascade_edge_tests"})
                    audit::add(key,0);
#endif
            }
#endif
#ifdef OPS_BUILD_BUILD
            work::reset();
#endif
            auto timer=Clock::now();
#ifdef STAGE_BUILD_BUILD
            stage::begin();
#endif
            if(bai) {
                if(direction=="insert") {
                    edge=make_shared<abstract_bipartite_edge>(uv.first,uv.second);set->insert(edge);
#ifdef INSERT_COUNT
                    baiInsertion::inserted=edge.get();
#endif
                    bai->insert(set);
                    
                    auto exact=max(previousMaximum,bai->phi->at(edge));
                    *bai->maxPhi=exact;
                }else scnu::quasi_wing_maintenance::remove2(bai->graph,bai->locks,set,bai->rank,bai->phi,bai->ws,bai->maxPhi,bai->pool);
            }
#ifdef INSERT_COUNT
            else if(pb)pb->insert(uv.first,uv.second,&pm);
            else if(af)af->insert(uv.first,uv.second,&am);
            else if(sl)sl->insert(uv.first,uv.second,&sm);
            else d->remove(deleted,variant,&pd,&sd,&ad);
#else
            else if(pb)pb->insert(uv.first,uv.second);
            else if(af)af->insert(uv.first,uv.second);
            else if(sl)sl->insert(uv.first,uv.second);
            else d->remove(deleted,variant);
#endif
#ifdef STAGE_BUILD_BUILD
            stage::end();
#endif
            const double elapsed=elapsedMilliseconds(timer);singleThreadCheck();
#ifdef OPS_BUILD_BUILD
            const auto measuredWork=work::records;
#endif
            if(bai&&direction=="insert")++nativeMaxRepairs;
            const InsertionState* state=pb?static_cast<InsertionState*>(pb.get()):af?static_cast<InsertionState*>(af.get()):sl.get();
            vector<intE> baiPhi;vector<uint64_t> baiOwn;
            const vector<intE>* result=state?&state->phi:d?&d->phi:nullptr;
            if(bai) {
                baiPhi.resize(initial.edges()+(direction=="insert"));baiOwn.resize(baiPhi.size());
                for(intE e=0;e<baiPhi.size();++e)if(direction=="insert"||e!=deleted) {
                    auto item=e==initial.edges()?edge:bai->edges[e];baiPhi[e]=bai->phi->at(item);baiOwn[e]=bai->ws->at(item);
                    if(bai->graph->get_edge(item->get_left_vertex_id(),item->get_right_vertex_id())!=item)throw runtime_error("Bai entity mismatch");
                }
                if(direction=="delete"&&bai->graph->get_edge(edge->get_left_vertex_id(),edge->get_right_vertex_id()))throw runtime_error("deleted Bai entity remains");
                result=&baiPhi;
            }
            uint64_t delta=0,changed=0;intE maximum=0;
            for(intE e=0;e<result->size();++e)if(direction=="insert"||e!=deleted) {
                auto value=(*result)[e];auto before=e==phi.size()?0:phi[e];maximum=max(maximum,value);
                if(value!=before)++changed;delta+=value>before?value-before:before-value;
            }
            checksum+=delta+maximum;
            bool checked=false;
            if(verifyState) {
                if(direction=="insert") {
                    auto reference=initial;reference.insert(samples[id].first,samples[id].second);
                    if(*result!=reference.phi||(state&&state->es!=reference.es))throw runtime_error("insertion reference phi/es mismatch");
                    if(state)growth(initial,*state,samples[id]);
                    auto expectedOwn=updatedOwn(initial,reference,own);
                    if(af&&af->h!=expectedOwn)throw runtime_error("AF insertion h mismatch");
                    if(bai&&(baiOwn!=expectedOwn||*bai->maxPhi!=maximum))throw runtime_error("Bai insertion WS/max mismatch");
                } else {
                    DeleteState reference(*base,phi,es,{});reference.remove(deleted,"SL");
                    if(*result!=reference.phi)throw runtime_error("deletion reference phi mismatch");
                    if(d) {
                        for(intE e=0;e<es.size();++e)if(e!=deleted&&d->es[e]!=reference.es[e])throw runtime_error("deletion es mismatch");
                        sameIndex(d->index,reference.index);
                        if(d->graph.adj!=reference.graph.adj||d->graph.eId!=reference.graph.eId)throw runtime_error("deletion graph mismatch");
                    }
                    vector<intB> expectedOwn;buildPersistentSupport(reference.index,reference.phi,expectedOwn);
                    if(af)throw runtime_error("unexpected insertion state");
                    if(d&&variant=="AF"&&d->h!=expectedOwn)throw runtime_error("AF deletion h mismatch");
                    if(bai) {
                        for(intE e=0;e<es.size();++e)if(e!=deleted&&baiOwn[e]!=uint64_t(expectedOwn[e]))throw runtime_error("Bai deletion WS mismatch");
                        if(*bai->maxPhi!=maximum)throw runtime_error("Bai deletion maximum mismatch");
                    }
                }
                if(id==0||id==size_t(limit-1)) {staticCheck(initial,samples[id],direction=="insert",deleted,*result);++staticChecks;}
                ++verified;checked=true;
            }
            if(emit) {
#ifdef STAGE_BUILD_BUILD
                for(int s=0;s<stage::Stages;++s)stageOutput<<id<<'\t'<<repetition<<'\t'<<stage::names[s]<<'\t'<<setprecision(17)<<stage::elapsed[s]<<'\n';
#endif
                events<<id<<'\t'<<repetition<<'\t'<<samples[id].first<<'\t'<<samples[id].second<<'\t'<<setprecision(17)<<elapsed
                      <<'\t'<<checked<<'\t'<<changed<<'\t'<<delta<<'\t'<<maximum<<'\t'<<getVmRSS_KB()<<'\n';events.flush();
#ifdef INSERT_COUNT
                auto emitCount=[&](const char* name,uint64_t value){counts<<id<<'\t'<<name<<'\t'<<value<<'\n';};
                emitCount("outputChangedEdges",changed);emitCount("outputPhiDelta",delta);
                if(bai) {
                    emitCount("adjacencySecondHop",scnu::g_bai_wedge_probes);
                    if(direction=="delete") {
                    emitCount("adjacencyFirstHop",baiDeletion::firstHop);
                    emitCount("candidateTests",baiDeletion::candidateTests);
                    emitCount("testedUnique",baiDeletion::tested.size());
                    emitCount("peeledUnique",baiDeletion::peeled.size());
                    emitCount("phiWrites",baiDeletion::phiWrites);
                    emitCount("layers",scnu::g_bai_layers.load());
                    emitCount("layerCandidateScans",scnu::g_bai_layer_scan.load());
                    emitCount("supportCascadeWrites",scnu::g_bai_dec.load());
                    emitCount("supportInitialWrites",scnu::g_bai_dec_init.load());
                    emitCount("confirmedButterflyVisits",scnu::g_bai_baff.load());
                    }
                    if(direction=="delete")for(int site=0;site<24;++site) {
                        auto name="adjacencySecondHop_site"+to_string(site);emitCount(name.c_str(),scnu::g_bai_site_probes[site]);
                        name="confirmedButterflyVisits_site"+to_string(site);emitCount(name.c_str(),baiDeletion::guards[site]);
                    }
                    if(direction=="insert") {
                        const auto& m=baiInsertion::values;
#define BAI_VALUE(f) emitCount(#f,m.f);
                        BAI_VALUE(layers) BAI_VALUE(batches) BAI_VALUE(candidateTests) BAI_VALUE(candidates)
                        BAI_VALUE(peeled) BAI_VALUE(phiWrites) BAI_VALUE(phiLogicalInc) BAI_VALUE(phiLogicalIncExcludingNew)
#undef BAI_VALUE
                        emitCount("testedUnique",m.tested.size());emitCount("candidateUnique",m.candidateUnique.size());emitCount("peeledUnique",m.peeledUnique.size());
                        for(int site=0;site<baiInsertion::Sites;++site) {
#define BAI_SITE(f) {auto name=string(#f)+"_site"+to_string(site);emitCount(name.c_str(),m.f[site]);}
                            BAI_SITE(first) BAI_SITE(second) BAI_SITE(confirmed) BAI_SITE(supportWrites)
                            BAI_SITE(supportInc) BAI_SITE(supportDec) BAI_SITE(supportAssignments)
#undef BAI_SITE
                        }
                    }
#ifdef DELETE_BUILD_BUILD
                    for(const auto& item:audit::record.counts)emitCount(item.first.c_str(),item.second);
                    emitCount("supportUpdatedEdgeLayerUnique",audit::record.frequency.size());
                    emitCount("admittedEdgeLayerUnique",audit::record.admissions.size());
                    emitCount("supportRebuiltEdgeUnique",audit::record.recomputes.size());
#endif
                }
#define VALUE(f) emitCount(#f,m.f);
#ifdef OPS_BUILD_BUILD
                for(const auto& entry:measuredWork) {
                    auto total=entry.first+"_total",unique=entry.first+"_unique";
                    emitCount(total.c_str(),entry.second.total);emitCount(unique.c_str(),entry.second.keys.size());
                }
#endif
                if(pb){const auto& m=pm;PB_FIELDS(VALUE)}
                if(sl){const auto& m=sm;INSERT_FIELDS(VALUE)}
                if(af){const auto& m=am;INSERT_FIELDS(VALUE)
                    emitCount("hInitialWrites",m.hInitialWrites);emitCount("hPromotionWrites",m.hPromotionWrites);emitCount("hAssignments",m.hAssignments);
                    emitCount("hLogicalInc",m.hLogicalInc);emitCount("hMembershipScans",m.hMembershipScans);emitCount("hWedgeScans",m.hWedgeScans);
                    emitCount("hEffectiveWedges",m.hEffectiveWedges);emitCount("hGroups",m.hGroups);}
                if(d&&variant=="PB"){const auto& m=pd;PB_DELETE_FIELDS(VALUE)}
                if(d&&variant=="SL"){const auto& m=sd;SL_DELETE_FIELDS(VALUE)}
                if(d&&variant=="AF"){const auto& m=ad;AF_DELETE_FIELDS(VALUE)}
#undef VALUE
#endif
            }
            if(state) {
                auto* mutableState=pb?static_cast<InsertionState*>(pb.get()):af?static_cast<InsertionState*>(af.get()):sl.get();
                insertionWork=std::move(mutableState->workspace);
            }
            if(d)deletionWork=std::move(d->workspace);
            if(bai) {
                if(direction=="insert")bai->restore(initial,ownLevels,edge);
                else {
                    bai->graph->insert_edge(edge);*bai->maxPhi=0;
                    for(intE e=0;e<phi.size();++e) {
                        auto old=bai->edges[e];(*bai->phi)[old]=phi[e];bai->ws->at(old)=ownLevels[e];(*bai->rank)[old]=UINT32_MAX;
                        (*bai->scratch)[old]=0;*bai->maxPhi=max(*bai->maxPhi,phi[e]);
                    }
                }
            }
        };
        phase="warmup";run(0,-1,false);phase="events";
        for(int r=0;r<repeats;++r)for(size_t event=0;event<size_t(limit);++event)run(event,r,true);
        ofstream status(folder/"status.json");
        status<<"{\"events\":"<<limit<<",\"repeats\":"<<repeats<<",\"warmup\":1,\"actual_threads\":1,\"cpu\":"<<cpu
              <<",\"verified\":"<<verified<<",\"static_checks\":"<<staticChecks<<",\"max_wrapper_calls\":"<<nativeMaxRepairs
              <<",\"checksum\":"<<checksum<<",\"read_ms\":"<<readMs<<",\"order_ms\":"<<orderMs<<",\"index_ms\":"<<indexMs
              <<",\"peel_ms\":"<<peelMs<<",\"own_ms\":"<<ownMs<<",\"vertices\":"<<base->graph.numT<<",\"edges\":"<<base->graph.numE
              <<",\"mode\":\""<<mode<<"\",\"variant\":\""<<variant<<"\",\"direction\":\""<<direction<<"\"}\n";
        if(!status||!events||!counts)throw runtime_error("output failed");
        cout<<"BENCH_PASS variant="<<variant<<" direction="<<direction<<" events="<<limit<<" verified="<<verified<<endl;
    }catch(const exception& e){cerr<<"BENCH_FAIL phase="<<phase<<" event="<<current<<" "<<e.what()<<endl;return 1;}
}
